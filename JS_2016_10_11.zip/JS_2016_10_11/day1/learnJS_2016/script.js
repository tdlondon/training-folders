// single line JS comments

/*
	multiline
	JS
	comments
*/




/**
 * ===============================================================================
 *	VARIABLES
 * ===============================================================================
 *	* cannot start var names with numbers
 *	* var names cannot be any of reserved keywords
 *	* can use letters, numbers, _, $
 *	* var names are CASE SENSITIVE
 *	
 *	
 *	STEP 1) initialisation:
 *	
 *	var varName = value;
 *	
 *	STEP 2) usage:
 *	we use the var name to refer to its value
 *	
 */


/**
 * ===============================================================================
 *	DATATYPES
 * ===============================================================================
 */
var myString = 'a piece of text';
var myNumber = 2016;
var myBoolean = true;
var a;
var myNull = null;






/**
 * ===============================================================================
 *	USING THE CONSOLE FOR DEBUGGING
 * ===============================================================================
 *
 *	console.log('this is a log in the console');
 *	console.info('info');
 *	console.error('something wrong');
 */



/**
 * ===============================================================================
 *	use typeof to check datatype
 * ===============================================================================
 */




/**
 * ===============================================================================
 *	CONCATENATION
 * ===============================================================================
 */


// concatenating text and vars
// you can escape with \










/**
 * ===============================================================================
 *	PRE / POST INCREMENT AND DECREMENT (by 1) OPERATORS
 * ===============================================================================
 *	
 *	++ / --
 *	
 *	PRE increment
 *	change value first, then returns the result
 *	
 *	POST increment
 *	returns value, then changes it
 */





/**
 * ===============================================================================
 *	ARRAYS:
 * ===============================================================================
 *	* an array is an entity that can store a list of comma 
 *	separated values
 *	* each value will have an index automatically assigned
 *	* indexes are integers
 *	* indexes always start from 0
 *
 *	short declaration - array literal
 *  var myArray = [val, val , val ,val ....];
 *  indexes: 	  0    1	 2	  3	...
 */






/**
 * ===============================================================================
 * accessing values in an array:
 * ===============================================================================
 *
 * myArray[index]
 */


/**
 * ===============================================================================
 *	creating arrays
 * ===============================================================================
 *
 *	using the Array CONSTRUCTOR
 *	var arr = new Array(val, val, val)
 */




/**
 * ===============================================================================
 *	accessing the 
 *	no of elements in an array
 * ===============================================================================
 */







/**
 * ===============================================================================
 *	IF STATEMENTS
 * ===============================================================================
 *
 */
/*
if(condition){
	do something if condition is truthy
}
*/





//############################################

/*
if(condition){
	do something if condition is truthy
} else {
	do something if condition is falsy
}
*/


//############################################


/*
if(condition){
	do something if condition is truthy
} else if(condition2) {
	do something if condition2 is truthy
} else {
	do something if condition2 is falsy
}*/










/**
 * ===============================================================================
 *	SWITCH STATEMENTS
 * ===============================================================================
 *
 *	switch(element){
 *		case value:
 *			do something is element == value
 *		break;	
 *		
 *		case value2:
 *			do something is element == value2
 *		break;	
 *		
 *		case value3:
 *			do something is element == value3
 *		break;	
 *		
 *		default:
 *			do something for any other value
 *		break;	
 *	}
 *	
 */







/**
 * ===============================================================================
 *	FOR loops
 * ===============================================================================
 *
 *	* we use loops to repeat some code on the basis of a condition
 *	
 *	for(
 *		* initialise the iterator
 *		* condition (how many times we want to execute code)
 *		* update the iterator
 *	){
 *		code to repeat
 *	}//end for
 *
 */





/**
 * ===============================================================================
 *	LOOPING THROUGH ARRAYS
 * ===============================================================================
 *    using FOR loops
 */








/**
 * ===============================================================================
 *	LOOPING THROUGH ARRAYS
 *    using FOR-IN loops
 * ===============================================================================
 *
 *    this is more for objects rather than arrays
 *    * adding properties to the array will expose them as content
 *
 *	for(var i in arr){
 *		//do something to arr[i]
 *	}//end for
 */













/**
 * ===============================================================================
 *	FUNCTIONS
 * ===============================================================================
 *
 *	step1) declaration
 *	
 *	fuction fooName(){
 *		instructions:
 *		do this;
 *		do that;
 *		check...
 *		repeat...	
 *	}
 *	
 *	step2) invocation
 *	fooName();
 *	
 */


/**
 * ===============================================================================
 *	functions with params
 * ===============================================================================
 */



/**
 * ===============================================================================
 *	function that return values
 * ===============================================================================
 *
 *	* default: functions return undefined
 */



/**
 * 	makeAjuice sample
 */





/**
 * ===============================================================================
 *	EXERCISE IN CLASS:
 * ===============================================================================
 *
 *	implement a function
 *	following given
 *	documentation
 */


/**
 * @name	calculate
 * @desc	this will receive two numbers and an operator
 * 				then it will output the result
 * @param	{number}	numA	first number
 * @param	{string}	op		math operator [+,-,*,/]
 * @param	{number}	numB    second number
 * @return	{string}	result	the result of given operation
 */









/**
 * ===============================================================================
 *	OBJECTS
 * ===============================================================================
 *	
 *	in JS nearly everything is an object
 *	objects store values (PROPERTIES) and functions (METHODS)
 */





/**
 * ===============================================================================
 *	creating OBJECTS
 * ===============================================================================
 *
 *	//object literal (common in jQuery)
 */ 

















