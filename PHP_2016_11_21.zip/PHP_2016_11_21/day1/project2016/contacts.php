<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /contacts.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("includes/top.php");
include("includes/header.php");
####
?>
</header>

        <main>
            <section class="mainBody">
                <div class="container">

                    <!-- ====================  FEEDBACK START =========-->
                    <?php include("includes/feedback.php"); ?>
                    <!-- ====================  FEEDBACK END ===========-->

                    <div class="formHolder">
                        <div class="contactForm">
                            <div class="redDash"></div>
                            <h2 class="sectionTitle">Contact form</h2>
                            <form method="post" action="#">
                                <div class="formRow">
                                    <p><label class="fieldLabel" for="usrName">your name</label></p>
                                    <p><input class="formField" id="usrName" type="text" required name="usrName" value=""></p>
                                </div><!--/formRow-->

                                <div class="formRow">
                                    <p><label class="fieldLabel" for="usrEmail">your email</label></p>
                                    <p><input class="formField" id="usrEmail" type="email"  name="usrEmail" value=""></p>
                                </div><!--/formRow-->

                                <div class="formRow">
                                    <p><label class="fieldLabel" for="usrMsg">your message</label></p>
                                    <p><textarea class="formField" id="usrMsg" name="usrMsg"></textarea></p>
                                </div><!--/formRow-->

                                <p class="contactBtns">
                                    <button type="reset" class="btn ckBtn smBtn">clear</button>
                                    <button type="submit" class="btn ckBtn smBtn blueBtn">send</button>
                                </p>
                            </form>
                        </div><!--/contactForm-->
                        <div class="contactInfo">
                            <div class="redDash"></div>
                            <h2 class="sectionTitle">Contact info</h2>
                            <div class="map">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d634.4015521947482!2d-0.10726981697067936!3d51.51954980174244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761b38b4d1161f%3A0xb8fb2ba0663d6ea!2sTraining+Dragon!5e0!3m2!1sen!2suk!4v1474061067334" width="250" height="170" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div><!--/map-->
                            <div class="companyAddress">
                                <h4>Training Dragon</h4>
                                <p class="addrPar">3-4 Kirby Street,</p>
                                <p class="addrPar">London, EC1N 8TS</p>
                                <p class="phonePar">Telephone: +1 959 603 6035</p>
                                <p class="linkPar"><a href="http://www.trainingdragon.co.uk">www.companyname.co.uk</a></p>
                            </div>
                        </div><!--/contactInfo-->
                    </div>
                </div><!--/mainBody container-->
            </section><!--/ mainBoby-->
        </main>

<?php include("includes/footer.php");?>

</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>

