<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/user.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="editAddItem">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Add / Edit user</h2>
                        <form method="post" enctype="multipart/form-data" action="#" class="editAddForm editAddProd flexCont">
                            <div class="formCol">
                                <label for="uName">FIRST NAME</label>
                                <input class="formField" type="text" id="uName" name="uName" value="">

                                <label for="uLast">LAST NAME</label>
                                <input class="formField" type="text" id="uLast" name="uLast" value="">

                                <label for="uEmail">EMAIL</label>
                                <input class="formField" type="email" id="uEmail" name="uEmail" value="">

                                <label for="uPsw">PASSWORD</label>
                                <input class="formField" type="text" id="uPsw" name="uPsw" value="">

                                <label for="uPhone">PHONE</label>
                                <input class="formField" type="text" id="uPhone" name="uPhone" value="">
                            </div><!--/formCol-->

                            <div class="formCol">
                                <label for="uAddr1">ADDRESS 1</label>
                                <input class="formField" type="text" id="uAddr1" name="uAddr1" value="">

                                <label for="uAddr2">ADDRESS 2</label>
                                <input class="formField" type="text" id="uAddr2" name="uAddr2" value="">

                                <label for="uCode">POSTAL CODE</label>
                                <input class="formField" type="text" id="uCode" name="uCode" value="">

                                <label for="uCity">CITY</label>
                                <input class="formField" type="text" id="uCity" name="uCity" value="">

                                <label for="uCountry">COUNTRY</label>
                                <input class="formField" type="text" id="uCountry" name="uCountry" value="GB">


                                <button type="submit" name="submit" class="btn ckBtn smBtn blueBtn">Add / Edit user</button>

                            </div><!--/formCol-->
                        </form><!--/editAddForm-->

                    </section><!--/editAddItem-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>

<?php include ("../includes/footer.php");?>
</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>