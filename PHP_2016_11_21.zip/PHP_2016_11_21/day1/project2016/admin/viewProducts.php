<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/viewProducts.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">View products</h2>
                        
                        <div class="itemsBlock">
                            <div class="itemLabelsBlock flexCont">
                                <div class="itemLabel pIDLabel">id</div>
                                <div class="itemLabel pNameLabel">name</div>
                                <div class="itemLabel pPriceLabel">price</div>
                                <div class="itemLabel pDescLabel">description</div>
                                <div class="itemLabel pShippLabel">shipping</div>
                                <div class="itemLabel pImageLabel">image</div>
                            </div><!--/itemLabels-->

                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox vCentre pIDBox">
                                    <p>1</p>
                                </div><!--/pID-->

                                <div class="itemBox vCentre pNameBox">
                                    <p>iPhone</p>
                                </div><!--/pName-->

                                <div class="itemBox vCentre pPriceBox">
                                    <p>&pound;900.00</p>
                                </div><!--/pPrice-->

                                <div class="itemBox vCentre pDescBox">
                                    <p>new iPhone 7</p>
                                </div><!--/pDesc-->

                                <div class="itemBox vCentre pShippBox">
                                    <p>&pound;20.00</p>
                                </div><!--/pShipp-->

                                <div class="itemBox vCentre pImageBox">
                                    <img src="<?php echo ROOT;?>build/imgs/sample_products/iphone.jpg" width="75" height="75" title="iPhone" alt="iPhone">
                                </div><!--/pImage-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="<?php echo ROOT;?>/admin/product.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item =======================================================-->

                            <!--DELETE FROM HERE =================================-->
                            <div class="item flexCont">
                                <div class="itemBox vCentre pIDBox">
                                    <p>2</p>
                                </div><!--/pID-->

                                <div class="itemBox vCentre pNameBox">
                                    <p>servo motor</p>
                                </div><!--/pName-->

                                <div class="itemBox vCentre pPriceBox">
                                    <p>&pound;3.00</p>
                                </div><!--/pPrice-->

                                <div class="itemBox vCentre pDescBox">
                                    <p>Parallax Inc</p>
                                </div><!--/pDesc-->

                                <div class="itemBox vCentre pShippBox">
                                    <p>&pound;1.00</p>
                                </div><!--/pShipp-->

                                <div class="itemBox vCentre pImageBox">
                                    <img src="<?php echo ROOT;?>build/imgs/sample_products/servo.jpg" width="75" height="75" title="servo" alt="iPhone">
                                </div><!--/pImage-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="<?php echo ROOT;?>/admin/product.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->


                            <div class="item flexCont">
                                <div class="itemBox vCentre pIDBox">
                                    <p>3</p>
                                </div><!--/pID-->

                                <div class="itemBox vCentre pNameBox">
                                    <p>Chassis</p>
                                </div><!--/pName-->

                                <div class="itemBox vCentre pPriceBox">
                                    <p>&pound;9.00</p>
                                </div><!--/pPrice-->

                                <div class="itemBox vCentre pDescBox">
                                    <p>chassis for arduino projects</p>
                                </div><!--/pDesc-->

                                <div class="itemBox vCentre pShippBox">
                                    <p>&pound;2.00</p>
                                </div><!--/pShipp-->

                                <div class="itemBox vCentre pImageBox">
                                    <img src="<?php echo ROOT;?>build/imgs/sample_products/chassis.jpg" width="75" height="75" title="chassis" alt="iPhone">
                                </div><!--/pImage-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="<?php echo ROOT;?>/admin/product.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->



                            <!--DELETE UP TO HERE=======================================================-->

                        </div><!--/itemsBlock-->


                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php");?>
</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>