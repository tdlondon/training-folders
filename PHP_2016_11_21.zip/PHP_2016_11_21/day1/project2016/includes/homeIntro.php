<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/homeIntro.php
 */
?>



        <section class="offer">
            <div class="container">
                <div class="offerLeft">
                    <div class="redDash"></div>
                    <h2 class="underlined offerTitle">We offer the best!</h2>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean quam ante, egestas tristique consequat ut, pulvinar a ante.
                    </p>

                    <p>
                        Donec commodo eros at felis tempor at porttitor mauris adipisci morbi in velit sapien modo eros at felis te adispicing ulvinar.
                    </p>
                </div><!--/offerLeft-->

                <div class="offerVideo"></div><!--/offerVideo-->
            </div><!--/ offer container-->
        </section><!--/ offer-->

        <section class="promises">
            <div class="container">
                <div class="redDash"></div>
                <h2 class="underlined promiseTitle">Our promises</h2>
            </div><!--/promises container-->
        </section><!--/promises-->
