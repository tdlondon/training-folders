<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/adminNav.php
 */
?>



        <section class="adminNavBlock">
            <div class="container">
                <section class="welcome">
                    <div class="redDash"></div>
                    <h2 class="welcomeTitle">Welcome back, John!</h2>
                </section><!--/welcome-->

                <nav class="adminNav">
                    <ul class="flexCont">
                        <li><a class="ckBtn" href="<?php echo ROOT;?>admin/viewProducts.php">view products</a></li>
                        <li><a class="ckBtn" href="<?php echo ROOT;?>admin/product.php">add product</a></li>
                        <li><a class="ckBtn" href="<?php echo ROOT;?>admin/viewUsers.php">view users</a></li>
                        <li><a class="ckBtn" href="<?php echo ROOT;?>admin/user.php">add user</a></li>
                        <li><a class="ckBtn" href="<?php echo ROOT;?>admin/viewPages.php">view pages</a></li>
                        <li><a class="ckBtn" href="<?php echo ROOT;?>admin/page.php">add pages</a></li>
                        <li><a class="ckBtn" href="#">log out</a></li>
                    </ul>
                </nav>
            </div>   <!--/container-->
        </section><!--/adminNavBlock-->
