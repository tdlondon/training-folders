<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | HOME</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
    <meta name="description" content="php project homepage"/>
    <meta name="keywords" content="home keywords"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a class="currentPageLink" href="index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="search.php">search</a></li>
                        <li><a href="contacts.php">contacts</a></li>
                        <li><a href="admin/admin.php">admin</a></li>
                        <li><a href="admin/basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

            <div class="banner">
                <div class="container">
                    <div class="redDash"></div>
                    <h1 class="mainName">Company Name</h1>
                    <h2 class="subTitle">We are great at what we do!</h2>
                    <div class="redDash"></div>
                    <div class="mainDesc underlined">
                        Lorem ipsum dolor sit amet, consectetur elit.
                        Aenean quam ante, egestas tristique consequat ut,
                        Donec commodo eros at felis tempor at porttitor.
                    </div><!--/mainDesc-->

                </div><!--/ banner container-->
            </div><!--/banner-->
        </header>

        <main>
            <section class="offer">
                <div class="container">
                    <div class="offerLeft">
                        <div class="redDash"></div>
                        <h2 class="underlined offerTitle">We offer the best!</h2>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>

                        <p>
                            Donec commodo eros at felis tempor at porttitor mauris adipisci morbi in velit sapien modo eros at felis te adispicing ulvinar.
                        </p>
                    </div><!--/offerLeft-->

                    <div class="offerVideo"></div><!--/offerVideo-->
                </div><!--/ offer container-->
            </section><!--/ offer-->

            <section class="promises">
                <div class="container">
                    <div class="redDash"></div>
                    <h2 class="underlined promiseTitle">Our promises</h2>
                </div><!--/promises container-->
            </section><!--/promises-->

            <section class="mainBody">
                <div class="container flexCont">
                    <div class="homeCol">
                        <div class="topCol">
                            <img src="build/imgs/Symbols/symbol.png" width="31" height="31" alt="red logo">
                            <h3>Commitment</h3>
                        </div><!--/topCol-->
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>
                        <a href="#" class="btn moreBtn ckBtn">read more</a>
                    </div><!--/homeCol-->
                    <div class="homeCol">
                        <div class="topCol">
                            <img src="build/imgs/Symbols/symbol.png" width="31" height="31" alt="red logo">
                            <h3>Quality</h3>
                        </div><!--/topCol-->
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>
                        <a href="#" class="btn moreBtn ckBtn">read more</a>
                    </div><!--/homeCol-->
                    <div class="homeCol">
                        <div class="topCol">
                            <img src="build/imgs/Symbols/symbol.png" width="31" height="31" alt="red logo">
                            <h3>Trust</h3>
                        </div><!--/topCol-->
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>
                        <a href="#" class="btn moreBtn ckBtn">read more</a>
                    </div><!--/homeCol-->
                </div><!--/mainBody container-->
            </section><!--/ mainBoby-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="search.php">Search</a> |
                        <a href="contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div><!--/wrapper-->
</body>
</html>