<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | SEARCH</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
    <meta name="description" content="php project search"/>
    <meta name="keywords" content="search keywords"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a class="currentPageLink" href="search.php">search</a></li>
                        <li><a href="contacts.php">contacts</a></li>
                        <li><a href="admin/admin.php">admin</a></li>
                        <li><a href="admin/basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success</div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->


                    <section class="search">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Search</h2>
                        <form method="get" action="#" class="searchForm">
                            <input type="text" class="formField" name="q" value="" placeholder="Type here_">
                            <button class="btn ckBtn bgBtn blueBtn">search</button>
                        </form>
                    </section><!--/search-->
                </div><!--/container-->

                <div class="separator"></div>

                <div class="container">
                    <section class="searchResults">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Results for <span class="qName">iMac</span></h2>

                        <div class="resultProduct flexCont"><!--=============================== result product-->
                            <div class="resPic vCentre">
                                <img src="build/imgs/sample_products/imac.jpg" width="106" height="106" title="imac" alt="imac">
                            </div><!--/resPic-->
                            
                            <div class="resDetails vCentre">
                                <div>
                                    <h4 class="resName">iMac</h4>
                                    <p class="resDesc">Latest model</p>
                                </div>
                            </div><!--/resDetails-->
                            
                            <div class="resPrice vCentre">
                                <p>&pound;1500.00</p>
                            </div><!--/resPrice-->
                            
                            <div class="resAction vCentre">
                                <a href="admin/basket.php" class="btn ckBtn smBtn blueBtn">add to basket</a>
                            </div><!--/resAction-->
                        </div><!--/resultProduct ==============================================================-->

                        <div class="resultProduct flexCont">
                            <div class="resPic vCentre">
                                <img src="build/imgs/sample_products/motor.jpg" width="106" height="106" title="imac" alt="imac">
                            </div><!--/resPic-->

                            <div class="resDetails vCentre">
                                <div>
                                    <h4 class="resName">Motor</h4>
                                    <p class="resDesc">Latest model</p>
                                </div>
                            </div><!--/resDetails-->

                            <div class="resPrice vCentre">
                                <p>&pound;1500.00</p>
                            </div><!--/resPrice-->

                            <div class="resAction vCentre">
                                <a href="admin/basket.php" class="btn ckBtn smBtn blueBtn">add to basket</a>
                            </div><!--/resAction-->
                        </div><!--/resultProduct ==============================================================-->

                        <div class="resultProduct flexCont">
                            <div class="resPic vCentre">
                                <img src="build/imgs/sample_products/tank.jpg" width="106" height="106" title="imac" alt="imac">
                            </div><!--/resPic-->

                            <div class="resDetails vCentre">
                                <div>
                                    <h4 class="resName">tank chassis</h4>
                                    <p class="resDesc">Latest model</p>
                                </div>
                            </div><!--/resDetails-->

                            <div class="resPrice vCentre">
                                <p>&pound;1500.00</p>
                            </div><!--/resPrice-->

                            <div class="resAction vCentre">
                                <a href="admin/basket.php" class="btn ckBtn smBtn blueBtn">add to basket</a>
                            </div><!--/resAction-->
                        </div><!--/resultProduct ==============================================================-->

                        
                                         
                    </section><!--/searchResults-->

                </div><!--/mainBody container-->
            </section><!--/ mainBody-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="search.php">Search</a> |
                        <a href="contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>
</body>
</html>