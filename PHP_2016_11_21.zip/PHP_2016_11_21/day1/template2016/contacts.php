<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | CONTACTS</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
    <meta name="description" content="php project contacts"/>
    <meta name="keywords" content="contacts keywords"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="search.php">search</a></li>
                        <li><a class="currentPageLink" href="contacts.php">contacts</a></li>
                        <li><a href="admin/admin.php">admin</a></li>
                        <li><a href="admin/basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="mainBody">
                <div class="container">

                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success</div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->

                    <div class="formHolder">
                        <div class="contactForm">
                            <div class="redDash"></div>
                            <h2 class="sectionTitle">Contact form</h2>
                            <form method="post" action="#">
                                <div class="formRow">
                                    <p><label class="fieldLabel" for="usrName">your name</label></p>
                                    <p><input class="formField" id="usrName" type="text" required name="usrName" value=""></p>
                                </div><!--/formRow-->

                                <div class="formRow">
                                    <p><label class="fieldLabel" for="usrEmail">your email</label></p>
                                    <p><input class="formField" id="usrEmail" type="email"  name="usrEmail" value=""></p>
                                </div><!--/formRow-->

                                <div class="formRow">
                                    <p><label class="fieldLabel" for="usrMsg">your message</label></p>
                                    <p><textarea class="formField" id="usrMsg" name="usrMsg"></textarea></p>
                                </div><!--/formRow-->

                                <p class="contactBtns">
                                    <button type="reset" class="btn ckBtn smBtn">clear</button>
                                    <button type="submit" class="btn ckBtn smBtn blueBtn">send</button>
                                </p>
                            </form>
                        </div><!--/contactForm-->
                        <div class="contactInfo">
                            <div class="redDash"></div>
                            <h2 class="sectionTitle">Contact info</h2>
                            <div class="map">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d634.4015521947482!2d-0.10726981697067936!3d51.51954980174244!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48761b38b4d1161f%3A0xb8fb2ba0663d6ea!2sTraining+Dragon!5e0!3m2!1sen!2suk!4v1474061067334" width="250" height="170" frameborder="0" style="border:0" allowfullscreen></iframe>
                            </div><!--/map-->
                            <div class="companyAddress">
                                <h4>Training Dragon</h4>
                                <p class="addrPar">3-4 Kirby Street,</p>
                                <p class="addrPar">London, EC1N 8TS</p>
                                <p class="phonePar">Telephone: +1 959 603 6035</p>
                                <p class="linkPar"><a href="http://www.trainingdragon.co.uk">www.companyname.co.uk</a></p>
                            </div>
                        </div><!--/contactInfo-->
                    </div>
                </div><!--/mainBody container-->
            </section><!--/ mainBoby-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="search.php">Search</a> |
                        <a href="contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>
</body>
</html>