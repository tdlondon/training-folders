<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /includes/utilities.php
 */

/*
  This will take care of:
    + useful constants,
    + error handling,
    + database connection and selection
    + helper functions
 */

//===========  ERROR HANDLING:

######  DO NOT EXPOSE ERRORS IN PRODUCTION MODE
###### ATTACKERS CAN GET ADVANTAGE OF THEM!!!!
ini_set('display_errors','on');
error_reporting(E_ALL);


//===========  CONSTANTS:

###### defining a constant pointing at the root folder
//define('CONST_NAME','VALUE');



//===========  DATABASE LOGIC:




//===========  HELPER FUNCTIONS:


/**
 *	trace
 *
 *	this foo will display the content of arrays/superglobals
 *	in a nice and readable fashion
 *
 *  @param   {ARRAY}	$arr		the array to show
 */
function trace($arr){
    echo "<pre>";
    print_r($arr);
    echo "</pre>";
}//end trace



