<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | BASKET</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="../build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="../build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="../build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="../search.php">search</a></li>
                        <li><a href="../contacts.php">contacts</a></li>
                        <li><a href="admin.php">admin</a></li>
                        <li><a class="currentPageLink" href="basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="adminNavBlock">
                <div class="container">
                    <section class="welcome">
                        <div class="redDash"></div>
                        <h2 class="welcomeTitle">Welcome back, John!</h2>
                    </section><!--/welcome-->

                    <nav class="adminNav">
                        <ul class="flexCont">
                            <li><a class="ckBtn" href="viewProducts.php">view products</a></li>
                            <li><a class="ckBtn" href="product.php">add product</a></li>
                            <li><a class="ckBtn" href="viewUsers.php">view users</a></li>
                            <li><a class="ckBtn" href="user.php">add user</a></li>
                            <li><a class="ckBtn" href="viewPages.php">view pages</a></li>
                            <li><a class="ckBtn" href="page.php">add pages</a></li>
                            <li><a class="ckBtn" href="#">log out</a></li>
                        </ul>
                    </nav>
                </div>   <!--/container-->
            </section><!--/adminNavBlock-->

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success <a href="#" class="boldLink">feedback link</a> </div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Basket</h2>


                        <!--========== no products in the basket ===========-->
                        <div class="noProducts">
                            <p>There are currently no products in the basket, please use the
                                <a href="../search.php" class="boldLink">search</a> page to look for new ones.</p>
                        </div><!--/noProducts-->
                        <!--========== end no products in the basket =======-->


                        <div class="itemsBlock">
                            <div class="itemLabelsBlock basketItemLabelsBlock flexCont">
                                <div class="itemLabel bQtyLabel">Qty</div>
                                <div class="itemLabel bImageLabel">Image</div>
                                <div class="itemLabel bNameLabel">Name</div>
                                <div class="itemLabel bUnitPriceLabel">Unit Price</div>
                                <div class="itemLabel bTotalPriceLabel">Total Price</div>
                                <div class="itemLabel bUnitShippLabel">Item shipping</div>
                                <div class="itemLabel bTotalShippLabel">Total shipphing</div>
                            </div><!--/itemLabels-->

                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox bQtyBox">
                                    <p  class="qtyNoPar">2</p>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/bQtyBox-->

                                <div class="itemBox vCentre bImageBox">
                                    <img src="../build/imgs/sample_products/iphone.jpg" width="75" height="75" title="iPhone" alt="iPhone">
                                </div><!--/bImageBox-->

                                <div class="itemBox vCentre bNameBox">
                                    <p>iPhone</p>
                                </div><!--/bNameBox-->

                                <div class="itemBox vCentre bUnitPriceBox">
                                    <p>&pound;200.00</p>
                                </div><!--/bUnitPriceBox-->

                                <div class="itemBox vCentre bTotalPriceBox">
                                    <p>&pound;400.00</p>
                                </div><!--/bTotalPriceBox-->

                                <div class="itemBox vCentre bUnitShippBox">
                                    <p>&pound;25.00</p>
                                </div><!--/bUnitShippBox-->

                                <div class="itemBox vCentre bTotalShippBox">
                                    <p>&pound;50.00</p>
                                </div><!--/bTotalShippBox-->

                            </div><!--/item =======================================================-->

                            <!--DELETE FROM HERE =================================-->
                            <div class="item flexCont">
                                <div class="itemBox bQtyBox">
                                    <p  class="qtyNoPar">3</p>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/bQtyBox-->

                                <div class="itemBox vCentre bImageBox">
                                    <img src="../build/imgs/sample_products/tank.jpg" width="75" height="75" title="iPhone" alt="iPhone">
                                </div><!--/bImageBox-->

                                <div class="itemBox vCentre bNameBox">
                                    <p>tank</p>
                                </div><!--/bNameBox-->

                                <div class="itemBox vCentre bUnitPriceBox">
                                    <p>&pound;20.00</p>
                                </div><!--/bUnitPriceBox-->

                                <div class="itemBox vCentre bTotalPriceBox">
                                    <p>&pound;60.00</p>
                                </div><!--/bTotalPriceBox-->

                                <div class="itemBox vCentre bUnitShippBox">
                                    <p>&pound;3.00</p>
                                </div><!--/bUnitShippBox-->

                                <div class="itemBox vCentre bTotalShippBox">
                                    <p>&pound;9.00</p>
                                </div><!--/bTotalShippBox-->

                            </div>



                            <!--DELETE UP TO HERE=======================================================-->
                            <div class=" basketFinal">
                                <div class="flexCont">
                                    <div class="itemLabel">SUBSHIPPING</div>
                                    <div class="itemBox subItemBox">&pound;0.00</div>
                                </div>
                                <div class="flexCont">
                                    <div class="itemLabel">SUBTOTAL</div>
                                    <div class="itemBox subItemBox">&pound;0.00</div>
                                </div>
                                <div class="flexCont">
                                    <div class="itemLabel">GRAND TOTAL</div>
                                    <div class="itemBox redItemBox">&pound;0.00</div>
                                </div>
                                <a href="checkout.php" class="checkoutBtn btn blueBtn ckBtn">checkout</a>
                            </div><!--/basketFinal-->
                        </div><!--/itemsBlock-->


                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="../index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="../search.php">Search</a> |
                        <a href="../contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>
</body>
</html>