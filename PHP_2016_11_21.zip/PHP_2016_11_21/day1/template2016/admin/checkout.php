<!--/ https://developer.paypal.com/docs/classic/paypal-payments-standard/integration-guide/formbasics/ -->

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | CHECKOUT</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="../build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="../build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="../build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="../search.php">search</a></li>
                        <li><a href="../contacts.php">contacts</a></li>
                        <li><a href="admin.php">admin</a></li>
                        <li><a href="basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="adminNavBlock">
                <div class="container">
                    <section class="welcome">
                        <div class="redDash"></div>
                        <h2 class="welcomeTitle">Welcome back, John!</h2>
                    </section><!--/welcome-->

                    <nav class="adminNav">
                        <ul class="flexCont">
                            <li><a class="ckBtn" href="viewProducts.php">view products</a></li>
                            <li><a class="ckBtn" href="product.php">add product</a></li>
                            <li><a class="ckBtn" href="viewUsers.php">view users</a></li>
                            <li><a class="ckBtn" href="user.php">add user</a></li>
                            <li><a class="ckBtn" href="viewPages.php">view pages</a></li>
                            <li><a class="ckBtn" href="page.php">add pages</a></li>
                            <li><a class="ckBtn" href="#">log out</a></li>
                        </ul>
                    </nav>
                </div>   <!--/container-->
            </section><!--/adminNavBlock-->

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success</div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
                    <section class="editAddItem">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Checkout</h2>
                        <form method="post" enctype="multipart/form-data" action="https://www.paypal.com/cgi-bin/webscr" class="editAddForm editAddProd flexCont">
                            <INPUT TYPE="hidden" name="address_override" value="1">
                            <input type="hidden" name="cmd" value="_xclick">
                            <input type="hidden" name="business" value="seller@email.com">
                            <input type="hidden" name="notify_url" value="sellerwebsite.com/confirmation.php">
                            <INPUT TYPE="hidden" name="address_override" value="1">
                            <input type="hidden" name="item_name" value="company order">
                            <input type="hidden" name="item_number" value="1">
                            <input type="hidden" name="currency_code" value="GBP">
                            <div class="formCol">
                                <label for="first_name">FIRST NAME</label>
                                <input class="formField" type="text" id="first_name" name="first_name" value="John">

                                <label for="last_name">LAST NAME</label>
                                <input class="formField" type="text" id="last_name" name="last_name" value="Doe">

                                <label for="email">EMAIL</label>
                                <input class="formField" type="email" id="email" name="email" value="j@email.com">


                                <label for="addr1">ADDRESS 1</label>
                                <input class="formField" type="text" id="uAddr1" name="addr1" value="ad1">

                                <label for="addr2">ADDRESS 2</label>
                                <input class="formField" type="text" id="uAddr2" name="addr2" value="ad2">
                            </div><!--/formCol-->

                            <div class="formCol">
                                <label for="phone">PHONE</label>
                                <input class="formField" type="text" id="phone" name="phone" value="123123123">

                                <label for="zip">POSTAL CODE</label>
                                <input class="formField" type="text" id="zip" name="zip" value="A1 3BC">

                                <label for="city">CITY</label>
                                <input class="formField" type="text" id="city" name="city" value="London">

                                <label for="country">COUNTRY</label>
                                <input class="formField" type="text" id="country" name="country" value="GB">

                                <label for="amount">YOU WILL PAY A TOTAL OF</label>
                                <input class="formField" type="text" id="fakeamount" name="fakeamount" value="&pound;123.00">
                                <input  class="formField" type="hidden" id="amount" name="amount" value="123">


                                <button type="submit" name="submit" class="btn ckBtn smBtn blueBtn">Buy now</button>

                            </div><!--/formCol-->
                        </form><!--/editAddForm-->

                    </section><!--/editAddItem-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="../index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="../search.php">Search</a> |
                        <a href="../contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>

</body>
</html>