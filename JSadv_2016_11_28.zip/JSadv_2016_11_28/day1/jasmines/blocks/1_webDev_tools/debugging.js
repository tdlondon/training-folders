/**
 * @preserve
 * Created by TrainingDragon
 * file:    debugging.js
 * using source tab for breakpoints and debugging
 */


(function(){

    var
        firstTest = function(){
            var d = document.getElementById('d');
            d.innerHTML += "<p>TEST 1 here, insert breakpoints BEFORE or AFTER this line</p>";
        },//firstTest

        loopTest = function(){
            var i = 0, l = 10;
            for(;i<l;i++){
                d.innerHTML += "<p>test no: "+i+"</p>";
            }//for
        },//loopTest

        init = function(){
            firstTest();
            loopTest();
        };//init

    window.onload = init;
})();







