/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 4_DOM_events
 * spec         : 0_DOM_events_spec
 **/





(function(){
    var
        links1 = document.querySelectorAll('#ul1 a'),
        i = 0,
        l = links1.length,
        ul2 = document.getElementById('ul2')

    ;

    $(".lists").on("click", "a", function(e){
        e.preventDefault();
    });

    for(;i<l;i++){
        links1[i].addEventListener("click", function(e){
            console.log(e);
            $("#ul1t").html(e.target.nodeName);
            $("#ul1ct").html(e.currentTarget.nodeName);
        });

    }

    ul2.addEventListener("click", function(e){
        $("#ul2t").html(e.target.nodeName);
        $("#ul2ct").html(e.currentTarget.nodeName);
        if(e.target.nodeName.toLowerCase() === 'a'){
            console.log("clicked on a link");

        }
    });


    $("#btn1").on("click", function(){
        $("#ul1t").html('');
        $("#ul1ct").html('');
        $("#ul1").append("<li>LI with appended <a href='#'>LINK</a></li>");
    });

    $("#btn2").on("click", function(){
        $("#ul2t").html('');
        $("#ul2ct").html('');
        $("#ul2").append("<li>LI with appended <a href='#'>LINK</a></li>");
    });


})();
