/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 4_DOM_events
 * spec         : 1_DOM_events_exercises_spec
 **/


/**
 *  EXERCISE:
 *  display a "RUN" message in output area (add .running class)
 *  whenever any of the textareas receives "run" as input
 *  OR when clicking on runBtn
 *
 *  * use delegate events
 *  * dispatch a custom event
 *  * subscribe a handler for custom event
 *
 **/

(function(){
    var
        myForm = document.getElementById('myForm'),
        runBtn = document.getElementById('runBtn'),
        resetBtn = document.getElementById('resetBtn'),
        textAreas = document.querySelectorAll('textarea'),
        output = document.getElementById('output'),

        runEvent = new CustomEvent(
            "runEvent",
            {
                detail : {
                    text : "need to run!",
                    time :new Date()
                },
                bubbles : true,
                cancelable : true
            }
        );

        displayRun = function(){
            output.innerHTML = 'RUN';
            output.classList.add('running');
        }, //displayRun


        init = function(){
            resetBtn.addEventListener("click", function(){
                output.innerHTML = '';
                output.classList.remove("running");
            });

            runBtn.addEventListener("click", function(){
                displayRun();
            });

            myForm.addEventListener("keyup", function(e){
               if(e.target.nodeName.toLowerCase() === 'textarea'){
                   output.innerHTML = e.target.value;
                   output.classList.remove("running");
                   if(e.target.value === 'run'){
                       e.target.dispatchEvent(runEvent);
                   }
               }
            });

            document.addEventListener("runEvent", function(e){
               console.log(e);
                displayRun();
            });

        }//init
    ;


    window.onload = init;
})();
