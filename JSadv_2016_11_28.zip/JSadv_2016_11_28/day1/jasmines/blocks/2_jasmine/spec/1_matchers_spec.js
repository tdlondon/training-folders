/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 2_jasmine
 * spec         : 1_matchers_spec
 * { exercises on bottom }
 **/




describe("Quick list of matchers", function() {
    it('.toBe() is like "===" ', function(){
        var a = '1';
        expect(a).toBe('1');
    });

    it('every matcher can be chained to .not', function(){
        var a = '1';
        expect(a).not.toBe(1);
    });

    it('you can also compare using .toEqual()', function(){
        var a = '1', b = '1';
        expect(a).not.toEqual(1);
        expect(a).toEqual('1');
        expect(a).toEqual(b);
    });

    it('compare booleans using .toBeTruthy() or .toBeFalsy()', function(){
        var a = 1, b = '1';
        expect(a == b).toBeTruthy();
        expect(a === b).toBeFalsy();
    });

    it('compare against `undefined` using .toBeDefined() or .toBeUndefined()', function(){
        var obj = {a : 123, c : 'abc'} ;

        expect(obj.a).toBeDefined();
        expect(obj.b).not.toBeDefined();

        expect(obj.b).toBeUndefined();
        expect(obj.a).not.toBeUndefined();

        //explain this
        expect(typeof obj.b).toBeDefined();
    });

    it('compare against `null` using .toBeNull()', function(){
        var obj = {a : null, c : 'abc'} ;

        expect(null).toBeNull();
        expect(obj.a).toBeNull();
        expect(obj.b).not.toBeNull();
        expect(obj.c).not.toBeNull();
    });

    it('compare against `NaN` using .toBeNaN()', function(){

        expect(NaN).toBeNaN();
        expect(3).not.toBeNaN();
        expect(Infinity - Infinity).toBeNaN();
        expect(3 / "abc").toBeNaN();

        expect(NaN).not.toBe(NaN);

        //how do we compare NaN????
        expect(NaN).toEqual(NaN);
    });

    it('use .toContain() to find elements in an array', function(){
        var arr = [1, 2, 3];
        expect(arr).toContain(3);
        expect(arr).not.toContain(5);
        //doez not work with objects!
    });

    it('use .toBeGreaterThan() and .toBeLessThan() for mathematical comparison', function(){
        expect(5).toBeGreaterThan(3);
        expect(4).not.toBeLessThan(2);
    });

    it('use .toThrow() to test functions', function(){
        var
            foo1 = function(){return 'a'+' string';},
            foo2 = function(){return  a +' string';}
        ;
        expect(foo1).not.toThrow();
        expect(foo2).toThrow();
    });
});


//beforeEach() and afterEach()


describe("using beforeEach()", function() {
    var a;
    beforeEach(function() {
        a = 0;
        a += 1;
    });

    it("here we will see effects of beforeEach()", function() {
        expect(a).toEqual(1);
        a = 3;
        expect(a).toEqual(3);
    });

    it("...same here", function() {
        expect(a).toEqual(1);
    });
});


describe("using afterEach()", function() {
    var a = 0;

    beforeEach(function(){
       a += 1;
    });

    afterEach(function(){
        a = 0;
    });

    it("normal spec", function() {
        expect(a).toEqual(1);
    });

    it("here you see effect of afterEach()", function() {
        expect(a).toEqual(1);
    });
});




/**
 * =====================================================
 * {create a single suite with a spec for each exercise}
 * =====================================================
 */


/**
 * EXERCISE 1
 * prove that 'abc' is a String (use typeof)
 */





/**
 * EXERCISE 2
 * crete a faulty function and make sure it throws exceptions
 */





/**
 * EXERCISE 3
 * test if two entities are identical
 */






/**
 * EXERCISE 4
 * test 0 as a boolean
 */






/**
 * EXERCISE 5
 * test if a property is null
 */






/**
 * EXERCISE 6
 * var arr = ['a', 'b', 'c', [1,2,3,5] , 'e' ];
 * test whether arr contains 4
 */







/**
 * EXERCISE 7
 * prove that a value is not NaN
 */




