/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 2_jasmine
 * spec         : 0_jasmine_spec
 **/

describe("This is a suite", function() {
    //here our specs
});


xdescribe("This is a suite with specs", function() {
    xit('hi, I am a spec', function(){
        //here some code and expectations
    });

    xit('I am another spec', function(){
        //here some code and expectations
    });
});



xdescribe("This is a suite with specs and expectations - I", function() {
    xit('hi, I am a spec with some code and an expectation', function(){
        var
            a = 123,
            arr = [1,2,3]
        ;
        expect('this is an expectation').toBeTruthy();
    });
});


xdescribe("This is a suite with specs and expectations - II", function() {
    xit('specs can have multiple expectations', function(){
        expect('this is an expectation').toBeTruthy();
        expect('this is another expectation').toBeTruthy();
        expect('').not.toBeTruthy();
        expect('one last expectation').not.toBeFalsy();
    });
});


xdescribe("This is a suite with specs and expectations - III", function() {
    xit('here a failing expectation', function(){
        expect('this is an expectation').not.toBeTruthy();
    });
});