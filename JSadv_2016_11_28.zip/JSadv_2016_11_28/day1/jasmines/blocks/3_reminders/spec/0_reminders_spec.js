/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 3_reminders
 * spec         : 0_reminders_spec
 **/




describe("primitive values are immutable", function() {
    it('cannot modify a string', function(){
        var a = 'abc';
        expect(a.toUpperCase()).toBe('ABC');
        expect(a).not.toBe('ABC');
    });

    it('cannot modify a number', function(){
        var a = 123;
        expect(a.toString()).toBe('123');
        expect(a).not.toBe('123');
    });
});


describe("Infinity and -Infinity", function() {
    it('Infinity is a number', function(){
        expect(typeof Infinity).toBe('number');
        expect(Infinity).toBe(1e309);
        expect(Math.pow(10,309)).toBe(Infinity);
    });

    it('cannot calculate Infinity - Infinity', function(){
        expect(Infinity - Infinity).toBeNaN();
    });

    it('dividing numbers by 0 returns Infinity', function(){
        expect(3/0).toBe(Infinity);
    });
});

describe("NaN", function() {
    it('NaN is a number', function(){
        expect(typeof Infinity).toBe('number');
        expect(parseInt('abc', 10)).toBeNaN();
    });

    it('other NaN samples', function(){
        expect(4/'a').toBeNaN();
        expect(parseInt('abc', 10)).toBeNaN();
    });

    it('NaN is the only value that is not identical to itself', function(){
        expect(NaN).not.toBe(NaN);
    });
});

describe("testing NaN - I", function() {
    it('we can use isNaN()...', function(){
        expect(isNaN(NaN)).toBe(true);
    });

    it('...but it can return false positives!', function(){
        expect(isNaN('abc')).toBe(true);
    });
});

describe("testing NaN - II", function() {
    it('we can test if it is NOT identical to itself', function(){
        var myTestNaN = function(val){
            return val !== val;
        };
        expect(myTestNaN(NaN)).toBe(true);
        expect(myTestNaN('abc')).not.toBe(true);
    });

    it('...or we can use Number.isNaN()', function(){
        expect(Number.isNaN(3/'a')).toBe(true);
        expect(Number.isNaN('abc')).not.toBe(true);
    });
});

describe("difference between undefined and not defined", function() {
    var a = undefined, b;
    it('a var can exist and have a value of undefined...', function(){
        expect(a).toBeUndefined();
    });

    it('...a var can exist and have no value, data type of undefined...', function(){
        expect(b).toBeUndefined();
    });

    xit('...or it can be `not defined` ', function(){
        expect(c).toBe(undefined);
    });
});


describe("guard operator &&", function() {
    var a = 123, b = 'abc', c, d = null;
    it('returns right operand if left one is true', function(){
        expect(a && b).toBe(b);
    });

    it('return left operand if falsy', function(){
        expect(c && b).toBe(c);
    });

    it('quick sample', function(){
        var
            logged = false,
            username = 'james',
            getUsername = function(){
                return logged && username;
            }
        ;
        expect(getUsername()).toBe(false);
    });
});

describe("default operator ||", function() {
    var a = undefined, b = null, c = 123, d = 'abc';
    it('returns left operand if true', function(){
        expect(c || a).toBe(c);
    });

    it('returns right operand if left one is falsy', function(){
        expect(a || d).toBe(d);
    });

    it('moves on on falsy, null, undefined', function(){
        expect(a || b || false || c).toBe(c);
    });
});


describe("simple test - I", function() {
    var a = 123;
    it('returns value of a', function(){
        expect(a).toBe(123);
    });
});


describe("simple test - II", function() {
    var a = 123;
    it('including a local var', function(){
        var a = 555;
        expect(a).not.toBe(123);
        expect(a).toBe(555);
    });
});


describe("var hoisting - I", function() {
    var a = 123;
    it('why on earth a is now undefined?', function(){
        expect(a).not.toBe(123);
        expect(a).not.toBe(555);
        expect(a).toBeUndefined();
        var a = 555;
    });
});

describe("var hoisting - II", function() {
    var a = 123;
    it('hey, look at the last one here!', function(){
        expect(a).not.toBe(123);
        expect(a).not.toBe(555);
        expect(a).toBeUndefined();
        var a = 555;
        expect(a).toBe(555);
    });
});
