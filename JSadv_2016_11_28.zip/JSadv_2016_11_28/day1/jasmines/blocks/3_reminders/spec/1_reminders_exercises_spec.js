/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 3_reminders
 * spec         : 1_reminders_exercises_spec
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("reminders exercises - I", function() {
    xit('tricky values', function(){
        expect(Infinity === Infinity).toBe(__);         //
        expect(NaN === NaN).toBe(__);                   //
        expect(1*Math.pow(10,309)).toBe(__);            //
        expect(typeof 'undefined').toBe(__);            //
        expect(undefined === undefined).toBe(__);       //
        expect(NaN).toEqual(__);                        //
        expect(Infinity * -Infinity).toEqual(__);       //
        expect(Infinity / -Infinity).toEqual(__);       //
        expect(typeof NaN).toBe(__)                     //
        expect(typeof null).toBe(__)                    //
        expect(1e200 - 1*Math.pow(10,309)).toBe(__);    //
    });
});



/**
 * notes:
 *
 **/
describe("reminders exercises - II", function() {
    xit('conversion', function(){
        var
            a = 'ff',
            convertToRgb = function(val){
                //implement to pass test
                //convert ff into 255
                //integer with radix 16
                return ;
            }
        ;

        expect(convertToRgb(a)).toBe(255);      //
    });
});



/**
 * notes:
 *
 **/
describe("reminders exercises - III", function() {
    xit('default and guard operators', function(){
        var
            a = 'ff',
            b = null,
            c = 123,
            d,
            e = false,
            f = true,
            g = ''
        ;

        expect(a || b).toBe(__);                    //
        expect(d && f).toBe(__);                    //
        expect(a || b && g).toBe(__);               //
        expect(g && c && f && a && b).toBe(__);     //
    });
});



/**
 * notes:
 *
 **/
describe("reminders exercises - IV", function() {
    xit('vars', function(){
        var a = 123, b = [1,2,3] ;

        (function(){
            var
                c = a++,
                d = b;
            ;
            b[1] += 15;

            expect(a).toBe(__);             //
            expect(b).toEqual(__);          //
            expect(c).toBe(__);             //
            expect(d[1]).toBe(__);          //
        })();

    });
});


/**
 * notes:
 *
 **/
describe("reminders exercises - V", function() {
    xit('throw, try... catch... finally', function(){
        var a = 123, b = [1,2,3] ;

        try{
            //trow an error using an object
            //...
            //end throw statement
            var b = 'new value';            //
        } catch(e){
            expect(e.name).toBe(__);        //
            expect(e.message).toBe(__);     //
            expect(b).toEqual(__);          //
        } finally{
            expect(b).toEqual(__);          //
            expect(typeof e).toBe(__);      //
            a++;
        }
        expect(a).toBe(__);                 //
    });
});
