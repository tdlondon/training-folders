<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/admin.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
<?php include("../includes/adminNav.php");?>

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <?php include("../includes/feedback.php");?>
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
                    <section class="login">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Log in to access</h2>
                        <form method="post" action="#" class="loginForm flexCont">
                            <div class="formCol emailCol">
                                <label for="logEmail">Email</label>
                                <input class="formField" type="email" id="logEmail" name="logEmail" value="">
                            </div>
                            <div class="formCol pswCol">
                                <label for="logPsw">Password</label>
                                <input class="formField" type="password" id="logPsw" name="logPsw" value="">
                                <button type="submit" name="login" class=" btn ckBtn smBtn blueBtn">LOG IN</button>
                            </div>
                        </form><!--/loginForm-->
                    </section><!--/login-->

                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php");?>

</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>

