<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/viewUsers.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">View users</h2>
                        
                        <div class="itemsBlock">
                            <div class="itemLabelsBlock flexCont">
                                <div class="itemLabel uIDLabel">id</div>
                                <div class="itemLabel uNameLabel">Name</div>
                                <div class="itemLabel uLastLabel">Last</div>
                                <div class="itemLabel uEmailLabel">Email</div>
                                <div class="itemLabel uPswLabel">Psw</div>
                                <div class="itemLabel uAddr1Label">Addr1</div>
                                <div class="itemLabel uAddr2Label">Addr2</div>
                                <div class="itemLabel uCodeLabel">Code</div>
                                <div class="itemLabel uCityLabel">City</div>
                                <div class="itemLabel uCountryLabel">Country</div>
                                <div class="itemLabel uPhoneLabel">Phone</div>
                            </div><!--/itemLabels-->

                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox vCentre uIDBox">
                                    <p>1</p>
                                </div><!--/uIDBox-->

                                <div class="itemBox vCentre uNameBox">
                                    <p>John</p>
                                </div><!--/uNameBox-->

                                <div class="itemBox vCentre uLastBox">
                                    <p>Doe</p>
                                </div><!--/uLastBox-->

                                <div class="itemBox vCentre uEmailBox">
                                    <p>j@email.com</p>
                                </div><!--/uEmailBox-->

                                <div class="itemBox vCentre uPswBox">
                                    <p>psw</p>
                                </div><!--/uPswBox-->

                                <div class="itemBox vCentre uAddr1Box">
                                    <p>ad1</p>
                                </div><!--/uAddr1Box-->

                                <div class="itemBox vCentre uAddr2Box">
                                    <p>ad2</p>
                                </div><!--/uAddr2Box-->

                                <div class="itemBox vCentre uCodeBox">
                                    <p>a1b23</p>
                                </div><!--/uCodeBox-->

                                <div class="itemBox vCentre uCityBox">
                                    <p>London</p>
                                </div><!--/uCityBox-->

                                <div class="itemBox vCentre uCountryBox">
                                    <p>GB</p>
                                </div><!--/uCountryBox-->

                                <div class="itemBox vCentre uPhoneBox">
                                    <p>09877893316</p>
                                </div><!--/uPhoneBox-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="user.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item =======================================================-->

                            <!--DELETE FROM HERE =================================-->
                            <div class="item flexCont">
                                <div class="itemBox vCentre uIDBox">
                                    <p>2</p>
                                </div><!--/uIDBox-->

                                <div class="itemBox vCentre uNameBox">
                                    <p>Jane</p>
                                </div><!--/uNameBox-->

                                <div class="itemBox vCentre uLastBox">
                                    <p>Smith</p>
                                </div><!--/uLastBox-->

                                <div class="itemBox vCentre uEmailBox">
                                    <p>s@email.com</p>
                                </div><!--/uEmailBox-->

                                <div class="itemBox vCentre uPswBox">
                                    <p>psw</p>
                                </div><!--/uPswBox-->

                                <div class="itemBox vCentre uAddr1Box">
                                    <p>ad1</p>
                                </div><!--/uAddr1Box-->

                                <div class="itemBox vCentre uAddr2Box">
                                    <p>ad2</p>
                                </div><!--/uAddr2Box-->

                                <div class="itemBox vCentre uCodeBox">
                                    <p>a1b23</p>
                                </div><!--/uCodeBox-->

                                <div class="itemBox vCentre uCityBox">
                                    <p>London</p>
                                </div><!--/uCityBox-->

                                <div class="itemBox vCentre uCountryBox">
                                    <p>GB</p>
                                </div><!--/uCountryBox-->

                                <div class="itemBox vCentre uPhoneBox">
                                    <p>09877893316</p>
                                </div><!--/uPhoneBox-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="user.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->


                            <div class="item flexCont">
                                <div class="itemBox vCentre uIDBox">
                                    <p>3</p>
                                </div><!--/uIDBox-->

                                <div class="itemBox vCentre uNameBox">
                                    <p>Bob</p>
                                </div><!--/uNameBox-->

                                <div class="itemBox vCentre uLastBox">
                                    <p>Builder</p>
                                </div><!--/uLastBox-->

                                <div class="itemBox vCentre uEmailBox">
                                    <p>b@email.com</p>
                                </div><!--/uEmailBox-->

                                <div class="itemBox vCentre uPswBox">
                                    <p>psw</p>
                                </div><!--/uPswBox-->

                                <div class="itemBox vCentre uAddr1Box">
                                    <p>ad1</p>
                                </div><!--/uAddr1Box-->

                                <div class="itemBox vCentre uAddr2Box">
                                    <p>ad2</p>
                                </div><!--/uAddr2Box-->

                                <div class="itemBox vCentre uCodeBox">
                                    <p>a1b23</p>
                                </div><!--/uCodeBox-->

                                <div class="itemBox vCentre uCityBox">
                                    <p>London</p>
                                </div><!--/uCityBox-->

                                <div class="itemBox vCentre uCountryBox">
                                    <p>GB</p>
                                </div><!--/uCountryBox-->

                                <div class="itemBox vCentre uPhoneBox">
                                    <p>09877893316</p>
                                </div><!--/uPhoneBox-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="user.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->


                            <!--DELETE UP TO HERE=======================================================-->

                        </div><!--/itemsBlock-->


                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>

<?php include ("../includes/footer.php");?>
</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>