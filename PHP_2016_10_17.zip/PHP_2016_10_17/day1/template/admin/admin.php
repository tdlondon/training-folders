<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | ADMIN</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="../build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="../build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
    <meta name="description" content="php project search"/>
    <meta name="keywords" content="search keywords"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="../build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="../search.php">search</a></li>
                        <li><a href="../contacts.php">contacts</a></li>
                        <li><a class="currentPageLink" href="admin.php">admin</a></li>
                        <li><a href="basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="adminNavBlock">
                <div class="container">
                    <section class="welcome">
                        <div class="redDash"></div>
                        <h2 class="welcomeTitle">Welcome back, John!</h2>
                    </section><!--/welcome-->

                    <nav class="adminNav">
                        <ul class="flexCont">
                            <li><a class="ckBtn" href="viewProducts.php">view products</a></li>
                            <li><a class="ckBtn" href="product.php">add product</a></li>
                            <li><a class="ckBtn" href="viewUsers.php">view users</a></li>
                            <li><a class="ckBtn" href="user.php">add user</a></li>
                            <li><a class="ckBtn" href="viewPages.php">view pages</a></li>
                            <li><a class="ckBtn" href="page.php">add pages</a></li>
                            <li><a class="ckBtn" href="#">log out</a></li>
                        </ul>
                    </nav>
                </div>   <!--/container-->
            </section><!--/adminNavBlock-->

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success</div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
                    <section class="login">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Log in to access</h2>
                        <form method="post" action="#" class="loginForm flexCont">
                            <div class="formCol emailCol">
                                <label for="logEmail">Email</label>
                                <input class="formField" type="email" id="logEmail" name="logEmail" value="">
                            </div>
                            <div class="formCol pswCol">
                                <label for="logPsw">Password</label>
                                <input class="formField" type="password" id="logPsw" name="logPsw" value="">
                                <button type="submit" name="login" class=" btn ckBtn smBtn blueBtn">LOG IN</button>
                            </div>
                        </form><!--/loginForm-->
                    </section><!--/login-->

                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="../index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="../search.php">Search</a> |
                        <a href="../contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>
</body>
</html>