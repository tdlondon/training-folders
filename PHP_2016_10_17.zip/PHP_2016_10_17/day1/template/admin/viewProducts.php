<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | VIEW PRODUCTS</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="../build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="../build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="../build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="../search.php">search</a></li>
                        <li><a href="../contacts.php">contacts</a></li>
                        <li><a href="admin.php">admin</a></li>
                        <li><a href="basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="adminNavBlock">
                <div class="container">
                    <section class="welcome">
                        <div class="redDash"></div>
                        <h2 class="welcomeTitle">Welcome back, John!</h2>
                    </section><!--/welcome-->

                    <nav class="adminNav">
                        <ul class="flexCont">
                            <li><a class="ckBtn activeLink" href="viewProducts.php">view products</a></li>
                            <li><a class="ckBtn" href="product.php">add product</a></li>
                            <li><a class="ckBtn" href="viewUsers.php">view users</a></li>
                            <li><a class="ckBtn" href="user.php">add user</a></li>
                            <li><a class="ckBtn" href="viewPages.php">view pages</a></li>
                            <li><a class="ckBtn" href="page.php">add pages</a></li>
                            <li><a class="ckBtn" href="#">log out</a></li>
                        </ul>
                    </nav>
                </div>   <!--/container-->
            </section><!--/adminNavBlock-->

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success</div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">View products</h2>
                        
                        <div class="itemsBlock">
                            <div class="itemLabelsBlock flexCont">
                                <div class="itemLabel pIDLabel">id</div>
                                <div class="itemLabel pNameLabel">name</div>
                                <div class="itemLabel pPriceLabel">price</div>
                                <div class="itemLabel pDescLabel">description</div>
                                <div class="itemLabel pShippLabel">shipping</div>
                                <div class="itemLabel pImageLabel">image</div>
                            </div><!--/itemLabels-->

                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox vCentre pIDBox">
                                    <p>1</p>
                                </div><!--/pID-->

                                <div class="itemBox vCentre pNameBox">
                                    <p>iPhone</p>
                                </div><!--/pName-->

                                <div class="itemBox vCentre pPriceBox">
                                    <p>&pound;900.00</p>
                                </div><!--/pPrice-->

                                <div class="itemBox vCentre pDescBox">
                                    <p>new iPhone 7</p>
                                </div><!--/pDesc-->

                                <div class="itemBox vCentre pShippBox">
                                    <p>&pound;20.00</p>
                                </div><!--/pShipp-->

                                <div class="itemBox vCentre pImageBox">
                                    <img src="../build/imgs/sample_products/iphone.jpg" width="75" height="75" title="iPhone" alt="iPhone">
                                </div><!--/pImage-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="product.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item =======================================================-->

                            <!--DELETE FROM HERE =================================-->
                            <div class="item flexCont">
                                <div class="itemBox vCentre pIDBox">
                                    <p>2</p>
                                </div><!--/pID-->

                                <div class="itemBox vCentre pNameBox">
                                    <p>servo motor</p>
                                </div><!--/pName-->

                                <div class="itemBox vCentre pPriceBox">
                                    <p>&pound;3.00</p>
                                </div><!--/pPrice-->

                                <div class="itemBox vCentre pDescBox">
                                    <p>Parallax Inc</p>
                                </div><!--/pDesc-->

                                <div class="itemBox vCentre pShippBox">
                                    <p>&pound;1.00</p>
                                </div><!--/pShipp-->

                                <div class="itemBox vCentre pImageBox">
                                    <img src="../build/imgs/sample_products/servo.jpg" width="75" height="75" title="servo" alt="iPhone">
                                </div><!--/pImage-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="product.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->


                            <div class="item flexCont">
                                <div class="itemBox vCentre pIDBox">
                                    <p>3</p>
                                </div><!--/pID-->

                                <div class="itemBox vCentre pNameBox">
                                    <p>Chassis</p>
                                </div><!--/pName-->

                                <div class="itemBox vCentre pPriceBox">
                                    <p>&pound;9.00</p>
                                </div><!--/pPrice-->

                                <div class="itemBox vCentre pDescBox">
                                    <p>chassis for arduino projects</p>
                                </div><!--/pDesc-->

                                <div class="itemBox vCentre pShippBox">
                                    <p>&pound;2.00</p>
                                </div><!--/pShipp-->

                                <div class="itemBox vCentre pImageBox">
                                    <img src="../build/imgs/sample_products/chassis.jpg" width="75" height="75" title="chassis" alt="iPhone">
                                </div><!--/pImage-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="product.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->



                            <!--DELETE UP TO HERE=======================================================-->

                        </div><!--/itemsBlock-->


                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="../index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="../search.php">Search</a> |
                        <a href="../contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>
</body>
</html>