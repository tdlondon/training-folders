<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | VIEW USERS</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="../build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="../build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="../build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="../search.php">search</a></li>
                        <li><a href="../contacts.php">contacts</a></li>
                        <li><a href="admin.php">admin</a></li>
                        <li><a href="basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="adminNavBlock">
                <div class="container">
                    <section class="welcome">
                        <div class="redDash"></div>
                        <h2 class="welcomeTitle">Welcome back, John!</h2>
                    </section><!--/welcome-->

                    <nav class="adminNav">
                        <ul class="flexCont">
                            <li><a class="ckBtn" href="viewProducts.php">view products</a></li>
                            <li><a class="ckBtn" href="user.php">add product</a></li>
                            <li><a class="ckBtn activeLink" href="viewUsers.php">view users</a></li>
                            <li><a class="ckBtn" href="user.php">add user</a></li>
                            <li><a class="ckBtn" href="viewPages.php">view pages</a></li>
                            <li><a class="ckBtn" href="page.php">add pages</a></li>
                            <li><a class="ckBtn" href="#">log out</a></li>
                        </ul>
                    </nav>
                </div>   <!--/container-->
            </section><!--/adminNavBlock-->

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success</div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">View users</h2>
                        
                        <div class="itemsBlock">
                            <div class="itemLabelsBlock flexCont">
                                <div class="itemLabel uIDLabel">id</div>
                                <div class="itemLabel uNameLabel">Name</div>
                                <div class="itemLabel uLastLabel">Last</div>
                                <div class="itemLabel uEmailLabel">Email</div>
                                <div class="itemLabel uPswLabel">Psw</div>
                                <div class="itemLabel uAddr1Label">Addr1</div>
                                <div class="itemLabel uAddr2Label">Addr2</div>
                                <div class="itemLabel uCodeLabel">Code</div>
                                <div class="itemLabel uCityLabel">City</div>
                                <div class="itemLabel uCountryLabel">Country</div>
                                <div class="itemLabel uPhoneLabel">Phone</div>
                            </div><!--/itemLabels-->

                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox vCentre uIDBox">
                                    <p>1</p>
                                </div><!--/uIDBox-->

                                <div class="itemBox vCentre uNameBox">
                                    <p>John</p>
                                </div><!--/uNameBox-->

                                <div class="itemBox vCentre uLastBox">
                                    <p>Doe</p>
                                </div><!--/uLastBox-->

                                <div class="itemBox vCentre uEmailBox">
                                    <p>j@email.com</p>
                                </div><!--/uEmailBox-->

                                <div class="itemBox vCentre uPswBox">
                                    <p>psw</p>
                                </div><!--/uPswBox-->

                                <div class="itemBox vCentre uAddr1Box">
                                    <p>ad1</p>
                                </div><!--/uAddr1Box-->

                                <div class="itemBox vCentre uAddr2Box">
                                    <p>ad2</p>
                                </div><!--/uAddr2Box-->

                                <div class="itemBox vCentre uCodeBox">
                                    <p>a1b23</p>
                                </div><!--/uCodeBox-->

                                <div class="itemBox vCentre uCityBox">
                                    <p>London</p>
                                </div><!--/uCityBox-->

                                <div class="itemBox vCentre uCountryBox">
                                    <p>GB</p>
                                </div><!--/uCountryBox-->

                                <div class="itemBox vCentre uPhoneBox">
                                    <p>09877893316</p>
                                </div><!--/uPhoneBox-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="user.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item =======================================================-->

                            <!--DELETE FROM HERE =================================-->
                            <div class="item flexCont">
                                <div class="itemBox vCentre uIDBox">
                                    <p>2</p>
                                </div><!--/uIDBox-->

                                <div class="itemBox vCentre uNameBox">
                                    <p>Jane</p>
                                </div><!--/uNameBox-->

                                <div class="itemBox vCentre uLastBox">
                                    <p>Smith</p>
                                </div><!--/uLastBox-->

                                <div class="itemBox vCentre uEmailBox">
                                    <p>s@email.com</p>
                                </div><!--/uEmailBox-->

                                <div class="itemBox vCentre uPswBox">
                                    <p>psw</p>
                                </div><!--/uPswBox-->

                                <div class="itemBox vCentre uAddr1Box">
                                    <p>ad1</p>
                                </div><!--/uAddr1Box-->

                                <div class="itemBox vCentre uAddr2Box">
                                    <p>ad2</p>
                                </div><!--/uAddr2Box-->

                                <div class="itemBox vCentre uCodeBox">
                                    <p>a1b23</p>
                                </div><!--/uCodeBox-->

                                <div class="itemBox vCentre uCityBox">
                                    <p>London</p>
                                </div><!--/uCityBox-->

                                <div class="itemBox vCentre uCountryBox">
                                    <p>GB</p>
                                </div><!--/uCountryBox-->

                                <div class="itemBox vCentre uPhoneBox">
                                    <p>09877893316</p>
                                </div><!--/uPhoneBox-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="user.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->


                            <div class="item flexCont">
                                <div class="itemBox vCentre uIDBox">
                                    <p>3</p>
                                </div><!--/uIDBox-->

                                <div class="itemBox vCentre uNameBox">
                                    <p>Bob</p>
                                </div><!--/uNameBox-->

                                <div class="itemBox vCentre uLastBox">
                                    <p>Builder</p>
                                </div><!--/uLastBox-->

                                <div class="itemBox vCentre uEmailBox">
                                    <p>b@email.com</p>
                                </div><!--/uEmailBox-->

                                <div class="itemBox vCentre uPswBox">
                                    <p>psw</p>
                                </div><!--/uPswBox-->

                                <div class="itemBox vCentre uAddr1Box">
                                    <p>ad1</p>
                                </div><!--/uAddr1Box-->

                                <div class="itemBox vCentre uAddr2Box">
                                    <p>ad2</p>
                                </div><!--/uAddr2Box-->

                                <div class="itemBox vCentre uCodeBox">
                                    <p>a1b23</p>
                                </div><!--/uCodeBox-->

                                <div class="itemBox vCentre uCityBox">
                                    <p>London</p>
                                </div><!--/uCityBox-->

                                <div class="itemBox vCentre uCountryBox">
                                    <p>GB</p>
                                </div><!--/uCountryBox-->

                                <div class="itemBox vCentre uPhoneBox">
                                    <p>09877893316</p>
                                </div><!--/uPhoneBox-->

                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="user.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->


                            <!--DELETE UP TO HERE=======================================================-->

                        </div><!--/itemsBlock-->


                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="../index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="../search.php">Search</a> |
                        <a href="../contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>
</body>
</html>