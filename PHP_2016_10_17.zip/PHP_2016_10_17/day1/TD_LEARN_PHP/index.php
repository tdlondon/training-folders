<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>TrainingDragon | learn PHP</title>
<link rel="stylesheet" type="text/css" href="assets/css/style.css" />
<link rel="shortcut icon" href="http://www.coursemixer.com/favicon.ico" />
<script src="assets/js/jquery-1.11.1.min.js"></script>
<script src="assets/js/main.js"></script>
</head>

<body>
	<div id="wrapper">
    	<div id="header" class="fullw">
        	TD - learn PHP
        </div><!--/header-->



    	<div id="main" class="inner">
            <div id="nav">
                <ul>
                    <li><a href="#s0">0. PHP</a></li>
                    <li><a href="#s1">1. PHP tag</a></li>
                    <li><a href="#s2">2. PHP COMMENTS</a></li>
                    <li><a href="#s3">3. OUTPUT IN PHP</a></li>
                    <li><a href="#s4">4. PHP VARIABLES</a></li>
                    <li><a href="#s5">5. DATA TYPES</a></li>
                    <li><a href="#s51">---5.1 Scalar Data Types</a></li>
                    <li><a href="#s5x">---5.X PHP OPERATORS</a></li>
                    <li><a href="#s52">---5.2 Compound Data Types</a></li>
                    <li><a href="#s6">6. ARRAYS</a></li>
                    <li><a href="#s61">---6.1 Indexed Arrays</a></li>
                    <li><a href="#s62">---6.2. Associative Arrays</a></li>
                    <li><a href="#s63">---6.3 MultiDimensional Arrays</a></li>
                    <li><a href="#s7">7. IF STATEMENTS</a></li>
                    <li><a href="#s8">8. SWITCH STATEMENTS</a></li>
                    <li><a href="#s9">9. LOOPS</a></li>
                    <li><a href="#s91">---9.1 FOR Loops</a></li>
                    <li><a href="#s92">---9.2 Loop Through Arrays</a></li>
                    <li><a href="#s93">---9.3 FOREACH Loops To Loop Through Arrays</a></li>
                    <li><a href="#s94">---9.4 Displaying The Content Of Compound Data Types</a></li>
                    <li><a href="#s10">10. FUNCTIONS</a></li>
                    <li><a href="#s11">11. CUSTOM FUNCTIONS</a></li>
                    <li><a href="#s111">---11.1 Functions With Arguments</a></li>
                    <li><a href="#s112">---11.2 Functions That Return Values</a></li>
                    <li><a href="#s113">---11.3 Custom Functions Documentation (PHPDoc)</a></li>
                    <li><a href="#s114">---11.4 GLOBAL Vs LOCAL Variables</a></li>
                    <li><a href="#s12">12. INBUILT FUNCTIONS</a></li>
                    <li><a href="#s13">13. SERVER SIDE INCLUDES (SSI)</a></li>
                </ul>
            </div><!--nav-->
            <hr>

            <h2 id="s0" class="secTitle">0. PHP</h2>
            <p>
                PHP stands for Php Hypertext Preprocessor. It is a server-side language we use to communicate with a DataBase,
                create markup dynamically, process data and much more.
            </p>

            <h2 id="s1" class="secTitle">1. PHP TAG</h2>
            <p>to write php code, we need to wrap it in between <strong>php tags</strong></p>

<pre>
&lt;?php some php code here  ?>
</pre>

<div class="phpTest">.
</div><!--/phpTest-->

            <h2 id="s2" class="secTitle">2. PHP COMMENTS</h2>
            <p>to write php code, we need to wrap it in between <strong>php tags</strong></p>
<pre>
&lt;?php
    // this is a single line comment

    #  this is another way to create single line comments

    /*
        this is
        a multiline
        PHP comment
    */
?>
</pre>

<div class="phpTest">.
</div><!--/phpTest-->


            <h2 id="s3" class="secTitle">3. OUTPUT IN PHP</h2>
            <p>the easiest way to output in php is to use the ECHO construct</p>

<pre>
&lt;?php
    // output with echo
    echo 'this is some text generated with PHP.';
?>
</pre>

<div class="phpTest">.
</div><!--/phpTest-->


            <h2 id="s4" class="secTitle">4. PHP VARIABLES</h2>
            <p>variables are containers we use to store data, pieces of memory we allocate to store information.</p>
<pre>
&lt;?php
// php vars

/*
    STEP 1: var declaration
    $varName = value;

    STEP 2: usage
    echo $varName;

    VAR NAMES:
    * are case sensitive
    * always start with $
    * contain letters, numbers, _
    * cannot start with a number
*/
?>

            * interpolation     * concatenation      * escaping chars
</pre>

<div class="phpTest">.
</div><!--/phpTest-->



                <h2 id="s5" class="secTitle">5. DATA TYPES</h2>
                <h2 id="s51" class="childTitle secTitle">5.1 scalar data types</h2>
                <ul>
                    <li> * strings</li>
                    <li> * integers</li>
                    <li> * float / double</li>
                    <li> * booleans</li>
                    <li> * null</li>
                </ul>


<pre>
    $myString   = ...;
    $myInteger  = ...;
    $myFloat    = ...;
    $myBoolean  = ...;
    $myNull     = ...;

    echo "&lt;p>$myString&lt;/p>";
    echo "&lt;p>$myInteger&lt;/p>";
    echo "&lt;p>$myFloat&lt;/p>";
    echo "&lt;p>$myBoolean&lt;/p>";
    echo "&lt;p>$myNull&lt;/p>";
    echo "&lt;p>$myUndefined&lt;/p>";
</pre>

<div class="phpTest">.
</div><!--/phpTest-->


                <h2 id="s5x" class="secTitle childTitle">5.x PHP OPERATORS</h2>
<pre>

    #### MATH operators ####
    + 	add
    -	subtract
    *	multiply
    /	divide
    %	modulus => remainder of a division


    #### SIMPLE ASSIGNMENT operator
    $var = value

    #### COMPOUND ASSIGNMENT operators
    +=
    -=
    *=
    /=
    .=


    ##### PRE/POST INCREMENT-DECREMENT (by 1) OPERATORS
    $a++    ++$a
    $a--    --$a


    #### COMPARISON OPERATORS
    (always return booleans)

    ==			=> is actually equals to (comparing values)
    ===			=> is identical to (comparing values and type)

    != 			=> not equals
    !== 		=> not identical


    5 == '5' 	true
    5 === '5'	false


    $a = $b 	=> ASSIGNING $b to $a
    $a == $b	=> COMPARING two values

    >			=> greater than
    <			=> less than

    >=			=> greater than or equals
    <=			=> less than or equals


    #### LOGICAL OPERATORS (always return booleans)

    ! 	=> NOT
    && 	=> AND
    || 	=> OR

</pre>

<div class="phpTest">.
</div><!--/phpTest-->



                <h2 id="s52" class="secTitle childTitle">5.2 compound data types</h2>
                <p>compound data types can store multiple values, in different ways</p>
                <ul>
                    <li> * arrays</li>
                    <li> * objects</li>
                    <li> * resources</li>
                </ul>



                <h2 id="s6" class="secTitle">6. ARRAYS</h2>
                <p>an ARRAY is a comma separated LIST of values. There are several types of arrays:</p>
                <ul>
                    <li> * indexed arrays</li>
                    <li> * associative arrays</li>
                    <li> * multidimensional arrays</li>
                </ul>

                <h2 id="s61" class="secTitle childTitle">6.1 indexed arrays</h2>
<pre>
&lt;?php
    ### ARRAYS ###
    /*
        step 1) array declaration
        $arrName = array(val, val, val, ...);
        indexes		  0    1    2   ...


        step2) access values
        $arrName[index]

    */
?>
</pre>
<div class="phpTest">.
</div><!--/phpTest-->

                <h2 id="s62" class="secTitle childTitle">6.2. associative arrays</h2>
                <p>Associative Arrays are comma separated lists of key/value pairs</p>
<pre>
&lt;?php
    ## associative array

    ## definition

    $associativeArr = array(
        key => value,
        key => value,
        ....
    );

    ## accessing values
    $associativeArr[key]
?>
</pre>
<div class="phpTest">.
</div><!--/phpTest-->

                    <h2 id="s63" class="secTitle childTitle">6.3 MultiDimensional arrays</h2>
                    <p>MultiDimensional Arrays are arrays that store other arrays</p>
<pre>
&lt;?php
    ## MultiDimensional array

    ## definition

    $associativeArr = array(
       array(val, val, val),
       array(val, val, val),
        ....
    );

    ## accessing values

    $associativeArr[index][index]

 * MD indexed arrays * MD associative arrays * company MD array exercise
?>
</pre>
<div class="phpTest">.
</div><!--/phpTest-->


<div class="phpTest">
<?php
    /**
    *	exercise in class
    *
    *	create a MD array
    *	called company
    *
    *	store 3 employees
    * 	for each employee store name, last, position
    *
    *	refer to employees with codes
    */
?>
</div><!--/phpTest-->




             <h2 id="s7" class="secTitle">7. IF STATEMENTS</h2>
<pre>
&lt;?php
/*
    IF STATEMENT

    if(condition){
        do something
    }

    ---------

    if(condition){
        do something
    } else {
        do something different
    }
    ---------

    if(condition1){
        do something
    } elseif(condition2) {
        do something different
    } else {
        do something else
    }
*/
?>
</pre>
            <div class="phpTest">.
            </div><!--/phpTest-->


            <h2 id="s8" class="secTitle">8. SWITCH STATEMENTS</h2>
            <p> * comparing some entity against multiple values</p>
            <p> * providing different cases / options</p>
<pre>
&lt;?php

    switch($variable){
        case 'value1':
            //do something if $variable == value1
        break;

        case 'value2':
            //do something if $variable == value2
        break;

        ...

        default:
            //do something as default
        break;
    }//end switch

?>
</pre>
<div class="phpTest">.
</div><!--/phpTest-->




<h2 id="s9" class="secTitle">9. LOOPS</h2>
<p>loops will execute a piece of code a certain no of times on the basis of a condition</p>
<p>loops automate repetitive actions</p>

<ul>
    <li> * for</li>
    <li> * foreach</li>
    <li> * while</li>
    <li> * do while</li>
</ul>

<h2 id="s91" class="secTitle childTitle">9.1 FOR loops</h2>
<pre>
 &lt;?php
    /*
    FOR
        for(
            1) initialise counter
            2) set a condition
            3) update counter
        ){
            code to repeat
        }//end for
    */
?>
</pre>
<div class="phpTest">.
</div><!--/phpTest-->




            <h2 id="s92" class="secTitle childTitle">9.2 loop through arrays</h2>
            <p>looping through arrays we can execute operations on all elements of an array</p>


            <div class="phpTest">.
            </div><!--/phpTest-->

            <h2 id="s93" class="secTitle childTitle">9.3 FOREACH loops to loop through arrays</h2>
            <div class="phpTest">
                <p>##### BLOG SIMULATION ####</p>
            </div><!--/phpTest-->


            <h2 id="s94" class="secTitle childTitle">9.4 Displaying the content of compound data types</h2>
<pre>
    * print_r()     * var_dump()
</pre>
<div class="phpTest">.
</div><!--/phpTest-->






                <h2 id="s10" class="secTitle">10. FUNCTIONS</h2>
                <p>Functions store pieces of logic we may want to execute</p>
                <p>There are two big group of functions</p>
                <ul>
                    <li> * custom functions</li>
                    <li> * inbuilt functions</li>
                </ul>

                <h2 id="s11" class="secTitle">11. CUSTOM FUNCTIONS</h2>
                <p>custom functions are created by developers following their own specific needs</p>
<pre>
  #### CUSTOM FUNCTIONS #####

    ## step1) FOO DECLARATION

    function fooName(){
        code to execute
    }//end fooName


    ## step2) foo INVOCATION
    fooName();
</pre>
<div class="phpTest">.
</div><!--/phpTest-->

            <h2 id="s111" class="secTitle childTitle">11.1 functions with arguments</h2>
            <p>Arguments are values we parse to functions.</p>
            <p>Functions receive arguments / parameters and do something on them</p>
<pre>
    //declaration (expecting params)
    function fooName(param, param2, param3 ...){
        do something to/with given params
    }

    //invocation (parsing params)
    fooName(1, 2, 3, ....)
</pre>
            <div class="phpTest">.
            </div><!--/phpTest-->

            <h2 id="s112" class="secTitle childTitle">11.2 functions that return values</h2>
            <p>functions can return values using the <strong>return</strong> keyword</p>
            <p>returned values can be then accessed from outside the function</p>
<pre>
    function foo(){
        //do something
        $val = "test";

        //returning a value
        return $val;
    }
    * food processor example
</pre>

            <div class="phpTest">.
            </div><!--/phpTest-->

            <h2 id="s113" class="secTitle childTitle">11.3 custom functions documentation (PHPDoc)</h2>
            <p>It's extremely important to write a clean documentation for custom functions</p>
            <p>PHPDoc is a useful and easy standard to follow (http://www.phpdoc.de/) </p>
<pre>
/**
 *	@name
 *	@description
 *	@param 	TYPE	$paramName   param description
 * 	@return	TYPE	$returnName  return description
 */
function foo($paramName){
    return $returnName
}

* food processor with multiple params
</pre>

<div class="phpTest">.
</div><!--/phpTest-->

<pre>
    ###### EXERCISE ######
    implement a function following given documentation

    /**
     *	@name   stylePar
     *	@desc   this will receive a piece of text and a hex colour,
     *	        then it will style the text using given colour
     *	        and it will return a par out of it
     *	@param	    STRING      $txt	some text
     *	@param	    STRING      $col	hex colour
     *	@return	    STRING      $par    styled par
     */
</pre>

<div class="phpTest">.
</div><!--/phpTest-->

            <h2 id="s114" class="secTitle childTitle">11.4 GLOBAL vs LOCAL variables</h2>
            <p>Global variables are variables created outside of any function</p>
            <p>A variable created inside a function belongs to the local scope:
                it cannot be accessed from outside the function (unless it's returned)</p>
<pre>
    //global var
    $var = 1;

    function foo(){
        //local var
        $var = 2;
    }

    the two $var are NOT pointing to the same value
</pre>

<div class="phpTest">.
</div><!--/phpTest-->


            <h2 id="s12" class="secTitle">12. INBUILT FUNCTIONS</h2>

            <p>PHP has a huge number of inbuilt functions, you can read PHP documentation at PHP.NET</p>
<pre>
    #### date() exercise
    read on PHP.NET how to display a paragraph like:
    Today is Monday, September the 19th, 2016
</pre>

<div class="phpTest">.
</div><!--/phpTest-->



            <h2 id="s13" class="secTitle">13. SERVER SIDE INCLUDES (SSI)</h2>
            <p>We can include external php script using following functions:</p>
            <ul>
                <li> * include()</li>
                <li> * include_once()</li>
                <li> * require()</li>
                <li> * require_once()</li>
            </ul>
<pre>
    include(path/to/file.php);

    #### include test
</pre>

<div class="phpTest">.
</div><!--/phpTest-->

















        <br /><br /><br /><br /><br /><br /><br /><br /><br />
        <br /><br /><br /><br /><br /><br /><br /><br /><br />
        <br /><br /><br /><br /><br /><br /><br /><br /><br />
        <br /><br /><br /><br /><br /><br /><br /><br /><br />
        <br /><br /><br /><br /><br /><br /><br /><br /><br />
        <br /><br /><br /><br /><br /><br /><br /><br /><br />
        <br /><br /><br /><br /><br /><br /><br /><br /><br />









        </div><!--/main-->
        
    	<div id="footer" class="fullw">
        	<div class="inner">TrainingDragon &copy;2016 - learn php - <a href="#nav">top</a> </div>
        </div><!--/footer-->
    </div><!--/wrapper-->

</body>
</html>
