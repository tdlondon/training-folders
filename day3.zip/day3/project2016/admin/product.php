<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/product.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="editAddItem">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Add / Edit product</h2>
                        <form method="post" enctype="multipart/form-data" action="#" class="editAddForm editAddProd flexCont">
                            <div class="formCol">
                                <label for="pName">PRODUCT NAME</label>
                                <input class="formField" type="text" id="pName" name="pName" value="">

                                <label for="pPrice">PRODUCT PRICE</label>
                                <input class="formField" type="text" id="pPrice" name="pPrice" value="">

                                <label>PRODUCT IMAGE</label>
                                <div class="fileUploadBlock">
                                    <div class="flexCont">
                                        <label for="pImage" class="fileBtn btn smBtn ckBtn">CHOOSE FILE</label>
                                        <p>
                                            <span class="formField uploadFileSpan" id="uploadProdSpan">No file selected</span>
                                        </p>
                                    </div>
                                    <input class="hiddenFileUpload" type="file" id="pImage" name="pImage" value="">
                                </div><!--/fileUploadBlock-->



                                <label for="pShipp">PRODUCT SHIPPING</label>
                                <input class="formField" type="text" id="pShipp" name="pShipp" value="">
                            </div><!--/formCol-->

                            <div class="formCol">
                                <label for="pDesc">PRODUCT DESCRIPTION</label>
                                <textarea class="formField bgTxtArea" id="pDesc" name="pDesc"></textarea>
                                <button type="submit" name="submit" class="btn ckBtn smBtn blueBtn">Add / Edit product</button>

                            </div><!--/formCol-->
                        </form><!--/editAddForm-->

                    </section><!--/editAddItem-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php");?>
</div><!--/wrapper-->
<!-- add your JS here-->
<script src="<?php echo ROOT;?>build/js/fileUploadTrick.js"></script>
<!--/ your JS here-->
</body>
</html>

