<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/basket.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Basket</h2>


                        <!--========== no products in the basket ===========-->
                        <div class="noProducts">
                            <p>There are currently no products in the basket, please use the
                                <a href="../search.php" class="boldLink">search</a> page to look for new ones.</p>
                        </div><!--/noProducts-->
                        <!--========== end no products in the basket =======-->
                        
                        <div class="itemsBlock">
                            <div class="itemLabelsBlock basketItemLabelsBlock flexCont">
                                <div class="itemLabel bQtyLabel">Qty</div>
                                <div class="itemLabel bImageLabel">Image</div>
                                <div class="itemLabel bNameLabel">Name</div>
                                <div class="itemLabel bUnitPriceLabel">Unit Price</div>
                                <div class="itemLabel bTotalPriceLabel">Total Price</div>
                                <div class="itemLabel bUnitShippLabel">Item shipping</div>
                                <div class="itemLabel bTotalShippLabel">Total shipphing</div>
                            </div><!--/itemLabels-->

                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox bQtyBox">
                                    <p  class="qtyNoPar">2</p>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/bQtyBox-->

                                <div class="itemBox vCentre bImageBox">
                                    <img src="../build/imgs/sample_products/iphone.jpg" width="75" height="75" title="iPhone" alt="iPhone">
                                </div><!--/bImageBox-->

                                <div class="itemBox vCentre bNameBox">
                                    <p>iPhone</p>
                                </div><!--/bNameBox-->

                                <div class="itemBox vCentre bUnitPriceBox">
                                    <p>&pound;200.00</p>
                                </div><!--/bUnitPriceBox-->

                                <div class="itemBox vCentre bTotalPriceBox">
                                    <p>&pound;400.00</p>
                                </div><!--/bTotalPriceBox-->

                                <div class="itemBox vCentre bUnitShippBox">
                                    <p>&pound;25.00</p>
                                </div><!--/bUnitShippBox-->

                                <div class="itemBox vCentre bTotalShippBox">
                                    <p>&pound;50.00</p>
                                </div><!--/bTotalShippBox-->

                            </div><!--/item =======================================================-->

                            <!--DELETE FROM HERE =================================-->
                            <div class="item flexCont">
                                <div class="itemBox bQtyBox">
                                    <p  class="qtyNoPar">3</p>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/bQtyBox-->

                                <div class="itemBox vCentre bImageBox">
                                    <img src="../build/imgs/sample_products/tank.jpg" width="75" height="75" title="iPhone" alt="iPhone">
                                </div><!--/bImageBox-->

                                <div class="itemBox vCentre bNameBox">
                                    <p>tank</p>
                                </div><!--/bNameBox-->

                                <div class="itemBox vCentre bUnitPriceBox">
                                    <p>&pound;20.00</p>
                                </div><!--/bUnitPriceBox-->

                                <div class="itemBox vCentre bTotalPriceBox">
                                    <p>&pound;60.00</p>
                                </div><!--/bTotalPriceBox-->

                                <div class="itemBox vCentre bUnitShippBox">
                                    <p>&pound;3.00</p>
                                </div><!--/bUnitShippBox-->

                                <div class="itemBox vCentre bTotalShippBox">
                                    <p>&pound;9.00</p>
                                </div><!--/bTotalShippBox-->

                            </div>



                            <!--DELETE UP TO HERE=======================================================-->
                            <div class=" basketFinal">
                                <div class="flexCont">
                                    <div class="itemLabel">SUBSHIPPING</div>
                                    <div class="itemBox subItemBox">&pound;0.00</div>
                                </div>
                                <div class="flexCont">
                                    <div class="itemLabel">SUBTOTAL</div>
                                    <div class="itemBox subItemBox">&pound;0.00</div>
                                </div>
                                <div class="flexCont">
                                    <div class="itemLabel">GRAND TOTAL</div>
                                    <div class="itemBox redItemBox">&pound;0.00</div>
                                </div>
                                <a href="checkout.php" class="checkoutBtn btn blueBtn ckBtn">checkout</a>
                            </div><!--/basketFinal-->
                        </div><!--/itemsBlock-->


                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>

<?php include ("../includes/footer.php")?>

</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>

