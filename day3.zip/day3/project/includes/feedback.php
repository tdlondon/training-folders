<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/feedback.php
 */
?>
<section class="feedback">
<?php if( isset($successMsg) ){ // boldLink ?>
    <div class="successMsg"><?php echo $successMsg; ?></div>
<?php } // if successMsg

if( isset($failMsg) ){
?>
    <div class="failMsg"><?php echo $failMsg; ?></div>
<?php } // if failMsg?>
</section><!--/feedBack-->

