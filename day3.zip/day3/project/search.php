<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /search.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("includes/top.php");
include("includes/header.php");
####
?>
    </header>

    <main>
        <section class="mainBody">
            <div class="container">

                <!-- ====================  FEEDBACK START =========-->
                <?php include("includes/feedback.php"); ?>
                <!-- ====================  FEEDBACK END ===========-->


                    <section class="search">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Search</h2>
                        <form method="get" action="#" class="searchForm">
                            <input type="text" class="formField" name="q" value="" placeholder="Type here_">
                            <button class="btn ckBtn bgBtn blueBtn">search</button>
                        </form>
                    </section><!--/search-->
                </div><!--/container-->

                <div class="separator"></div>

                <div class="container">
                    <section class="searchResults">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Results for <span class="qName">iMac</span></h2>

                        <div class="resultProduct flexCont"><!--=============================== result product-->
                            <div class="resPic vCentre">
                                <img src="<?php echo ROOT;?>build/imgs/sample_products/imac.jpg" width="106" height="106" title="imac" alt="imac">
                            </div><!--/resPic-->
                            
                            <div class="resDetails vCentre">
                                <div>
                                    <h4 class="resName">iMac</h4>
                                    <p class="resDesc">Latest model</p>
                                </div>
                            </div><!--/resDetails-->
                            
                            <div class="resPrice vCentre">
                                <p>&pound;1500.00</p>
                            </div><!--/resPrice-->
                            
                            <div class="resAction vCentre">
                                <a href="<?php echo ROOT;?>admin/basket.php" class="btn ckBtn smBtn blueBtn">add to basket</a>
                            </div><!--/resAction-->
                        </div><!--/resultProduct ==============================================================-->

                        <div class="resultProduct flexCont">
                            <div class="resPic vCentre">
                                <img src="<?php echo ROOT;?>build/imgs/sample_products/motor.jpg" width="106" height="106" title="imac" alt="imac">
                            </div><!--/resPic-->

                            <div class="resDetails vCentre">
                                <div>
                                    <h4 class="resName">Motor</h4>
                                    <p class="resDesc">Latest model</p>
                                </div>
                            </div><!--/resDetails-->

                            <div class="resPrice vCentre">
                                <p>&pound;1500.00</p>
                            </div><!--/resPrice-->

                            <div class="resAction vCentre">
                                <a href="<?php echo ROOT;?>admin/basket.php" class="btn ckBtn smBtn blueBtn">add to basket</a>
                            </div><!--/resAction-->
                        </div><!--/resultProduct ==============================================================-->

                        <div class="resultProduct flexCont">
                            <div class="resPic vCentre">
                                <img src="<?php echo ROOT;?>build/imgs/sample_products/tank.jpg" width="106" height="106" title="imac" alt="imac">
                            </div><!--/resPic-->

                            <div class="resDetails vCentre">
                                <div>
                                    <h4 class="resName">tank chassis</h4>
                                    <p class="resDesc">Latest model</p>
                                </div>
                            </div><!--/resDetails-->

                            <div class="resPrice vCentre">
                                <p>&pound;1500.00</p>
                            </div><!--/resPrice-->

                            <div class="resAction vCentre">
                                <a href="<?php echo ROOT;?>admin/basket.php" class="btn ckBtn smBtn blueBtn">add to basket</a>
                            </div><!--/resAction-->
                        </div><!--/resultProduct ==============================================================-->

                        
                                         
                    </section><!--/searchResults-->

                </div><!--/mainBody container-->
            </section><!--/ mainBody-->
        </main>



<?php include("includes/footer.php");?>

</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>

