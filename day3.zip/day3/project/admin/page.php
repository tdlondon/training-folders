<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/page.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="editAddItem">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Add / Edit page</h2>
                        <form method="post" enctype="multipart/form-data" action="#" class="editAddForm editAddProd flexCont">
                            <div class="formCol">
                                <label for="pgName">PAGE NAME</label>
                                <input class="formField" type="text" id="pgName" name="pgName" value="">

                                <label for="pgOrder">PAGE ORDER</label>
                                <input class="formField" type="text" id="pgOrder" name="pgOrder" value="">

                                <label for="pgUrl">PAGE URL</label>
                                <input class="formField" type="text" id="pgUrl" name="pgUrl" value="">

                                <label for="pgTitle">PAGE TITLE</label>
                                <input class="formField" type="text" id="pgTitle" name="pgTitle" value="">

                                <label for="pgDesc">PAGE DESCRIPTION</label>
                                <input class="formField" type="text" id="pgDesc" name="pgDesc" value="">

                            </div><!--/formCol-->

                            <div class="formCol">
                                <label for="pgKeys">PAGE KEYWORDS</label>
                                <input class="formField" type="text" id="pgKeys" name="pgKeys" value="">

                                <label for="pgBody">PAGE BODY</label>
                                <textarea class="formField bgTxtArea" id="pgBody" name="pgBody"></textarea>
                                <button type="submit" name="submit" class="btn ckBtn smBtn blueBtn">Add / Edit page</button>

                            </div><!--/formCol-->
                        </form><!--/editAddForm-->

                    </section><!--/editAddItem-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php")?>
</div><!--/wrapper-->
<!-- add your JS here-->
<!--
    <script src="http://cdn.tinymce.com/4/tinymce.min.js"></script>
    <script>tinymce.init({ selector:'.bgTxtArea' });</script>
-->
<!--/ your JS here-->
</body>
</html>
