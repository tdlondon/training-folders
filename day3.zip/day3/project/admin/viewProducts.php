<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/viewProducts.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");

if(true) {
########### 2) DELETE MODE
/**
 * query string parameters are collected by another superglobal called $_GET
 */
#### executing delete mode only if we have a GET parameter called d_id
if( isset($_GET["d_id"]) ){
    //storing d_id into a var
    $d_id = $_GET["d_id"];

    // building query
    $dq = "
        DELETE FROM
            `" . DBN . "`.`product`
        WHERE
            `product`.`pID` = '$d_id'
    ";

    // echo $dq;
    // executing the query
    $dRes = mysqli_query($link, $dq);

    // checking and handling result
    if( mysqli_affected_rows($link) == 1 ){
        // product deleted
        $successMsg = "Product successfully deleted.";
    } else {
        // something went wrong
        $failMsg = "Could not delete product or product already deleted.";
    }// end delete check


} ############## END DELETE MODE





########### 1) SELECT MODE
/**
 * 1) build query (and test it!!!!!)
 * 2) run query
 * 3) check and handle query result
 */
// 1) building the query:
$q = "
    SELECT
        *
    FROM
        `" . DBN . "`.`product`
";

// echo $q;
// 2) run query and store result
$res = mysqli_query($link, $q);

// trace($res);

// 3) check and handle query result
if( mysqli_num_rows($res) > 0 ){
    // we have products
    // a) creating an empty array
    $prods = [];

    // b) loop through rows and turn each row into an associative array
    // while(statement){ code }
    while( $row = mysqli_fetch_assoc($res) ){
        // c) push each row at the end of $prods array
        // array_push($arr, $item)
        $prods[] = $row;
    }// end while

    //trace($prods);

} else {
    // error or no products
    $failMsg = "No products or something went wrong.";
} // end select query

}################### end logged in


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">View products</h2>

<?php if(isset($prods)){?>
                        <div class="itemsBlock">
                            <div class="itemLabelsBlock flexCont">
                                <div class="itemLabel pIDLabel">id</div>
                                <div class="itemLabel pNameLabel">name</div>
                                <div class="itemLabel pPriceLabel">price</div>
                                <div class="itemLabel pDescLabel">description</div>
                                <div class="itemLabel pShippLabel">shipping</div>
                                <div class="itemLabel pImageLabel">image</div>
                            </div><!--/itemLabels-->

<?php foreach($prods as $prod){?>
                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox vCentre pIDBox">
                                    <p><?php echo $prod["pID"]; ?></p>
                                </div><!--/pID-->

                                <div class="itemBox vCentre pNameBox">
                                    <p><?php
if(isset($prod["pName"])){
    echo $prod["pName"];
} else {
    echo "--";
}
                                        ?></p>
                                </div><!--/pName-->

                                <div class="itemBox vCentre pPriceBox">
                                    <p>&pound;<?php
                                        if(isset($prod["pPrice"])){
                                            echo $prod["pPrice"];
                                        } else {
                                            echo "--";
                                        }
                                        ?></p>
                                </div><!--/pPrice-->

                                <div class="itemBox vCentre pDescBox">
                                    <p><?php
                                        if(isset($prod["pDesc"])){
                                            echo $prod["pDesc"];
                                        } else {
                                            echo "--";
                                        }
                                        ?></p>
                                </div><!--/pDesc-->

                                <div class="itemBox vCentre pShippBox">
                                    <p>&pound;<?php
                                        if(isset($prod["pShipp"])){
                                            echo $prod["pShipp"];
                                        } else {
                                            echo "--";
                                        }
                                        ?></p>
                                </div><!--/pShipp-->

                                <div class="itemBox vCentre pImageBox">
                                    <img src="<?php echo ROOT;?>build/imgs/products/<?php
                                    if(isset($prod["pImage"])){
                                        echo $prod["pImage"];
                                    } else {
                                        echo "no_img.jpg";
                                    }
                                    ?>" width="75" height="75"
                                         title="<?php
                                         if(isset($prod["pName"])){
                                             echo $prod["pName"];
                                         } else {
                                             echo "product";
                                         }
                                         ?>"
                                         alt="<?php
                                         if(isset($prod["pName"])){
                                             echo $prod["pName"];
                                         } else {
                                             echo "product";
                                         }
                                         ?>">
                                </div><!--/pImage-->

<div class="itemBox itemBtns">
    <a class="itemAction editItemAction" href="<?php echo ROOT;?>/admin/product.php?e_id=<?php echo $prod["pID"]; ?>"></a>
    <a class="itemAction deleteItemAction" href="?d_id=<?php echo $prod["pID"]; ?>"></a>
</div><!--/itemBtns-->
                            </div><!--/item =======================================================-->
<?php }### foreach ?>

                        </div><!--/itemsBlock-->
<?php } ####  if $prods?>

                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php");?>
</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>