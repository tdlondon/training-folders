<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/viewUsers.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");

if(true) {

########## 2) DELETE MODE #################
    if (isset($_GET["d_id"]) ) {
        $d_id = $_GET["d_id"];

        $dq = "
        DELETE FROM
          `" . DBN . "`.`user`
        WHERE
          `user`.`uID` = '$d_id'
    ";
        // echo $dq;
        $dRes = mysqli_query($link, $dq);

        if (mysqli_affected_rows($link) == 1) {
            $successMsg = "User successfully deleted.";
        } else {
            $failMsg = "Could not delete user or user already deleted.";
        }// end delete check
    }###################### END DELETE MODE


########## 1) SELECT MODE #################
    /**
     * 1) build the query (and test it)
     * 2) run the query (and store the result)
     * 3) check query result
     */
####  building query
    $q = "
    SELECT
        *
    FROM
        `" . DBN . "`.`user`
";

//echo $q;

#### running the query
    $res = mysqli_query($link, $q);

// trace($res);

#### checking the result
    if (mysqli_num_rows($res) > 0) {
        // creating an empty array
        $users = [];

        // while(condition / statement){.....}
        while ($row = mysqli_fetch_assoc($res)) {
            // appending rows at the end of $users array
            array_push($users, $row);
        }// while

        //trace($users);
    } else {
        $failMsg = "No users or something went wrong.";
    }// end select check

}############ end is_logged in
########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
    </header>

    <main>
        <?php include("../includes/adminNav.php");?>

        <section class="mainBody">
            <div class="container">
                <!-- ====================  FEEDBACK START =========-->
                <?php include("../includes/feedback.php");?>
                <!-- ====================  FEEDBACK END ===========-->
            </div><!--container-->

            <?php if( true ){ ?>
                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">View users</h2>
                        <?php if(isset($users)){?>
                            <div class="itemsBlock">
                                <div class="itemLabelsBlock flexCont">
                                    <div class="itemLabel uIDLabel">id</div>
                                    <div class="itemLabel uNameLabel">Name</div>
                                    <div class="itemLabel uLastLabel">Last</div>
                                    <div class="itemLabel uEmailLabel">Email</div>
                                    <div class="itemLabel uPswLabel">Psw</div>
                                    <div class="itemLabel uAddr1Label">Addr1</div>
                                    <div class="itemLabel uAddr2Label">Addr2</div>
                                    <div class="itemLabel uCodeLabel">Code</div>
                                    <div class="itemLabel uCityLabel">City</div>
                                    <div class="itemLabel uCountryLabel">Country</div>
                                    <div class="itemLabel uPhoneLabel">Phone</div>
                                </div><!--/itemLabels-->

                                <?php foreach($users as $user){?>
<div class="item flexCont"><!--/item =================================-->
    <div class="itemBox vCentre uIDBox">
        <p><?php echo $user["uID"];?></p>
    </div><!--/uIDBox-->

    <div class="itemBox vCentre uNameBox">
        <p><?php if(isset($user["uName"])){echo $user["uName"];} else {echo "--";};?></p>
    </div><!--/uNameBox-->

    <div class="itemBox vCentre uLastBox">
        <p><?php if(isset($user["uLast"])){echo $user["uLast"];} else {echo "--";};?></p>
    </div><!--/uLastBox-->

    <div class="itemBox vCentre uEmailBox">
        <p><?php if(isset($user["uEmail"])){echo $user["uEmail"];} else {echo "--";};?></p>
    </div><!--/uEmailBox-->

    <div class="itemBox vCentre uPswBox">
        <p><?php if(isset($user["uPsw"])){echo substr($user["uPsw"],0, 5) . "[...]" ;} else {echo "--";};?></p>
    </div><!--/uPswBox-->

    <div class="itemBox vCentre uAddr1Box">
        <p><?php if(isset($user["uAddr1"])){echo $user["uAddr1"];} else {echo "--";};?></p>
    </div><!--/uAddr1Box-->

    <div class="itemBox vCentre uAddr2Box">
        <p><?php if(isset($user["uAddr2"])){echo $user["uAddr2"];} else {echo "--";};?></p>
    </div><!--/uAddr2Box-->

    <div class="itemBox vCentre uCodeBox">
        <p><?php if(isset($user["uCode"])){echo $user["uCode"];} else {echo "--";};?></p>
    </div><!--/uCodeBox-->

    <div class="itemBox vCentre uCityBox">
        <p><?php if(isset($user["uCity"])){echo $user["uCity"];} else {echo "--";};?></p>
    </div><!--/uCityBox-->

    <div class="itemBox vCentre uCountryBox">
        <p><?php if(isset($user["uCountry"])){echo $user["uCountry"];} else {echo "--";};?></p>
    </div><!--/uCountryBox-->

    <div class="itemBox vCentre uPhoneBox">
        <p><?php if(isset($user["uPhone"])){echo $user["uPhone"];} else {echo "--";};?></p>
    </div><!--/uPhoneBox-->

    <div class="itemBox itemBtns">
        <a class="itemAction editItemAction" href="user.php?e_id=<?php echo $user["uID"];?>"></a>
        <a  class="itemAction deleteItemAction" href="?d_id=<?php echo $user["uID"];?>" ></a>
    </div><!--/itemBtns-->
</div><!--/item =======================================================-->
                                <?php } // foreach?>
                            </div><!--/itemsBlock-->
                        <?php } // if isset users?>

                    </section><!--/viewItems-->
                </div><!--/container-->
            <?php } //if true ?>

        </section><!--/ mainBody-->
    </main>

<?php include ("../includes/footer.php");?>