/**
 * @file    video.js
 * @author  Training Dragon
 * @desc    this will display a video with a basic controller,
 *              it will also apply effects on the video using CSS3 filters
 */

// wrap all your code in an Immediately Invoked Function Expression (iffy)
// we want to avoid global variables
(function () {
var
    vid         = document.getElementById("vid1"),
    slowBtn     = document.getElementById("slowBtn"),
    playBtn     = document.getElementById("playBtn"),
    pauseBtn    = document.getElementById("pauseBtn"),
    fastBtn     = document.getElementById("fastBtn"),


    bindBtns = function () {
        slowBtn.addEventListener("click", function () {
            vid.playbackRate = .5;
        });// slow

        playBtn.addEventListener("click", function () {
            vid.playbackRate = 1;
            vid.play();
        });// play

        pauseBtn.addEventListener("click", function () {
            vid.pause();
        });// pause

        fastBtn.addEventListener("click", function () {
            vid.playbackRate = 2;
        });// fast
    }, // bindBtns

    initialiser  = function () {
        bindBtns();
    } // initializer
;

window.onload = initialiser;
})();