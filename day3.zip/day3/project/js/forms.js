/**
 * @file    forms.js
 * @author  Training Dragon
 * @desc    this will display new forms 2.0 features
 */



// wrap all your code in an Immediately Invoked Function Expression (iffy)
// we want to avoid global variables
(function () {
var
    numA        = document.getElementById("numA"),
    numB        = document.getElementById("numB"),
    sumBtn      = document.querySelector("#sumBtn"), // using css selectors
    sumResult   = document.getElementById("sumResult"),
    prBar       = document.getElementById("prBar"),
    prValue     = 0,
    sizeSliders = document.querySelectorAll("input[data-prop]"),
    blueBox     = document.getElementById("blueBox"),
    colSliders  = document.querySelectorAll("input[data-col]"),

    bindSumBtn = function () {
        //element.addEventListener(event:string, handler:function)
        sumBtn.addEventListener("click", function () {
            var
                valueA = parseInt(numA.value),
                valueB = parseInt(numB.value),
                result = valueA + valueB
            ;
            sumResult.innerHTML = result;
        });
    }, // bindSumBtn

    bindProgressBar = function () {
        if(prValue < prBar.max){
            prValue += 5;
            prBar.value = prValue;
            setTimeout(
                // code to execute
                function () {
                    bindProgressBar();
                },
                // delay in ms
                100
            );
        }
    }, // bindProgressBar

    bindSizeSliders = function () {
        // console.log(sizeSliders);
        // looping trough sizeSliders
        var i = 0, L = sizeSliders.length;
        for(; i < L; i++){
            // "e" is the event we are listening to
            sizeSliders[i].addEventListener("input", function (e) {
                // dynamically fetching the target of the event
                // console.log(e.target);
                var
                    val     = e.target.value,
                    prop    = e.target.getAttribute("data-prop")
                ;

                // using subscript notation to access a property of
                // the style object using a variable (prop)
                blueBox.style[prop] = val + "px";

            }); // input
        }// for

    }, // bindSizeSliders

    bindColSliders = function () {
        //console.log(colSliders);
        var
            bgCol = {
                r : 0,
                g : 0,
                b : 255,
                a : 1
            }, i = 0, L = colSliders.length;

        for(; i<L; i++){
            colSliders[i].addEventListener("input", function (e) {
                var
                    val = e.target.value,
                    col = e.target.getAttribute("data-col")
                ;
                bgCol[col] = val;
                // console.log(bgCol);

                //blueBox.style.backgroundColor = "rgba(0 , 0, 255, 1)";

                blueBox.style.backgroundColor =
                    "rgba(" + bgCol.r + "," +
                              bgCol.g + "," +
                              bgCol.b + "," +
                              bgCol.a +
                    ")";

            }); // input
        }// for
    }, // bindColSliders

    initialiser  = function () {
        bindSumBtn();
        bindProgressBar();
        bindSizeSliders();
        bindColSliders();
    } // initializer
;

window.onload = initialiser;
})();