/**
 * Training Dragon
 */

//this is a single line js comment

/*
 this is
 a multiline
 js comment
*/

function showPic1(){
    //console.log(document.getElementById("banner").style.backgroundImage);
    document.getElementById("banner").style.backgroundImage = "url('imgs/banner1.png')";
}//showPic1


function showPic2(){
    document.getElementById("banner").style.backgroundImage = "url('imgs/banner2.png')";
}//showPic2


function showPic3(){
    document.getElementById("banner").style.backgroundImage = "url('imgs/banner3.png')";
}//showPic3