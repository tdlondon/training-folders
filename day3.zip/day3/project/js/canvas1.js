/**
 * @file    canvas1.js
 * @author  Training Dragon
 * @desc    this will show basic canvas usage:
 *              drawing primitives,
 *              interacting with canvas via buttons,
 *              detecting mouse cursor position and working with mouse events
 */

// wrap all your code in an Immediately Invoked Function Expression (iffy)
// we want to avoid global variables
(function () {
var
    c1          =   document.getElementById("c1"),
    ctx1        =   c1.getContext("2d"),
    c2          =   document.getElementById("c2"),
    ctx2        =   c2.getContext("2d"),
    c3          =   document.getElementById("c3"),
    ctx3        =   c3.getContext("2d"),
    w           =   c1.width,
    h           =   c1.height,
    fillCols    =   ['#0CF','#0C0','#C96','#63F','#F0F',
                    'red','yellow','blue','green','#030','#3F9',
                    '#06F','#FC6','#933','#0C3','#CF9'],
    strokeCols  =   ['#000','#333','#009','#99c','#F06','#C99',
                    '#093','#F9F','#F60','#30C','#699','#306'],
    addBtn      =   document.getElementById("addBtn"),
    clearBtn    =   document.getElementById("clearBtn"),
    snapBtn     =   document.getElementById("snapBtn"),

    /**
     * @name    getRandomToMax
     * @desc    this will generate a random number between 0 and given max
     * @param   {number}    max     maximum allowed number
     * @return  {number}            random number
     *
     * Math.random()    =>  random numbers between 0 and 1
     * Math.floor()     =>  round down
     * Math.ceil()      =>  round up
     * Math.round()     =>  round to closest
     */
    getRandomToMax = function (max) {
        return Math.floor(Math.random() * max);
    }, // getRandomToMax

    /**
     * drawing rectangles using
     * ctx.rect()
     */
    drawRectangles = function () {

        var
            ratio = .8,
            rw = w * ratio,
            rh = h * ratio,
            rx = w/2 - rw/ 2,
            ry = h/2 - rh/2
            ;

        ctx1.beginPath();
        //ctx1.rect(100, 100, 300, 150);
        ctx1.rect(rx, ry, rw, rh);
        ctx1.fillStyle = "red";
        ctx1.fill();
        ctx1.strokeStyle = "blue";
        ctx1.lineWidth = 5;
        ctx1.stroke();
        ctx1.closePath();
    }, // drawRectangles

    /**
     * drawing circles using
     * ctx.arc()
     */
    drawArcs = function () {
        ctx2.beginPath();
        //context.arc(cx, cy, radius, startAngle, endAngle, direction)
        ctx2.arc(200, 200, 150, 0, 2*Math.PI, true);
        ctx2.fillStyle = "yellow";
        ctx2.fill();
        ctx2.strokeStyle = "cornflowerblue";
        ctx2.lineWidth = 10;
        ctx2.stroke();
        ctx2.closePath();
    }, // drawArcs

    bindBtns = function () {
        addBtn.addEventListener("click", function () {
            var
                rx      = getRandomToMax(w),
                ry      = getRandomToMax(h),
                rw      = getRandomToMax(300),
                rh      = getRandomToMax(200),
                rLw     = getRandomToMax(20),
                rFill   = fillCols[ getRandomToMax(fillCols.length - 1) ],
                rStroke = strokeCols[ getRandomToMax(strokeCols.length - 1) ]
            ;

            ctx3.beginPath();
            ctx3.rect(rx,ry,rw,rh);
            ctx3.fillStyle = rFill;
            ctx3.fill();
            ctx3.strokeStyle = rStroke;
            ctx3.lineWidth = rLw;
            ctx3.stroke();
            ctx3.closePath();
        }); // add
    }, // bindBtns


    initialiser  = function () {
        drawRectangles();
        drawArcs();
        bindBtns();
    } // initializer
;

window.onload = initialiser;
})();