/**
 * @author  Training Dragon
 * @name    canvas1.js
 * @desc    this will demonstrate how to draw primitives (squares, rectangles, circles),
 *          interact with buttons, detect mouse cursor position on canvas
 */
// wrap all your code in an iife
(function(){
var
    c1 = document.getElementById("c1"),
    ctx1 = c1.getContext("2d"),
    w = c1.width,
    h = c1.height,

    /**
     *  @name   drawRect
     *  @desc   this will draw rectangles / squares
     */
    drawRect = function () {
        var
            a = 8/9,
            rw = w * a,
            rh = h * a,
            rx = (w-rw) / 2,
            ry = (h-rh) / 2
        ;


        ctx1.beginPath();
        // ctx.rect(x, y, w, h)
        ctx1.rect(rx,ry, rw, rh);
        ctx1.fillStyle = "red";
        ctx1.fill();
        ctx1.strokeStyle = "blue";
        ctx1.lineWidth = 5;
        ctx1.stroke();
        ctx1.closePath();
    }, // drawRect


    init = function () {
        drawRect();
    }// init
;
    window.addEventListener("load",init);
})();