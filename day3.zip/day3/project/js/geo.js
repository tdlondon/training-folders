/**
 * @author  Training Dragon
 * @name    geo.js
 * @desc    this will use geolocation object and use google maps API to display maps
 */
// wrap all your code in an iife
(function(){
var
    mapDiv = document.getElementById("mapDiv"),
    // detecting geolocation support
    // !! operator typecasts elements as booleans
    supportsGeo = (function(){return !!navigator.geolocation;})(),

    /**
     *  @name   addMarker
     *  @desc   this will display a marker in our map, highlighting current position
     *  @param  map             OBJECT      google map object
     *  @param  googleCoords    OBJECT      LatLng object
     */
    addMarker = function(map, googleCoords){
        var
            markerProps = {
                // map we want to add the marker to
                map : map,
                // position of the marker
                position :  googleCoords,
                // animation of the marker [DROP / BOUNCE]
                animation : google.maps.Animation.DROP,
                // icon URL
                icon : "https://maps.google.com/mapfiles/ms/icons/blue-dot.png"
            },
            // creating a marker object
            marker = new google.maps.Marker(markerProps);
    }, // addMarker

    /**
     *  @name   addMap
     *  @desc   this will receive coords, create a LatLng obj, create the map
     *  @param  coords    OBJECT      latitude and longitude coordinates of the user
     */
    addMap = function(coords){
        var
            // creating an object that we can use with google maps API using their LatLng constructor
            googleCoords = new google.maps.LatLng(coords.latitude, coords.longitude),
            // creating a properties objects
            mapProps = {
                // centre of the map
                center  :   googleCoords,
                // size of the map 15 => roads
                zoom :  15,
                // type of map [ROADMAP / SATELLITE / HYBRID / TERRAIN]
                mapTypeId : google.maps.MapTypeId.ROADMAP
            },
            // creating a Map object
            map = new google.maps.Map(mapDiv, mapProps)
        ;

        addMarker(map, googleCoords);
    }, // addMap


    /**
     *  @name   onSuccess
     *  @desc   this will receive a geolocation position object
     *  @param  position    OBJECT      position object
     */
    onSuccess = function(position){
        console.log(position);

        addMap(position.coords);
    }, // onSuccess

    onError = function (error) {
        console.log(error);
    }, // onError


    getPosition = function () {
        navigator.geolocation
            .getCurrentPosition(
                onSuccess,  // success callback
                onError,    // error callback
                // properties
                {
                    // how do we want to detect position
                    enableHighAccuracy  : true,
                    // how long I want to look for a new position for (value in ms)
                    timeout :   10000,
                    // how long I want a fetched position to last
                    maximumAge  : 0
                }
            );
    }, // getPosition

    init = function () {
        if(supportsGeo){
            getPosition();
        } else {
            alert("time to update your browser...");
        }
    }// init
;
    window.addEventListener("load",init);
})();