/**
 * @file    geo.js
 * @author  Training Dragon
 * @desc    this will detect user location in real time and display it into a map
 *          using google maps API v3
 */

// wrap all your code in an Immediately Invoked Function Expression (iffy)
// we want to avoid global variables
(function () {
var
    mapDiv = document.getElementById("mapDiv"),

    /**
     * @name    addMarkerDynamic
     * @desc    this will receive parameters to generate markers
     * @param   {object}    map     google Map object
     * @param   {object}    coords  google LatLng object
     * @param   {string}    animation   [BOUNCE / DROP]
     * @param   {string}    icon    marker icon url
     */
    addMarkerDynamic = function(map, coords, animation, icon){
        var
            // parameters to create the marker
            markerParams = {
                // map to add a marker to:
                "map" : map,
                // position of the marker
                "position" : coords,
                // marker animation [DROP / BOUNCE]
                "animation" : google.maps.Animation[animation],
                // icon url
                "icon"  : icon
            },
            // creating the marker object using Marker constructor
            marker = new google.maps.Marker(markerParams)
            ;

    }, // addMarkerDynamic

    /**
     * @name    addMarker
     * @desc    this will receive a map and coordinates,
     *              then display a marker on given map for given coordinates
     * @param   {object}    map             google Map object
     * @param   {object}    googleCoords    LatLng object
     */
    addMarker = function(map, googleCoords){
        var
            markerSettings = {
                // map we want to add a marker to
                "map"       :   map,
                // marker position
                "position"  :   googleCoords,
                // marker animation [DROP / BOUNCE]
                "animation" :   google.maps.Animation.DROP,
                // marker icon URL
                "icon"      :   "http://maps.google.com/mapfiles/ms/icons/blue-dot.png"
            },
            // creating a Marker object
            marker = new google.maps.Marker(markerSettings)
        ;
    }, // addMarker


    /**
     * @name    addMap
     * @desc    this will receive coordinates,
     *              create a LatLng object out of them,
     *              set parameters for google maps API,
     *              display a map around current position
     * @param   {object}    coords      geolocation coordinates
     */
    addMap = function (coords) {
        var
            // creating an object using google maps LatLng constructor
            googleCoords = new google.maps.LatLng(
                coords.latitude,
                coords.longitude
            ),
            // creating an object of settings
            mapSettings = {
                "center"    :   googleCoords,
                // how detailed we want our map to be
                "zoom"      :   17,
                // type of the map [ROADMAP / SATELLITE/ HYBRID / TERRAIN]
                "mapTypeId" :   google.maps.MapTypeId.ROADMAP
            },
            // creating a google Map object
            map = new google.maps.Map(mapDiv, mapSettings),
            farringdonCoords = new google.maps.LatLng(51.5202, -0.1048),

            currentPostion = {
                "map" : map,
                "coords" : googleCoords,
                "animation" : "DROP",
                "icon"  : "http://maps.google.com/mapfiles/ms/icons/blue-dot.png"
            },

            targetPosition = {
                "map" : map,
                "coords" : farringdonCoords,
                "animation" : "BOUNCE",
                "icon"  : "http://maps.google.com/mapfiles/ms/icons/red-dot.png"
            }

        ;
        //addMarker(map, googleCoords);


        addMarkerDynamic(
            currentPostion.map,
            currentPostion.coords,
            currentPostion.animation,
            currentPostion.icon
        );
        addMarkerDynamic(
            targetPosition.map,
            targetPosition.coords,
            targetPosition.animation,
            targetPosition.icon
        );

    }, // addMap

    onSuccess = function (position) {
        // console.log(position);
        addMap(position.coords);
    }, // onSuccess


    onError = function (error) {
        console.log("something wrong: " + error);
    }, // onError

    getPosition = function () {
        navigator.geolocation.getCurrentPosition(
            onSuccess,
            onError,
            {
                // how to get position
                "enableHighAccuracy"    :   true,
                // how long we want to look for a new position for
                "timeout"               :   10000,
                // how long we want to wait before getting a new position
                "maximumAge"            :   0
            }
        ); // getCurrentPosition
    }, // getPosition

    initialiser  = function () {
        getPosition();
    } // initializer
;

window.onload = initialiser;
})();