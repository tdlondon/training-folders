//script. js
//---------------DECLARE GLOBAL VARIABLES AT THE TOP
var
//----
	path = 'assets/imgs/',
	
//---- flag for smiley pic change
	status = 'sad',
	


//---- flag for smiley animation
	leftMargin = 0,
	
	
// animBtns here...
	
	
//---- flag for gallery
	index = 0,
	
	
	;


//onload initialiser
window.onload = init;

//init foo
function init(){
	bindBtns();
	loadDate();

}//end init





/**
 * this will subscribe handlers to click events on our buttons
 */
function bindBtns(){
	// element.onevent = handler
	
}// bindBtns

//FUNCTIONS SAMPLE
function foo(){
	
}//end foo()


//--------------------DATE SAMPLE
//to be invoked at the very top
function loadDate(){
}//end loadDate


//--------------------CHANGE PIC SAMPLE
//var status;
function changePic(){
}//end changePic


//--------------------CHANGE TEXT SAMPLE

function reduceFont(){
}//end reduceFont

function normaliseFont(){
}//end normaliseFont

function enlargeFont(){
}//end enlargeFont

function makeTextRed(){
}//end makeTextRed

function makeTextBlack(){
}//end makeTextBlack



//--------------------ANIMATION SAMPLE
// var leftMargin = 0;

function moveRight(){
	

}//end moveRight

function moveLeft(){
	
}//end moveLeft




//--------------------GALLERY SAMPLE
//var index = 0;
function moveGallery(direction){
	
}//end moveGallery









