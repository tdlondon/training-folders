

<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/header.php
 */
?>
<body>
<div class="wrapper">
    <header>
        <div class="topHeader">
            <div class="identity">
                <img class="logo" src="<?php echo ROOT;?>build/imgs/logo.png" width="70" height="80" alt="logo">
                <h3 class="cName">Company Name</h3>
            </div><!--/identity-->

            <nav class="topNav">
                <ul>
                    <li><a  href="<?php echo ROOT;?>index.php">Home</a></li> <!-- class="currentPageLink" -->
                    <li><a href="#">fake</a></li>
                    <li><a href="<?php echo ROOT;?>search.php">search</a></li>
                    <li><a href="<?php echo ROOT;?>contacts.php">contacts</a></li>
                    <li><a href="<?php echo ROOT;?>admin/admin.php">admin</a></li>
                    <li><a href="<?php echo ROOT;?>admin/basket.php"><span class="greyLink">basket</span> (1)</a></li>
                </ul>
            </nav><!--/topNav-->
        </div><!--/topHeader-->

