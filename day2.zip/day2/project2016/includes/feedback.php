<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/feedback.php
 */
?>



            <section class="feedback">
                <div class="successMsg">success <a href="#" class="boldLink">feedback link</a> </div>
                <div class="failMsg">fail</div>
            </section><!--/feedBack-->

