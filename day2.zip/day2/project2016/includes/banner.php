<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/banner.php
 */
?>


        <div class="banner">
            <div class="container">
                <div class="redDash"></div>
                <h1 class="mainName">Company Name</h1>
                <h2 class="subTitle">We are great at what we do!</h2>
                <div class="redDash"></div>
                <div class="mainDesc underlined">
                    Lorem ipsum dolor sit amet, consectetur elit.
                    Aenean quam ante, egestas tristique consequat ut,
                    Donec commodo eros at felis tempor at porttitor.
                </div><!--/mainDesc-->

            </div><!--/ banner container-->
        </div><!--/banner-->
