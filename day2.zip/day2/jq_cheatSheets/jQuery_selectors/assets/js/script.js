//script.js
$(document).ready(init);


function init(){
	$("#reference tr:odd").css('background-color','#CFF');
	$("#reference tr:even").css('background-color','#CCC');
	$("#reference tr:first").css('background-color','#CF0');
	$(".emptyRow").css('background-color','#333');
}//end init