/**
 * @file: scrollingSample.js
 * @folder: learn_jQuery_2016
 */

// do not forget to wrap all your code in an IFFE
(function(){
    $("document").ready(function(){
       $(".navLinks").on("click",
           // capturing the event
           function(evt){
                // disabling anchors default behaviour
               evt.preventDefault();

               // fetching the element we clicked on
               console.log( $(this).attr("href") );
               var t = $(this).attr("href");

               //animating the whole content of the website
               $("html, body").animate(
                   // object with params
                   {
                       "scrollTop" :
                           $(t)
                               .offset().top -94
                   },
                   // duration
                   800

               );
           }
       );
    });
})();
