//script. js
//---------------DECLARE GLOBAL VARIABLES AT THE TOP
/*
	instead of:
		var a = 1;
		var b = 2;
		var c = 3;

	USE THIS:
		var
			a = 1,
			b = 2,
			c = 3
		;

	  user						JavaScript
	   |							|
	actions						reactions
	   |						    |
	events 		                event handlers
								event listeners
								callbacks
								(functions)



*/



var
//----
	path = 'assets/imgs/',
	fooBtn = document.getElementById("fooBtn"),

	currentDate = document.getElementById("currentDate"),
	currentHours = document.getElementById("currentHours"),
	currentMinutes = document.getElementById("currentMinutes"),
	currentSeconds = document.getElementById("currentSeconds"),
	
//---- flag for smiley pic change
	status = 'sad',
	smiley = document.getElementById("smiley"),
	smileyBtn = document.getElementById("smileyBtn"),

	resDiv = document.getElementById("resDiv"),
	reduceBtn = document.getElementById("reduceBtn"),

//---- flag for smiley animation
	leftMargin = 0,
	
	
// animBtns here...
	
	
//---- flag for gallery
	index = 0
	
	
	;


// onload initialiser
// element.event = handler
window.onload = init;

//init foo
function init(){
	bindBtns();
	loadDate();
}//end init





/**
 * this will subscribe handlers to click events on our buttons
 *
 * best practice:
 * use
 * element.addEventListener(event:string, callback:function)
 */
function bindBtns(){
	// element.onevent = handler
	// DO NOT USE!!!! YOU CAN ONLY STORE ONE HANDLER AT A TIME
	//fooBtn.onclick = foo;
	//fooBtn.onclick = foo2;
	fooBtn.addEventListener("click", foo);
	fooBtn.addEventListener("click", foo2);

	smileyBtn.addEventListener("click", changePic);

	reduceBtn.addEventListener("click", reduceFont);

}// bindBtns

//FUNCTIONS SAMPLE
function foo(){
	alert(1);
}//end foo()

function foo2(){
	alert(2);
}//end foo()


//--------------------DATE SAMPLE
//to be invoked at the very top
function loadDate(){
	var
		// creating a Date object using an inbuilt constructor
		// Current Date
		cd = new Date(),
		// Current Date String
		cds = cd.toDateString(),
		// Current Hours
		ch = cd.getHours(),
		// Current Minutes
		cm = cd.getMinutes(),
		// Current Seconds
		cs = cd.getSeconds()
	;


	if(ch < 10){ ch = "0" + ch; }
	if(cm < 10){ cm = "0" + cm; }
	if(cs < 10){ cs = "0" + cs; }


	//alert(cds);
	// element.innerHTML = value

	currentDate.innerHTML 		= cds;
	currentHours.innerHTML 		= ch;
	currentMinutes.innerHTML 	= cm;
	currentSeconds.innerHTML 	= cs;

	//setTimeout(code:function, delay: ms)
	setTimeout(
		function(){
			loadDate();
		},
		1000
	);
}//end loadDate


//--------------------CHANGE PIC SAMPLE
//var status;
function changePic(){
	if(status === "sad"){
		smiley.src = path + "Smiley_HAPPY.png";
		smileyBtn.value = "No, please don't!";
		status = "happy";
	} else {
		smiley.src = path + "Smiley_SAD.png";
		smileyBtn.value = "Make me happy!";
		status = "sad";
	}
}//end changePic


//--------------------CHANGE TEXT SAMPLE

function reduceFont(){
	// element.style.cssProperty = value
	resDiv.style.fontSize = "10px";

}//end reduceFont

function normaliseFont(){
}//end normaliseFont

function enlargeFont(){
}//end enlargeFont

function makeTextRed(){
}//end makeTextRed

function makeTextBlack(){
}//end makeTextBlack



//--------------------ANIMATION SAMPLE
// var leftMargin = 0;

function moveRight(){
	

}//end moveRight

function moveLeft(){
	
}//end moveLeft




//--------------------GALLERY SAMPLE
//var index = 0;
function moveGallery(direction){
	
}//end moveGallery









