//script. js
/*
	instead of
	var a = 1;
	var b = 2;
	var c = 3;

	USE THIS:
	var
		a = 1,
		b = 2,
		c = 3
	;


*/



//---------------DECLARE GLOBAL VARIABLES AT THE TOP
var
//----
	path = 'assets/imgs/',
	fooBtn 			= document.getElementById("fooBtn"),
	currentDate		= document.getElementById("currentDate"),
	currentHours	= document.getElementById("currentHours"),
	currentMinutes	= document.getElementById("currentMinutes"),
	currentSeconds	= document.getElementById("currentSeconds"),


//---- flag for smiley pic change
	status = 'sad',
	


//---- flag for smiley animation
	leftMargin = 0,
	
	
// animBtns here...
	
	
//---- flag for gallery
	index = 0
	
	
;


/*
	actions 			reactions
	   |				    |
	events				event handlers (listeners / callbacks)
*/


//onload initialiser
// element.(on)event = handler
window.onload = init;

//init foo
function init(){
	loadDate();

	bindBtns();
}//end init





/**
 * this will subscribe handlers to click events on our buttons
 */
function bindBtns(){
	// element.onevent = handler
	/*fooBtn.onclick = foo1;
	fooBtn.onclick = foo2;*/

	// event.addEventListener(event:string, handler:function)
	fooBtn.addEventListener("click", foo1);
	fooBtn.addEventListener("click", foo2);

}// bindBtns

//FUNCTIONS SAMPLE
function foo1(){
	alert(1);
}//end foo1()

function foo2(){
	alert(2);
}//end foo2()


//--------------------DATE SAMPLE
//to be invoked at the very top
function loadDate(){
	// creating a Date object using Date() constructor
	var
		// current date
		cd = new Date(),
		// current date string
		cds = cd.toDateString(),
		// current hours
		ch = cd.getHours(),
		// current  minutes
		cm = cd.getMinutes(),
		// current seconds
		cs = cd.getSeconds()

	;

	// alert(cds);

	// injecting content into DOM elements
	// element.innerHTML = content
	currentDate.innerHTML = cds;
	currentHours.innerHTML = ch;
	currentMinutes.innerHTML = cm;
	currentSeconds.innerHTML = cs;

}//end loadDate


//--------------------CHANGE PIC SAMPLE
//var status;
function changePic(){
}//end changePic


//--------------------CHANGE TEXT SAMPLE

function reduceFont(){
}//end reduceFont

function normaliseFont(){
}//end normaliseFont

function enlargeFont(){
}//end enlargeFont

function makeTextRed(){
}//end makeTextRed

function makeTextBlack(){
}//end makeTextBlack



//--------------------ANIMATION SAMPLE
// var leftMargin = 0;

function moveRight(){
	

}//end moveRight

function moveLeft(){
	
}//end moveLeft




//--------------------GALLERY SAMPLE
//var index = 0;
function moveGallery(direction){
	
}//end moveGallery









