/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 6_functions
 * spec         : 6-2_function_parameters
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("function parameters", function () {
	xit("1 - understanding how parameters are passed in javascript", function () {
		var inc = function (first, second) {
			return first + (second || 1);
		};
		expect(inc(100, 23)).toBe(__);//
		expect(inc(100)).toBe(__);//

	});
	
	xit("2 - understanding parameters", function () {
		var f = function (arg) {
			delete arg;
			return arg;
		};
		expect(f(123)).toBe(__);//
	});
	
	xit("3 - understanding implicit parameter 'arguments'", function () {
		var dec = function () {
			return arguments[0] - (arguments[1] || 1);
		};
		expect(dec(123, 23)).toBe(__);//
		expect(dec(101)).toBe(__);//
	});
	
	xit("4 - understanding implicit parameter 'arguments'", function () {
		var f = function (first, second, third) {
			arguments[2] = 4;
			return first + second + third;
		};
		expect(f(1, 2, 3)).toBe(__);//
	});
	
	xit("5 - understanding implicit parameter 'arguments'", function () {
		var typeOfArguments = function () {
			return typeof arguments;
		};
		expect(typeOfArguments(1, 2, 3)).toBe(__);//
	});
	
	xit("6 - understanding arguments.callee", function () {
		(function (a, b, c) {
			var l = arguments.callee.arguments.length;//explain this
			expect( l ).toBe(__); //
		})(1, 2, 3, 4);
	});
	
	xit("7 - understanding arguments", function () {
		var f = function () {
			if (arguments.length === 1) {
				return;
			} else if (arguments.length === 2) {
				return;
			} else {
				throw "incorrect number of parameters";
			}
		}, result;
		expect(f(3)).toBe(__);//
		expect(f(2, 3)).toBe(__);//
		try {
			result = f(2, 3, undefined);
		} catch (error) {
			result = "error";
		}
		expect(result).toBe(__);//
	});
	
	xit("8 - understanding function length", function () {
		var f = function (first, second) {
		};
		expect(f.length).toBe(__);//
	});
});
