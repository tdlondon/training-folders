/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 6_functions
 * spec         : 6-5_prototype
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("prototype", function () {
	xit("1 - understanding prototype", function () {
		var Person = function () {
		}, instance;
		Person.prototype = {
			name: "john doe"
		};
		instance = new Person();
		expect(instance.name).toBe(__);//
	});
	
	xit("2 - understanding prototype", function () {
		var Person = function () {
		}, instance;
		instance = new Person();
		Person.prototype = {
			name: "john doe"
		};
		expect(instance.name).toBe(__);//
	});
	
	xit("3 - understanding prototype & delete", function () {
		var Person = function () {
		}, instance;
		Person.prototype.name = "john doe";
		instance = new Person();
		expect(instance.name).toBe(__);//
		delete Person.prototype.name;
		expect(instance.name).toBe(__);//
	});
});
