/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 6_functions
 * spec         : 6-3_invocation_patterns
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("Invocation patterns", function () {
	var that, storeThis, actor;
	beforeEach(function () {
		that = undefined;
		storeThis = function () {
			that = this;
		};
		actor = {
			storeThis: storeThis
		};
	});
	describe("method", function () {
		xit("1 - understanding method invocation pattern", function () {
			actor.storeThis();
			expect(that).toBe(__);//
		});
		
		xit("2 - understanding method invocation pattern", function () {
			var actor2 = {
				storeThis: actor.storeThis
			};
			actor2.storeThis();
			expect(that).toBe(__);//
		});
		
		xit("3 - understanding method invocation pattern", function () {
			var actor2 = {
				actor: actor,
				storeThis: actor.storeThis
			};
			actor2.actor.storeThis();
			expect(that).toBe(__);//
			actor2.storeThis();
			expect(that).toBe(__);//
		});
	});
	
	/**
	* careful! this is a new suite!
	*/

	describe("function", function () {
		xit("4 - understanding function invocation pattern", function () {
			storeThis();
			expect(that).toBe(__);//
		});
		
		xit("5 - understanding function invocation pattern", function () {
			//try and decipher this for bonus points
			var result = (function () {
				return this;
			}());
			expect(result).toBe(__);//
		});
		
		xit("6 - understanding function invocation pattern", function () {
			var myStoreThis = actor.storeThis;
			storeThis();
			expect(that).toBe(__);//
			actor.storeThis();
			expect(that).toBe(__);//
			myStoreThis();
			expect(that).toBe(__);//
		});


		xit("7 - understanding strict mode", function () {
			var that, strictStoreThis = function () {
				"use strict";//without use strict => that -> window
				/**
				 *	use strict prevents pointing to window
				 *	https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Strict_mode
				 */

				that = this;
			};
			strictStoreThis();
			expect(that).toBe(__);//
		});
	});

	describe("constructor", function () {
		xit("8 - understanding constructor invocation pattern", function () {
			
			var Constructor1 = storeThis, Constructor2 = actor.storeThis, s1, s2, s3, s4;
			s1 = new Constructor1();
			expect(that).toBe(__);//
			s2 = new Constructor2();
			expect(that).toBe(__);//
			s3 = new storeThis();
			expect(that).toBe(__);//
			s4 = new actor.storeThis();
			expect(that).toBe(__);//
		});
		
		xit("9 - understanding constructor invocation pattern", function () {
			var Actor = function (name) {
				//in Actor name is not a property
				this.getName = function () {
					return name;
				};
				this.setName = function (value) {
					name = value;
				};
			}, name = "Robert De Niro", actor = new Actor(name);
			expect(name).toBe(__);//
			expect(actor.name).toBe(__);//
			expect(actor.getName()).toBe(__);//
			actor.setName("Viggo Mortensen");
			expect(name).toBe(__);//
			expect(actor.getName()).toBe(__);//
			//
			actor.name = "Robert De Niro";
			expect(actor.name).toBe(__);//
			expect(actor.getName()).toBe(__);//
		});
		
		xit("10 - understanding instanceof", function () {
			var Actor = function (name) {
				this.getName = function () {
					return name;
				};
				this.setName = function (value) {
					name = value;
				};
			}, actor = new Actor("Robert De Niro");
			expect(actor instanceof Actor).toBe(__);//
			expect(actor instanceof Object).toBe(__);//
			expect(actor instanceof Array).toBe(__);//
			expect(actor.constructor).toBe(__);//
		});
	});

	describe("call/apply", function () {
		xit("11 - understanding call-apply invocation pattern", function () {
			var actor2 = {
				storeThis: storeThis
			}, actor3 = {};
			actor.storeThis.call(actor2);//
			expect(that).toBe(__);//
			actor.storeThis.apply(actor3, []);
			expect(that).toBe(__);//
		});
	});

	
});
