/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 6_functions
 * spec         : 6-1_function_declaration
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("function expression and function declaration", function () {
	xit("1 - understanding function expression", function () {
		expect(typeof f).toBe(__);//
		var f = function () {
			return 123;
		}, g = f;
		expect(typeof f).toBe(__);//
		expect(f()).toBe(__);//
		expect(f === g).toBe(__);//
	});
	
	xit("2 - understanding function declaration", function () {
		expect(typeof f).toBe(__);//
		function f() {
			return 123;
		}
		expect(typeof f).toBe(__);//
		expect(f()).toBe(__);//
	});
	
	xit("3 - understanding function declaration", function () {
		var f, result;
		expect(typeof f).toBe(__);//
		expect(typeof g).toBe(__);//
		f = function g() {//
			return 123; //
		};
		expect(typeof f).toBe(__);//
		expect(typeof g).toBe(__);//
		expect(f()).toBe(__);//
		try {
			result = g();//
		} catch (error) {
			result = "error";
		}
		expect(result).toBe(__);//
		if (typeof g !== "undefined") {
			expect(f === g).toBe(__);//
		}
	});
	
	xit("4 - understanding function declaration", function () {
		var result = 1;
		if (function f() {}) {
			result += typeof f;
		}
		expect(result).toBe(__);//
	});
	
	xit("5 - debugger and call stack in webDev - I", function () {
		//ANONYMOUS
		//uncomment the line below and run the test; check the call stack
		//debugger; //*****  creates a breakpoint ******
	});
	
	xit("6 - debugger and call stack in webDev - II", function foo() {
		//NO LONGER ANONYMOUS 
		//uncomment the line below and run the test; check the call stack; compare with previous one
		var a = 123; //try to access a in console
		debugger;
	});
});
