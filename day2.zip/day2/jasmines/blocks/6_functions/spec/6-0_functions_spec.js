/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 6_functions
 * spec         : 6-0_functions_spec
 **/


describe("function declaration", function() {
    it('declaration, expression, anonymous', function(){
        //function literal
        function foo(){
            console.log('foo');
        }

        //function expression
        var bar = function(){
            console.log("bar");
        };

        //anonymous function
        window.onblur = function(){
            console.log('anonymous')
        }
        expect(typeof foo).toBe('function');
        expect(typeof bar).toBe('function');
    });
});


describe("function hoisting - I", function() {
    it('function literal and function declaration', function(){

        expect(typeof foo).toBe('function');
        expect(typeof bar).toBe('undefined');

        //literal => hoisted and accessible before definition
        function foo(){ console.log('foo'); }

        //declaration => only var declaration is hoisted (not value)
        var bar = function(){ console.log('bar'); }
        expect(typeof foo).toBe('function');
        expect(typeof bar).toBe('function');
    });
});

describe("function hoisting - II", function() {
    it("function literal accessible even if after return", function(){
        expect(foo(5)).toBe(5);

        return 123; // code execution stops here

        //literal => hoisted and accessible before definition
        function foo(param){ return param ; }

    });
});

describe("function hoisting - III", function() {
    it("conditional declarations do not work", function(){
        var test = true;
        if(test){
            function foo(){ return 123 ; }
        } else {
            function foo(){ return 'abc' ; }
        }

        expect(foo()).toBe('abc');
    });
});


describe("function invocation - I", function() {
    it("literals, methods, constructors, IIFs", function(){
        var o = {a:1, foo : function(){return "foo";} },
            Person = function(name){this.name = name},
            jim,
            bar = function(){return "bar";}
            ;
        //function invocation
        expect( bar() ).toBe("bar");
        //method invocation
        expect( o.foo() ).toBe("foo");
        //constructor
        jim = new Person("JIM");
        expect( jim.name ).toBe("JIM");
        //Immediately Invoked Function
        expect(  (function(){return 123;})() ).toBe(123);
    });
});

describe("function invocation - II", function() {
    it("IIFs and foo declaration", function(){
        var
            //function declaration
            foo = function(){ return "foo";},
            //IIF!!
            bar = (function(){return "IIF"})()
        ;
        expect( typeof foo ).toBe("function");
        expect( typeof bar ).toBe("string");
    });
});


describe("returning values - I", function() {
    it("implicit return", function(){
        expect(typeof console.log('foo')).toBe("undefined");
    });
});

describe("returning values - II", function() {
    it("explicit return", function(){
        var foo = function(){return "foo";}
        expect(foo()).toBe("foo");
    });
});

describe("returning values - III", function() {
    it("code after return is not executed", function(){
        var a, foo = function(){return "foo"; a = 123;}
        expect(foo()).toBe("foo");
        expect(a).toBeUndefined();
    });
});

describe("returning values - IV", function() {
    it("constructor invocations return constructed object", function(){
        var Person = function(name){this.name = name},
            jim
        ;
        expect(jim).toBeUndefined();
        jim = new Person("JIM");

        expect(typeof jim).toBe("object");
    });
});


describe("parameters - I", function() {
    it("missing parameters are set to undefined", function(){
        (
            function(a, b){
                expect(a).toBe(123);
                expect(typeof b).toBe("undefined");
            }
        )(123);
    });
});

describe("parameters - II", function() {
    it("extra parameters are ignored", function(){
        (
            function(a, b){
                expect(a).toBe(123);
                expect(b).toBe("abc");
                //how do we get the third param??
            }
        )(123, 'abc', 555);
    });
});

describe("parameters - III", function() {
    it("callbacks: functions as parameters", function(){
        var
            n = 555;
            addOne = function(a){return a+=1;},
            subtractOne = function(a){return a-=1;},
            modifyNum = function(a, fn){return fn(a);}
        ;

        //parsing callbacks to ModifyNum
        expect( modifyNum(n, addOne) ).toBe(556);
        expect( modifyNum(n, subtractOne) ).toBe(554);
        //expect( modifyNum(n, alert) ).toBe(554);
    });
});

describe("parameters - IV", function() {
    it("length", function(){
       var foo = function(a, b, c){return 'done';}

        expect(foo.length).toBe(3);
    });
});

describe("arguments - II", function() {
    it("array-like object", function(){
        (function(a,b,c){
            expect(typeof arguments).toBe("object");
            expect(arguments.length).toBe(3);
            expect(Array.isArray(arguments)).not.toBe(true);
        })(1,2,3);
    });
});

describe("arguments - III", function() {
    it("arguments vs function.lenght", function(){
        function foo(a, b, c){
            return arguments.length;
        }
        var noOfArguments = foo(1, 2, 3, 4);
        expect(noOfArguments).toBe(4);
        expect(foo.length).toBe(3)
    });
});

describe("arguments - IV", function() {
    it("arguments.callee", function(){
        (function(a, b, c){
            expect(typeof arguments.callee).toBe("function");
            expect(arguments.callee.length).toBe(3);
        })();
    });
});


describe("function overload", function() {
    it("different behaviours according to number of arguments", function(){
        var greet = function(p1,p2){
            if(typeof p1 !== "undefined" && typeof p2 !== "undefined"){
                return "Hello, " + p2 + " my name is " + p1 + ".";
            }

            if(typeof p1 !== "undefined" && typeof p2 === "undefined"){
                return "Hello, my name is " + p1 + ".";
            }
        }

        expect(greet("jack", "jill")).toBe("Hello, jill my name is jack.");
        expect(greet("john doe")).toBe("Hello, my name is john doe.");

    });
});


describe("this and invocation patterns - I", function() {
    it("function invocation", function(){
        var foo = function(){
            return this;
        }
        expect(foo()).toEqual(window);
        //<global> in JASMINE
    });
});

describe("this and invocation patterns - II", function() {
    it("method invocation", function(){
        var person = {
            name : "john doe",
            greet : function(){
                return "Hello, my name is " + this.name;
                expect(this).toEqual(person);
                expect(this.name).toBe("john doe");
            }
        }
    });
});

describe("this and invocation patterns - III", function() {
    it("constructors invocation", function(){
        var
            Person = function(n){
                this.name = n,
                this.greet = function(){
                    return "Hello, my name is " + this.name;
                }
            }, p = new Person("john smith")
        ;
        expect(p.name).toBe("john smith");
    });
});

describe("troubles in function invocation pattern - I", function() {
    it("global namespace pollution", function(){
        var setName = function(n){
            this.name = n;
        };
        setName("john smith");
        expect(window.name).toBe("john smith");
    });
});

describe("troubles in function invocation pattern - II", function() {
    it("function inside a function", function(){
        var person = {
            setName : function(val){
                console.log('1' , this);
                var setFirstAndLast = function(f, l){
                    console.log('2' , this);
                    this.first = f;
                    this.last = l;
                }, fn = val[0], ln = val[1];

                setFirstAndLast(fn, ln);

            }//end setName
        }//end Person

        person.setName(["john", "smith"]);

        expect(person.first).toBeUndefined();
        expect(window.first).toBe("john");
    });
});


describe("troubles in function invocation pattern - III", function() {
    it("solution: store 'this' in 'that' ", function(){
        var person = {
            setName : function(val){
                console.log('1' , this);
                var that = this,
                    setFirstAndLast = function(f, l){
                        console.log('2' , that);
                        that.first = f;
                        that.last = l;
                    }, fn = val[0], ln = val[1];

                setFirstAndLast(fn, ln);

            }//end setName
        }//end Person

        person.setName(["john", "smith"]);

        expect(person.first).toBe("john");
        expect(person.last).toBe("smith");
    });
});

describe("troubles in function invocation pattern - IV", function() {
    it("solution: always use name of outer object ", function(){
        var person = {
            setName : function(val){
                var
                    setFirstAndLast = function(f, l){
                        person.first = f;
                        person.last = l;
                    }, fn = val[0], ln = val[1]
                ;
                setFirstAndLast(fn, ln);
            }//end setName
        }//end Person

        person.setName(["john", "smith"]);

        expect(person.first).toBe("john");
        expect(person.last).toBe("smith");
    });
});

describe("troubles in function invocation pattern - V", function() {
    it("using constructors without new operator", function(){
        var Person = function(n){
            this.name = n;
            this.greet = function(){console.log("hello");}
            }, p = Person("john doe");
        expect(p).toBeUndefined();
        expect(window.name).toBe("john doe");
    });
});

describe("call and apply - I", function() {
    it("call", function(){
        var
            person = {
                firstName : "john",
                lastName : "doe"
            },
            setName = function(n,l){
                this.firstName = n;
                this.lastName = l;
            }
        ;
        //this inside setName now points to person
        setName.call(person, "BOB", "REINER");
        expect(person.firstName).toBe("BOB");
        expect(person.lastName).toBe("REINER");
    });
});

describe("call and apply - II", function() {
    it("apply", function(){
        var
            person = {
                firstName : "john",
                lastName : "doe"
            },
            setName = function(n,l){
                this.firstName = n;
                this.lastName = l;
            }
            ;
        //this inside setName now points to person
        setName.apply(person, ["BOB", "REINER"]);
        expect(person.firstName).toBe("BOB");
        expect(person.lastName).toBe("REINER");
    });
});

describe("prototype - I", function() {
    it("prototype vs constructor", function(){
        var f = function(){};

        expect(f.constructor).toBe(Function);
        expect(f.prototype).toBeDefined();
        expect(typeof f.prototype).toBe("object");
    });
});

describe("prototype - II", function() {
    it("inherit from prototype", function(){
        var Person = function(n){
            this.name = n;
        }, p = new Person("Ben"), p2 = new Person("Robert");

        Person.prototype.talk = function(){return "I can talk";};

        expect( Person.prototype.isPrototypeOf(p) ).toBe(true);
        expect(typeof p.talk).toBe("function");
        expect( p2.talk() ).toBe("I can talk");
    });
});

describe("prototype - III", function() {
    it("overriding prototype members", function(){
        var Person = function(n){
            this.name = n;
        }, p = new Person("Ben"), p2 = new Person("Wong Fei Hung");
        Person.prototype.talk = function(){return "I speak English";};
        //overriding prototype method
        p2.talk = function(){return "Wo hai shuo putonghua";}
        expect( Person.prototype.isPrototypeOf(p2) ).toBe(true);
        expect(p.talk() ).toBe("I speak English");
        expect( p2.talk() ).toBe("Wo hai shuo putonghua");
    });
});

describe("prototype - IV", function() {
    it("deleting own members to expose prototype ones", function(){
        var Person = function(n){
            this.name = n;
        }, p = new Person("Ben"), p2 = new Person("Wong Fei Hung");
        Person.prototype.talk = function(){return "I speak English";};
        //overriding prototype method
        p2.talk = function(){return "Wo hai shuo putonghua";}
        expect(delete p2.talk).toBe(true); //EXPLAIN THIS!
        expect( Person.prototype.isPrototypeOf(p2) ).toBe(true);
        expect(p2.talk() ).toBe("I speak English");
    });
});

describe("prototype - V", function() {
    it("augmenting Array.prototype to supply missing features", function(){
        Array.prototype.inArray = function(el){
            var i = 0, l = this.length;
            for(;i<l;i++){
                if(this[i] === el){
                    return true
                }
            }
            return false;
        };

        var names = ["bill", "bob", "becky"], needle = "bob";
        expect(names.inArray(needle)).toBe(true);
        expect(names.inArray("james")).toBe(false);
    });
});

describe("prototype - VI", function() {
    it("using different object prototype - PART I", function(){
        //augmenting Array
        Array.prototype.inArray = function(el){
        var i = 0, l = this.length;
        for(;i<l;i++){if(this[i] === el){return true}
        }return false;};

        var str = "a string";
        //using Array prototype
        expect(Array.prototype.inArray.call(str, 't')).toBe(true);
        //using [] to represent Array
        expect([].inArray.call(str, 'b')).toBe(false);
    });
});

describe("prototype - VII", function() {
    it("using different object prototype - PART II", function(){
        //augmenting Array
        Array.prototype.inArray = function(el){
            var i = 0, l = this.length;
            for(;i<l;i++){if(this[i] === el){return true}
            }return false;};
        //augmenting String
        String.prototype.contain = function(char){
            return [].inArray.call(this,  char);
        }
        var str = "a string";
        //using new augmented prototype method
        expect( str.contain('t') ).toBe(true);
        expect( str.contain('k') ).toBe(false);
    });
});

describe("closure - I", function() {
    it("lexical scope", function(){
        //a exists in foo scope...
        function foo(){var a = 123; foo2();}
        //..but not yet in foo2 scope
        function foo2(){return typeof a}

        expect( foo() ).toBeUndefined();
    });
});

describe("closure - II", function() {
    it("returning inner foos", function(){
        function foo(){var a = 123; return foo2();}
        function foo2(){return a}
        var a = 3;
        //foo2 now access the global a
        expect( foo() ).toBe(3);
        a = 5;
        //...and it "watches" its state
        expect( foo() ).toBe(5);
    });
});

describe("closure - III", function() {
    it("getters and setters", function(){
        var getSecret, setSecret;
        (function(){
            var secret = "123";
            getSecret = function(){return secret;}
            setSecret = function(val){secret = val;}
        }
        )();
        //cannot access secret directly
        expect( typeof secret ).toBe("undefined");
        //...but can use a getter to get it
        expect( getSecret() ).toBe("123");
        //...or a setter to set it
        setSecret("abc");
        expect( getSecret() ).toBe("abc");
    });
});