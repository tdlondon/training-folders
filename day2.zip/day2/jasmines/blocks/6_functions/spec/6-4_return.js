/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 6_functions
 * spec         : 6-4_return
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("return", function () {
	xit("1 - understanding return", function () {
		var Actor = function (name) {
			this.name = name;
		}, actor = new Actor("Al Pacino");
		expect(Actor("Al Pacino")).toBe(__);//
		expect(actor.name).toBe(__);//
		expect(actor instanceof Actor).toBe(__);//
		expect(actor.constructor).toBe(__);//
	});
	
	xit("2 - understanding return", function () {
		var Actor = function (name) {
			this.name = name;
			return 1;	//also try with 0, true, false, "string", null, undefined
		}, actor = new Actor("Al Pacino");
		expect(actor.name).toBe(__);//
		expect(actor instanceof Actor).toBe(__);//
		expect(actor.constructor).toBe(__);//
	});
	
	xit("3 - understanding return", function () {
		var Actor = function (name) {
			return {
				name: name
			};
		}, actor = new Actor("Al Pacino");
		expect(actor.name).toBe(__);//
		expect(actor instanceof Actor).toBe(__);//
		expect(actor.constructor).toBe(__);//
	});
	
	xit("4 - understanding return - missing new constructor", function () {
		var Actor = function (name) {
			//implement this to pass tests
			if(!(this instanceof Actor)){

                __;     //implement this block
			}
			this.name = name;
			
		}, actor1 = Actor("Al Pacino"), actor2 = new Actor("Al Pacino");
		expect(actor1 instanceof Actor).toBe(true);
		expect(actor1.name).toBe("Al Pacino");
		expect(actor2 instanceof Actor).toBe(true);
		expect(actor2.name).toBe("Al Pacino");
	});
});
