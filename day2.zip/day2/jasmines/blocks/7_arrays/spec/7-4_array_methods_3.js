/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 7_arrays
 * spec         : 7-4_array_methods_3
 **/


/**
 * notes: 
 *
 **/
describe("Array methods - III :", function () {
	var __ = null;
	it("1 - understanding filter", function () {
		var array = [1, 2, 3, 4, 5, 4, 3, 2, 1];
		expect(array.filter(function (element) {
			return element <= 3;
		})).toEqual(__);//
	});
	
	it("2 - understanding forEach", function () {
		var array = [1, 2, 3, 4, 5], result = 0;
		array.forEach(function (element) {
			result += element;
		});
		expect(result).toBe(__);//
	});
	
	it("3 - understanding every", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.every(function (element, index) {
			return element > index;
		})).toEqual(__);//
	});
	
	it("4 - understanding some", function () {
		var array = [1, 2, 3, 4, 5], isNegative = function (element) {
			return element < 0;
		};
		expect(array.some(isNegative)).toBe(__);//
		array[2] = -array[2];
		expect(array.some(isNegative)).toBe(__);//
	});
});
