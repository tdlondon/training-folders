/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 7_arrays
 * spec         : 7-2_array_methods_1
 **/


/**
 * notes:
 *
 **/
describe("Array methods - I :", function () {
	var __ = null;
	xit("1 - understanding push", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.push(6, 7)).toBe(__);	//
		expect(array).toEqual([1, 2, 3, 4, 5,6,7]);//
		expect(array.length).toBe(__);//
		array.length = 10;
		array.push(8, 9);
		expect(array).toEqual([__]);//
		expect(array.length).toBe(__);//
	});
	
	xit("2 - understanding pop", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.pop()).toBe(5);//
		expect(array).toEqual([__]);//
		array.length = 10;
		expect(array.pop()).toBe(__);//
		expect(array).toEqual([__]);//
	});
	
	xit("3 - understanding shift", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.shift()).toBe(__);//
		expect(array).toEqual([__]);//
		array = [, , , 3, 4, 5];
		expect(array.shift()).toBe(__);//
		expect(array).toEqual([__]);//
	});
	
	xit("4 - understanding unshift", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.unshift(6, 7)).toBe(__);//
		expect(array).toEqual([ __ ]);//
		array = [, , , 3, 4, 5];
		expect(array.unshift(6, 7)).toBe(__);//
		expect(array).toEqual([ __ ]);//
	});
	
	xit("5 - understanding splice", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.splice(1, 2)).toEqual([ __ ]);//
		expect(array).toEqual([ __ ]);//
	});
	
	xit("6 - understanding splice", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.splice(1, 2, 21, 31)).toEqual([__]);//
		expect(array).toEqual([__]);//
	});
	
	xit("7 - understanding reverse", function () {
		var array = [1, 2, 3, 4, 5];
		expect(typeof array.reverse()).toBe(__);//
		expect(array).toEqual([ __ ]);//
	});
	
	xit("8 - understanding sort", function () {
		var array = [1, 3, 5, 7, 9, 11, 13, 15, 2, 4, 6, 8, 10, 12, 14, 16];
		expect(array.sort()).toEqual([ __ ]);//
	});
	
	xit("9 - understanding sort", function () {
		var array = [1, 3, 5, 7, 9, 11, 13, 15, 2, 4, 6, 8, 10, 12, 14, 16],
			compareFunction = function (first, second) {
				//implement this so that test is passing
                __;
			};
		expect([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]).toEqual(array.sort(compareFunction));
	});
});
