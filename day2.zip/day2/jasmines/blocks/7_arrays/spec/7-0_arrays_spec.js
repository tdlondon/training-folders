/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 7_arrays
 * spec         : 7-0_arrays_spec
 **/


describe("creating array - I", function() {
    it("Array constructor", function(){
        var actors = new Array("Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh");

        expect(typeof actors).toBe("object");
    });
});

describe("creating array - II", function() {
    it("array literal", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];

        expect(typeof actors).toBe("object");
    });
});

describe("creating array - III", function() {
    it("split?", function(){
        var string = "Ben-Kingsley Michael-Caine Jude-Law Kenneth-Branagh";
        //split generates an array dividing a string using given param
        var actors = string.split(' ');
        expect(typeof actors).toBe("object");
        expect(actors).toEqual(["Ben-Kingsley", "Michael-Caine", "Jude-Law", "Kenneth-Branagh"]);
    });
});

describe("distinguish arrays from objects - I", function() {
    it("constructor", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];

        expect(actors.constructor === Array).toBe(true);
    });
});

describe("distinguish arrays from objects - II", function() {
    it("instanceof", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];

        expect( actors instanceof Array  ).toBe(true);
    });
});

describe("distinguish arrays from objects - III", function() {
    it("Array.isArray", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];

        expect(Array.isArray(actors) ).toBe(true);
    });
});

describe("retrieving elements", function() {
    it("[] notation", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"], index = 3;

        expect( actors[0] ).toBe("Ben Kingsley");
        //actors.0 would not work
        expect( actors[index] ).toBe("Kenneth Branagh");
    });
});

describe("length - I", function() {
    it("number of elements", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];

        expect( actors.length ).toBe(4);
    });
});

describe("length - II", function() {
    it("writable property", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];
        actors.length = 2;
        expect( actors.length ).toBe(2);
        expect( actors ).toEqual(["Ben Kingsley", "Michael Caine"]);
    });
});

describe("length - III", function() {
    it("length is the last integer + 1", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];
        actors[10] = "Ray Winstone";
        expect( actors.length ).toBe(11);
        expect( actors[7] ).toBe(undefined);
    });
});

describe("length - IV", function() {
    it("maximum length", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];
        //maximum lenght is 2pow32-1 = 4,294,967,295
        expect(actors[4294967295] = "sylvester stallone").toBeTruthy();
        //stallone does not get stored (I know, he's not an actor...)
        expect( actors.length ).toBe(4);
        actors[4294967294] = "chuck norris";
        //chuck gets there, (I was afraid of spinning back kicks...)
        expect( actors[4294967294] ).toBe("chuck norris");
        expect( actors.length ).toBe(4294967295);
    });
});


describe("modifying arrays", function() {
    it("changing elements values", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];
        actors[2] = "Jason Flemying";
        expect( actors[2]).toBe("Jason Flemying");
        actors[4] = "Ray Winstone";
        expect( actors.length ).toBe(5);
    });
});

describe("deleting elements - I", function() {
    it("can use delete operator", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];
        delete actors[2];
        //deleted elements keep existing as undefined
        expect( actors[2]).toBe(undefined);
        //length does not change
        expect( actors.length ).toBe(4);
    });
});

describe("deleting elements - II", function() {
    it("better using splice", function(){
        var actors = ["Ben Kingsley", "Michael Caine", "Jude Law", "Kenneth Branagh"];
        actors.splice(2,1);

        //length does change
        expect( actors.length ).toBe(3);
        expect( actors ).toEqual(["Ben Kingsley", "Michael Caine", "Kenneth Branagh"]);
    });
});

describe("iterating arrays - I", function() {
    it("for loop", function(){
        var
            str = "",
            actors = ["Ben", "Michael", "Jude", "Kenneth"],
            i= 0, l = actors.length
        ;
        for(;i< l; i++){ str += actors[i] + " "; }

        expect( str ).toBe("Ben Michael Jude Kenneth ");
    });
});

describe("iterating arrays - II", function() {
    it("for-in loop", function(){
        var
            str = "",
            actors = ["Ben", "Michael", "Jude", "Kenneth"],
            i= 0
            ;
        for(i in actors){ str += actors[i] + " "; }

        expect( str ).toBe("Ben Michael Jude Kenneth ");
    });
});

describe("iterating arrays - III", function() {
    it("for-in loop issue", function(){
        var
            str = "",
            actors = ["Ben", "Michael", "Jude", "Kenneth"],
            key
        ;
        actors['prop'] = "something wrong";
        for(key in actors){ str += actors[key] + ", "; }

        expect( str ).not.toBe("Ben, Michael, Jude, Kenneth, ");
        expect( str ).toBe("Ben, Michael, Jude, Kenneth, something wrong, ");
    });
});

describe("array methods - I", function() {
    it("CONCAT joins two arrays", function(){
        var chars = ["a", "b", "c"], numbs = [1,2,3], arr;
        arr = chars.concat(numbs);
        expect( arr ).toEqual(["a", "b", "c", 1, 2, 3]);
    });

    it("JOIN outputs a string with elements alternated by given param", function(){
        var actors = ["Ben", "Michael", "Jude", "Kenneth"], str = "";
        str = actors.join(" & ");
        expect( str ).toEqual("Ben & Michael & Jude & Kenneth");
    });
});

describe("array methods - II", function() {
    it("PUSH adds given elements at the END of an array", function(){
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        actors.push("Hurt", "Winstone");
        expect( actors.length ).toBe(6);
    });

    it("POP removes and returns LAST element of an array", function(){
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        expect( actors.pop() ).toEqual("Branagh");
        expect( actors.length ).toBe(3);
    });
});

describe("array methods - III", function() {
    it("SHIFT removes and returns FIRST element of an array", function(){
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        expect( actors.shift()).toBe("Kingsley");
        expect( actors.length ).toBe(3);
    });

    it("UNSHIFT adds given elements at the BEGINNING of an array", function(){
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        actors.unshift("Hurt", "Winstone");
        expect( actors[0] ).toBe("Hurt");
    });
});

describe("array methods - IV", function() {
    it("SORT can sort element of arrays, can accept sorting method", function(){
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        expect( actors.sort()).toEqual(["Branagh", "Caine", "Kingsley", "Law"]);
        expect(
            actors.sort( function(a,b){return b > a;} )
        ).toEqual(["Law", "Kingsley", "Caine", "Branagh"]);
    });

    it("REVERSE inverts order of elements", function(){
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        actors.reverse();
        expect( actors[0] ).toBe("Branagh");
    });
});

describe("array methods - V", function() {
    it("SLICE extracts and returns portion of an array", function(){
        //arr.slice(begin [,end]) => end element not included
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        expect( actors.slice(1,3)).toEqual(["Caine", "Law"]);
        expect( actors.slice(1)).toEqual(["Caine", "Law", "Branagh"]);
    });

    it("SPLICE adds and/or removes elements from arrays", function(){
        //arr.splice(index ,howMany, [elements])
        var actors = ["Kingsley", "Caine", "Law", "Branagh"];
        expect( actors.splice(1,1) ).toEqual(["Caine"]);
        expect( actors ).toEqual(["Kingsley", "Law", "Branagh"]);
        expect( actors.splice(1,1, "Hurt") ).toEqual(["Law"]);
        expect( actors ).toEqual(["Kingsley", "Hurt", "Branagh"]);
    });
});

describe("array methods - VI", function() {
    it("EVERY makes sure that all elements satisfy given callback", function(){
        //bool  arr.every(callback [,thisArg]) => thisArg -> this
        var isNotUndefined = function(val){return val !== undefined},
            actors = ["Kingsley", "Caine", "Law", "Branagh"];
        expect( actors.every(isNotUndefined)).toBe(true);
        expect( [1, undefined, 3].every(isNotUndefined)).toBe(false);
    });

    it("SOME makes sure that at least one element satisfies given callback", function(){
        //bool  arr.some(callback [,thisArg]) => thisArg -> this
        var isNotNull = function(val){return val !== null},
            actors = ["Kingsley", "Caine", "Law", "Branagh"];
        expect( actors.some(isNotNull)).toBe(true);
        expect( [null, null, 3].some(isNotNull)).toBe(true);
        expect( [null, null].some(isNotNull)).toBe(false);
    });
});

describe("array methods - VII", function() {
    it("FOREACH executes given callback for every array element", function(){
        //bool  arr.foreach(callback [,thisArg]) => thisArg -> this
        var addOne = function(val, index, arr){ arr[index] +=1 },
            numbs = [1, 2, 3];
        numbs.forEach(addOne);
        expect( numbs).toEqual([ 2, 3, 4 ]);
    });

    it("FILTER creates a new array with elements that satisfy given callback",
        function(){
        //bool  arr.filter(callback [,thisArg]) => thisArg -> this
        var isNotNull = function(val){return val !== null},
            actors = ["Kingsley", null, "Law", "Branagh"];
        expect( actors.filter(isNotNull)).toEqual(["Kingsley", "Law", "Branagh"]);
    });
});