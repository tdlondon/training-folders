/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 7_arrays
 * spec         : 7-6_array_methods_5
 **/


/**
 * notes: 
 *
 **/
var __ = null;
describe("Array methods - V :", function () {
	var 
		a = "a nut for a jar of tuna",
		b = "a Toyota's a Toyota",
		c = "Amy must I jujitsu my ma",
		d = "a dog can panic in a pagoda",
		e = "the quick brown Fox jumps over the lazy dog",
		f = "Quick fox jumps nightly above lizard",
		g = "pack my box with FIVE dozen liquor jugs",
		alphabetStr = "a-b-c-d-e-f-g-h-i-j-k-l-m-n-o-p-q-r-s-t-u-v-w-x-y-z",
		
		/** 
		* implement isPalindrome() and isPangram() to make tests pass
		* help: you may need some of  join, reverse, toString, filter, split, indexOf	
		*/
		
		isPalindrome = function(str){
			//1- cast str as string and lowercase

			
			//2- create a filtering foo to get rid of spaces

			
			//3- make sure that filtered string is equals to reversed filtered string

		},
		isPangram = function(str){
			//1- cast str as string and lowercase

			
			//2- create a filtering foo to get rid of spaces

			
			//3- create a filtering foo to get rid of duplicates

			
			//4 sorting and filtering


			//make sure that manipulate string is equals to alphabetString

		}
	;
	xit("1 - testing palindromes", function () {
		
		expect(isPalindrome(a)).toBe(true);
		expect(isPalindrome(b)).toBe(false);
		expect(isPalindrome(c)).toBe(true);
		expect(isPalindrome(d)).toBe(false);
	});
	
	xit("2 - testing pangrams", function () {
		expect(isPangram(e)).toBe(true);
		expect(isPangram(f)).toBe(false);
		expect(isPangram(g)).toBe(true);
	});
	
});
