/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 7_arrays
 * spec         : 7-3_array_methods_2
 **/


/**
 * notes:
 *
 **/
describe("Array methods - II :", function () {
	var __ = null;
	xit("1 - understanding concat", function () {
		var first = [1, 2, 3], second = [4, 5, 6];
		expect(first.concat(second)).toEqual(__);//
		expect(first).toEqual(__);//
		expect(second).toEqual(__);//
	});
	
	xit("2 - understanding join", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.join("-")).toBe(__);//
	});
	
	xit("3 - understanding join", function () {
		var array = new Array(5);
		expect(array.join(" -")).toBe(__);//
	});
	
	xit("4 - understanding split", function () {
		expect("1-2-3-4-5-6-7-8-9-10".split("-")).toEqual(__);//
	});
	
	xit("5 - understanding split", function () {
		expect(".-.-.-.-.-.-.-.-.-.".split("-")).toEqual(__);//
	});
	
	xit("6 - understanding join and split", function () {
		expect(new Array(10).join("._").split("-")).toEqual(__);//
	});
	
	xit("7 - understanding slice", function () {
		var array = [1, 2, 3, 4, 5];
		expect(array.slice(1, 4)).toEqual(__);//
		expect(array).toEqual(__);//
		expect(array.slice(1)).toEqual(__);//
		expect(array.slice(1, -1)).toEqual(__);//
		expect(array.slice(-3, -1)).toEqual(__);//
	});
	
	xit("8 - understanding toString", function () {
		var array = [1, 3, 5, "hello", 9];
		expect(array.toString()).toBe("__");//
	});

});
