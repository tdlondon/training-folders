/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 7_arrays
 * spec         : 7-1_array_basics
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("Arrays - basics", function () {
	var array, isArray = function (value) {
		return value && typeof value === "object" && value.constructor === Array;
	};
	beforeEach(function () {
		array = [1, 2, 3];
	});
	
	xit("1 - understanding array literals", function () {
		var array = [1, "2", [3], false], returnArguments, args;
		expect(isArray(array)).toBe(__);//
		expect(isArray(array[0])).toBe(__);//
		expect(isArray(array[1])).toBe(__);//
		expect(isArray(array[2])).toBe(__);//
		expect(isArray(array[3])).toBe(__);//
		returnArguments = function () {
			return arguments;
		};
		args = returnArguments(1, 2, 3);
		expect(isArray(args)).toBe(__);//
	});
	
	xit("2 - arguments recap", function () {
		var returnArguments = function () {
			return arguments;
		}, args;
		args = returnArguments(1, 2, 3);
		expect(typeof args).toBe(__);//
		expect(isArray(args)).toBe(__);//
	});
	
	xit("3 - understanding [] operator", function () {
		expect(array[1]).toBe(__);//
		expect(array[3]).toBe(__);//
	});
	
	xit("4 - understanding [] operator", function () {
		array[3] = 4;
		expect(array[3]).toBe(__);//
	});
	
	xit("5 - understanding length property", function () {
		expect(array.length).toBe(__);//
		array[2] = undefined;
		expect(array.length).toBe(__);//
		array[99] = 100;
		expect(array.length).toBe(__);//
		array[200] = undefined;
		expect(array.length).toBe(__);//
	});
	
	xit("6 - understanding length property", function () {
		var array = [1, , , , 5, , , , ];
		expect(array.length).toBe(__);//
	});
	
	xit("7 - understanding delete operator", function () {
		delete array[1];
		expect(array[1]).toBe(__);//
		expect(array.length).toBe(__);//
	});
	
	xit("8 - understanding delete operator", function () {
		delete array[2];
		expect(array.length).toBe(__);//
	});
	
	xit("9 - understanding how for and for..in loops are used for iteration", function () {
		var array = [], i, iterationsFor = 0, name, iterationsForIn = 0;
		array[1000] = 1000;
		for (i = array.length - 1; i >= 0; i -= 1) {
            __; //to do
		}
		for (name in array) {
            __; //to do
		}
		expect(iterationsFor).toBe(1001);//
		expect(iterationsForIn).toBe(1);//
	});
});
