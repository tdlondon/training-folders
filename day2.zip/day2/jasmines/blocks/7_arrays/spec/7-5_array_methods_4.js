/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 7_arrays
 * spec         : 7-5_array_methods_4
 **/


/**
 * notes: 
 *
 **/
describe("Array methods - IV :", function () {
	var __ = null;
	xit("1 - understanding join is a generic method", function () {
		expect(Array.prototype.join.call("Hello", ".")).toBe(__);//
		expect(Array.prototype.join.call({ 0: "Zero", 1: "First", 2: "Second", length: 3 }, "-")).toBe(__);//
		expect(Array.prototype.join.call({ length: 3 }, "-")).toBe(__);//
	});
	
	xit("2 - understanding push is a generic method", function () {
		var obj = { 0: "Zero", 1: "First", 2: "Second", length: 3 };
		expect(Array.prototype.push.call(obj, "Third", "Fourth")).toBe(__);//
		expect(obj).toEqual(__);//
		obj = {};
		expect(Array.prototype.push.call(obj, "BOB", "STANLEY")).toBe(__);//
		expect(obj).toEqual({0:"BOB",1:"STANLEY",length:2});//
	});
	
	xit("3 - understanding that in order to call/apply push method, the underlying object has to be mutable", function () {
		var hello = "Hello";
		expect(Array.prototype.push.call(hello, "!")).toBe(__);//
		//
		expect(hello).toBe(__);//
	});
	
	xit("4 - understanding that pop is generic method", function () {
		var obj = { 0: "Zero", 1: "First", 2: "Second", 3: "Third", 4: "Fourth", length: 3 };
		expect(Array.prototype.pop.apply(obj)).toBe(__);//
		expect(obj).toEqual(__);//
	});
	
	xit("5 - understanding reverse is generic method", function () {
		var obj = { 0: "Zero", 1: "First", 2: "Second", 3: "Third", 4: "Fourth", length: 5 };
		Array.prototype.reverse.apply(obj);
		expect(obj).toEqual(__); //
	});
	
	xit("6 - understanding sort is generic method", function () {
		var obj = { 0: "Zero", 1: "First", 2: "Second", 3: "Third", 4: "Fourth", length: 5 };
		Array.prototype.sort.apply(obj);
		expect(obj).toEqual(__); //
	});
});
