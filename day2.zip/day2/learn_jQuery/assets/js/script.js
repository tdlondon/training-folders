// $(element).foo(params)





	/**
	 *   *** to avoid GLOBAL NAMESPACE POLLUTION,
	 *   we encapsulate all content of our scripts
	 *   into IIFE (read iffy)
	 *   Immediately Invoked Function Expression
	 *   (function(){ all code here })();
	 */




	/**
	 * ready jQuery documentation at https://api.jquery.com/
	 *
	 *  we want to invoke functions only AFTER their declaration
	 */



	/**
	 *  @name   manipulateH3
	 *  @desc   manipulate markup
	 *
	 *  .html()     no params   => read mode
	 *              1 param     => write mode
	 *  .append()
	 *  .prepend()
	 */
	function manipulateH3(){

	}// manipulateH3


	/**
	 *  @name   manipulateCss
	 *  @desc   manipulating style
	 *
	 *  .css()      1 param     => read mode
	 *              2 param     => write mode
	 *  .css(...).css(...).css(...)
	 *  .css({...})
	 *
	 *  for some heavier style manipulation better using
	 *  .addClass(className)
	 *  .removeClass(className)
	 *	.toggleClass(className)
	 *
	 */
	function manipulateCss(){

	}// manipulateCss



	/**
	 *  @name   bindBtns
	 *  @desc   subscribing handlers to events
	 *
	 *  $element.event(handler) // deprecated, old style
	 *
	 * $element.on(event:string, handler:function)
	 *
	 */
	function bindBtns(){

	}// bindBtns


	/**
	 *  @name   manipulateAttributes
	 *  @desc   reading or manipulating attribute values
	 *
	 *  .attr()     1 param     =>  read mode
	 *              2 params    =>  write mode
	 */
	function manipulateAttributes(){

	}// manipulateAttributes



	/**
	 *  @name   bindHover
	 *  @desc   using hover() for mouse enter / leave events
	 *
	 *  .hover()  1 or 2 params
	 *          1st param     :function    =>  mouse enter callback
	 *          2nd param     :function    =>  mouse leave callback
	 */
	function bindHover(){

	}// bindHover




	function bindEffectBtns(){

	}// bindEffectBtns


	/**
	 *  @name   bindAnimation
	 *  @desc   using animate()
	 *
	 *  .animate(
	 *      {
	 *          cssProp  :   endingVal,
	 *          cssProp2 :   endingVal2
	 *      },
	 *      duration:ms,
	 *      [end callback:function]
	 *  )
	 *
	 */
	function bindAnimation(){

	}// bindAnimation


	/**
	 *	@name:	init
	 *	@desc:	initialising function
	 */
	function init(){

	} // init



	//window.onload = init;
	// $(element).event(handler)
	$(document).ready(init);

