/**
 * @file    forms.js
 * @author  Training Dragon
 * @desc    this will display new forms 2.0 features
 */



// wrap all your code in an Immediately Invoked Function Expression (iffy)
// we want to avoid global variables
(function () {
var
    numA        = document.getElementById("numA"),
    numB        = document.getElementById("numB"),
    sumBtn      = document.querySelector("#sumBtn"), // using css selectors
    sumResult   = document.getElementById("sumResult"),
    prBar       = document.getElementById("prBar"),
    prValue     = 0,


    bindSumBtn = function () {
        //element.addEventListener(event:string, handler:function)
        sumBtn.addEventListener("click", function () {
            var
                valueA = parseInt(numA.value),
                valueB = parseInt(numB.value),
                result = valueA + valueB
            ;
            sumResult.innerHTML = result;
        });
    }, // bindSumBtn

    bindProgressBar = function () {
        if(prValue < prBar.max){
            prValue += 5;
            prBar.value = prValue;
            setTimeout(
                // code to execute
                function () {
                    bindProgressBar();
                },
                // delay in ms
                100
            );
        }
    }, // bindProgressBar

    initialiser  = function () {
        bindSumBtn();
        bindProgressBar();
    } // initializer
;

window.onload = initialiser;
})();