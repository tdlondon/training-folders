<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | HOME</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo ROOT;?>build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo ROOT;?>build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
    <meta name="description" content="php project homepage"/>
    <meta name="keywords" content="home keywords"/>
</head>
<body>
<div class="wrapper">
    <header>
        <div class="topHeader">
            <div class="identity">
                <img class="logo" src="<?php echo ROOT;?>build/imgs/logo.png" width="70" height="80" alt="logo">
                <h3 class="cName">Company Name</h3>
            </div><!--/identity-->

            <nav class="topNav">
                <ul>
                    <li><a class="currentPageLink" href="<?php echo ROOT;?>index.php">Home</a></li>
                    <li><a href="#">fake</a></li>
                    <li><a href="<?php echo ROOT;?>search.php">search</a></li>
                    <li><a href="<?php echo ROOT;?>contacts.php">contacts</a></li>
                    <li><a href="<?php echo ROOT;?>admin/admin.php">admin</a></li>
                    <li><a href="<?php echo ROOT;?>admin/basket.php"><span class="greyLink">basket</span> (1)</a></li>
                </ul>
            </nav><!--/topNav-->
        </div><!--/topHeader-->
