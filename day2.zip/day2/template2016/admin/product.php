<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TD PHP PROJECT TEMPLATE | PRODUCT</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
    <link rel="stylesheet" href="../build/css/main.css" media="screen"/>
    <link rel="shortcut icon" type="image/x-icon" href="../build/imgs/favicon.ico"/>
    <meta name="author" content="Training Dragon"/>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="topHeader">
                <div class="identity">
                    <img class="logo" src="../build/imgs/logo.png" width="70" height="80" alt="logo">
                    <h3 class="cName">Company Name</h3>
                </div><!--/identity-->

                <nav class="topNav">
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="#">fake</a></li>
                        <li><a href="../search.php">search</a></li>
                        <li><a href="../contacts.php">contacts</a></li>
                        <li><a href="admin.php">admin</a></li>
                        <li><a href="basket.php"><span class="greyLink">basket</span> (1)</a></li>
                    </ul>
                </nav><!--/topNav-->
            </div><!--/topHeader-->

        </header>

        <main>
            <section class="adminNavBlock">
                <div class="container">
                    <section class="welcome">
                        <div class="redDash"></div>
                        <h2 class="welcomeTitle">Welcome back, John!</h2>
                    </section><!--/welcome-->

                    <nav class="adminNav">
                        <ul class="flexCont">
                            <li><a class="ckBtn" href="viewProducts.php">view products</a></li>
                            <li><a class="ckBtn activeLink" href="product.php">add product</a></li>
                            <li><a class="ckBtn" href="viewUsers.php">view users</a></li>
                            <li><a class="ckBtn" href="user.php">add user</a></li>
                            <li><a class="ckBtn" href="viewPages.php">view pages</a></li>
                            <li><a class="ckBtn" href="page.php">add pages</a></li>
                            <li><a class="ckBtn" href="#">log out</a></li>
                        </ul>
                    </nav>
                </div>   <!--/container-->
            </section><!--/adminNavBlock-->

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <section class="feedback">
                        <div class="successMsg">success</div>
                        <div class="failMsg">fail</div>
                    </section><!--/feedBack-->
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
                    <section class="editAddItem">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Add / Edit product</h2>
                        <form method="post" enctype="multipart/form-data" action="#" class="editAddForm editAddProd flexCont">
                            <div class="formCol">
                                <label for="pName">PRODUCT NAME</label>
                                <input class="formField" type="text" id="pName" name="pName" value="">

                                <label for="pPrice">PRODUCT PRICE</label>
                                <input class="formField" type="text" id="pPrice" name="pPrice" value="">

                                <label>PRODUCT IMAGE</label>
                                <div class="fileUploadBlock">
                                    <div class="flexCont">
                                        <label for="pImage" class="fileBtn btn smBtn ckBtn">CHOOSE FILE</label>
                                        <p>
                                            <span class="formField uploadFileSpan" id="uploadProdSpan">No file selected</span>
                                        </p>
                                    </div>
                                    <input class="hiddenFileUpload" type="file" id="pImage" name="pImage" value="">
                                </div><!--/fileUploadBlock-->



                                <label for="pShipp">PRODUCT SHIPPING</label>
                                <input class="formField" type="text" id="pShipp" name="pShipp" value="">
                            </div><!--/formCol-->

                            <div class="formCol">
                                <label for="pDesc">PRODUCT DESCRIPTION</label>
                                <textarea class="formField bgTxtArea" id="pDesc" name="pDesc"></textarea>
                                <button type="submit" name="submit" class="btn ckBtn smBtn blueBtn">Add / Edit product</button>

                            </div><!--/formCol-->
                        </form><!--/editAddForm-->

                    </section><!--/editAddItem-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="../index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="../search.php">Search</a> |
                        <a href="../contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div>

    <script src="../build/js/fileUploadTrick.js"></script>
</body>
</html>