<?php

#######################  LOGIC FOR THE PAGE
include("includes/utilities.php");





####################### BEGINNING OF THE MARKUP
include("includes/header.php");




?>

            <div class="banner">
                <div class="container">
                    <div class="redDash"></div>
                    <h1 class="mainName">Company Name</h1>
                    <h2 class="subTitle">We are great at what we do!</h2>
                    <div class="redDash"></div>
                    <div class="mainDesc underlined">
                        Lorem ipsum dolor sit amet, consectetur elit.
                        Aenean quam ante, egestas tristique consequat ut,
                        Donec commodo eros at felis tempor at porttitor.
                    </div><!--/mainDesc-->

                </div><!--/ banner container-->
            </div><!--/banner-->
        </header>

        <main>
            <section class="offer">
                <div class="container">
                    <div class="offerLeft">
                        <div class="redDash"></div>
                        <h2 class="underlined offerTitle">We offer the best!</h2>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>

                        <p>
                            Donec commodo eros at felis tempor at porttitor mauris adipisci morbi in velit sapien modo eros at felis te adispicing ulvinar.
                        </p>
                    </div><!--/offerLeft-->

                    <div class="offerVideo"></div><!--/offerVideo-->
                </div><!--/ offer container-->
            </section><!--/ offer-->

            <section class="promises">
                <div class="container">
                    <div class="redDash"></div>
                    <h2 class="underlined promiseTitle">Our promises</h2>
                </div><!--/promises container-->
            </section><!--/promises-->

            <section class="mainBody">
                <div class="container flexCont">
                    <div class="homeCol">
                        <div class="topCol">
                            <img src="build/imgs/Symbols/symbol.png" width="31" height="31" alt="red logo">
                            <h3>Commitment</h3>
                        </div><!--/topCol-->
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>
                        <a href="#" class="btn moreBtn ckBtn">read more</a>
                    </div><!--/homeCol-->
                    <div class="homeCol">
                        <div class="topCol">
                            <img src="build/imgs/Symbols/symbol.png" width="31" height="31" alt="red logo">
                            <h3>Quality</h3>
                        </div><!--/topCol-->
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>
                        <a href="#" class="btn moreBtn ckBtn">read more</a>
                    </div><!--/homeCol-->
                    <div class="homeCol">
                        <div class="topCol">
                            <img src="build/imgs/Symbols/symbol.png" width="31" height="31" alt="red logo">
                            <h3>Trust</h3>
                        </div><!--/topCol-->
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit.  Quam ante, egestas tristique consequat ut, pulvinar a ante.
                        </p>
                        <a href="#" class="btn moreBtn ckBtn">read more</a>
                    </div><!--/homeCol-->
                </div><!--/mainBody container-->
            </section><!--/ mainBoby-->
        </main>


        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="index.php">Home</a> |
                        <a href="#">Fake</a> |
                        <a href="search.php">Search</a> |
                        <a href="contacts.php">Contacts</a> |
                        <a href="admin/admin.php">Admin</a> |
                        <a href="admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>
    </div><!--/wrapper-->
</body>
</html>