/**
 * @file:   carousel.js
 * @desc:   exercise in class
 */
(function(){
    var
        picsNo = $("#cList li").length,
        picW = $("#cList img").width(),
        $cList = $("#cList"),
        step = 0;

    $(document).on("ready", function (){
        // alert(picsNo);
        // alert(picW);
        $("#nextBtn").on("click",
            function(){
                var animObj, dur;
                if(step<picsNo-1){
                    animObj = { "marginLeft" : "-="+ picW +"px" };
                    dur =500 ;
                    step++;
                } else {
                    animObj = { "marginLeft" : "0px" };
                    dur = 1000;
                    step=0;
                }
                $cList.animate(animObj, dur);
            }//end click handler
        );// next click


        $("#prevBtn").on("click",
            function(){
                var animObj, dur;
                if(step>0){
                    animObj = { "marginLeft" : "+="+ picW +"px" };
                    dur = 500 ;
                    step--;
                } else {
                    animObj = { "marginLeft" : "-="+ (picW * (picsNo-1) ) +"px" };
                    dur = 1000 ;
                    step = picsNo-1;
                }
                $cList.animate(animObj, dur);
            }//end click handler
        );// prev click
    });// init
})();