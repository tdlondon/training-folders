(function(){
	$(document).ready( function(){
		//===============
		// jQuery UI demo - accordion
		//===========================
		// $('#accordion').accordion();



	});
})();