/**
 * @file:   carousel.js
 * @desc:   exercise in class
 */
