(function(){
	$(document).on("ready", function(){



		//===============
		//jQuery fancybox
		//===============
		/*$(".fancybox-thumb").fancybox({
			 prevEffect	: 'none',
			 nextEffect	: 'none',
			 helpers	: {
				 overlay : {
					 css : {
					 	'background' : 'rgba(0, 200, 0, .3)'
					 }
				 },
				 title	: {
				 	type: 'inside'
				 },
				 /!*thumbs	: {
					 width	: 80,
					 height	: 50
				 }*!/
			 }
		 });

		 $('#formLink').fancybox({
			 helpers	: {
				 overlay: {
					 css: {
						'background': 'rgba(0, 200, 0, .4)'
					 }
				 }
			 }
		 });*/

	});
})();