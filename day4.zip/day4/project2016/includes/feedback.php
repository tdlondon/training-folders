<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/feedback.php
 */
?>



<section class="feedback">
    <?php
    if( isset($successMsg) ){
        ?>
        <div class="successMsg"><?php echo $successMsg;?></div>

    <?php }// success

    if( isset($failMsg) ){
        ?>
        <div class="failMsg"><?php echo $failMsg; ?></div>
    <?php } // fail?>
</section><!--/feedBack-->

