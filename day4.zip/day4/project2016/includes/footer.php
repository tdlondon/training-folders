<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/footer.php
 */
?>



        <footer>
            <div class="footBanner"></div><!--footBanner-->
            <div class="bottomFooter">
                <div class="container">
                    <p>CompanyName &copy<?php echo date("Y");?> - Training Dragon PHP course</p>
                    <p>
                        <a href="<?php echo ROOT;?>index.php">Home</a> |
                        <a href="<?php echo ROOT;?>search.php">Search</a> |
                        <a href="<?php echo ROOT;?>contacts.php">Contacts</a> |
                        <a href="<?php echo ROOT;?>admin/admin.php">Admin</a> |
                        <a href="<?php echo ROOT;?>admin/basket.php">Basket</a>
                    </p>
                </div><!--/ footer container-->
            </div><!--/bottomFooter-->
        </footer>