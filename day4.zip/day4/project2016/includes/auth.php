<?php
/**
 * @author  Training Dragon
 * @file    includes/auth.php
 * @desc    this will take care of the authentication logic
 */



#### start session if not started yet
startSessionOnce();


#### displaying an error message if the user is not logged in
if( !is_logged_in() && !isset($adminPage) ){
    $failMsg = "You are not allowed, please click <a class='boldLink'
        href='" . ROOT . "admin/admin.php'>here</a> to log in.";
}// if not logged in


#### log out logic
if( isset($_GET["log"]) && $_GET["log"] === "out" ){
    // session_destroy();

    // removing id and name from session
    $_SESSION["logID"]      = null;
    $_SESSION["logNAME"]    = null;

    // redirecting user to log in page
    header("location:".ROOT."admin/admin.php");
}// log out








