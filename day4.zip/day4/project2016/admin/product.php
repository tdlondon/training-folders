<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/product.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");
include("../includes/auth.php");


if(is_logged_in()) {
    ##### 2) form handling
    if(isset($_POST["submit"])) {
        ##### DO NOT FORGET FORM SANITATION AND VALIDATION
        // trace($_POST);
        /*
    Array
(
    [pName] => iPhone
    [pPrice] => iPhone
    [pShipp] => 10.99
    [pDesc] => second hand iphone
    [submit] =>
)
    */

        $pName      = $_POST["pName"];
        $pPrice     = $_POST["pPrice"];
        $pShipp     = $_POST["pShipp"];
        $pDesc      = $_POST["pDesc"];

        if(is_edit_mode()){
            ## 2.1 edit mode
            //sanitising this get param forcing it to be an integer...
            $e_id = (int)$_GET["e_id"];

            ### build query
            $eq = "
                UPDATE
                    `" . DBN . "`.`product`
                SET
                    `product`.`pName`   = '$pName',
                    `product`.`pShipp`  = '$pShipp',
                    `product`.`pPrice`  = '$pPrice',
                    `product`.`pDesc`   = '$pDesc'
                WHERE
                    `product`.`pID` = '$e_id'
            ";

              // echo $eq;

            ### execute query
            $eRes = $mysqli->query($eq);

            ### check and handle result
            if($mysqli->affected_rows === 1){
                $successMsg = "Product successfully edited.";
            } else {
                $failMsg = "Could not edit product or product was not modified.";
            } // update check

        } else {
            ## 2.2 add mode

            $aq = "
                INSERT INTO
                    `" . DBN . "`.`product`
                    (`pName`,   `pShipp`,   `pPrice`,   `pDesc`)
                VALUES
                    ('$pName',  '$pShipp',  '$pPrice',  '$pDesc')
            ";

            // echo $aq;

            $aRes = $mysqli->query($aq);

            if( $mysqli->affected_rows === 1 ){
                $successMsg = "Product successfully inserted.";
                ########
                ### fetching ID of last added item
                ########
                $e_id = $mysqli->insert_id;
            } else {
                $failMsg = "Could not insert product.";
            } // end insert check
        }###### edit / add mode

        ## 2.3 file upload
        /*
            uploaded files details will be collected by a superglobal
            named $_FILES
        */
        // trace($_FILES);
        /*
        Array
(
    [pImage] => Array
        (
            [name] => arduino.jpg
            [type] => image/jpeg
            [tmp_name] => C:\xampp\tmp\phpB665.tmp
            [error] => 0
            [size] => 8516
        )

)
        */
        if(
            isset($_FILES["pImage"]["size"]) &&
            $_FILES["pImage"]["size"] !== 0
        ){
            // do not forget validation!
            $realName = $_FILES["pImage"]["name"];
            $realPath = "../build/imgs/products/";
            $destination = $realPath . $realName;
            $file = $_FILES["pImage"]["tmp_name"];

            if( move_uploaded_file($file, $destination) ){

            } else {
                displayMsg("Issues uploading file." , "f");
            }//move uploaded file

            $fq = "
                UPDATE
                    `".DBN."`.`product`
                SET
                    `product`.`pImage` = '$realName'
                WHERE
                    `product`.`pID` = '$e_id'
            ";

            $fRes = $mysqli->query($fq);

            if( $mysqli->affected_rows === 1  ){
                displayMsg("Filename updated.", "s");
            } else {
                displayMsg("Could not update filename." , "f");
            }### end file update

        }// file upload


    } ## form handling

    ##### 1) prefill mode
    if(is_edit_mode()){
        //sanitising this get param forcing it to be an integer...
        $e_id = (int)$_GET["e_id"];

        ### build query
        $q = "
            SELECT
                *
            FROM
                `" . DBN ."`.`product`
            WHERE
                `product`.`pID` = '$e_id'
        ";

        // echo $q;

        ### execute query
        $res = $mysqli->query($q);

        ### testing and handling
        if( $res->num_rows === 1  ){
            $prod = $res->fetch_assoc();
            // trace($prod);
        } else {
            $failMsg = "Could not get product or something went wrong.";
        } // end select check



    }##### prefill mode

}############## is logged in

########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

        <?php if(is_logged_in()){?>
                <div class="container">
                    <section class="editAddItem">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle"><?php get_title("Product");?></h2>
<form method="post" enctype="multipart/form-data" action="#" class="editAddForm editAddProd flexCont">
    <div class="formCol">
        <label for="pName">PRODUCT NAME</label>
        <input class="formField" type="text" id="pName" name="pName" value="<?php
            if(isset($prod["pName"])){echo $prod["pName"];}
        ?>">

        <label for="pPrice">PRODUCT PRICE</label>
        <input class="formField" type="text" id="pPrice" name="pPrice" value="<?php
        if(isset($prod["pName"])){echo $prod["pPrice"];}
        ?>">

        <label>PRODUCT IMAGE <?php
            if(isset($prod["pImage"])){echo "{ " . $prod["pImage"] . " }";}
            ?></label>
        <div class="fileUploadBlock">
            <div class="flexCont">
                <label for="pImage" class="fileBtn btn smBtn ckBtn">CHOOSE FILE</label>
                <p>
                    <span class="formField uploadFileSpan" id="uploadProdSpan">No file selected</span>
                </p>
            </div>
            <input class="hiddenFileUpload" type="file" id="pImage" name="pImage" value="">
        </div><!--/fileUploadBlock-->

        <label for="pShipp">PRODUCT SHIPPING</label>
        <input class="formField" type="text" id="pShipp" name="pShipp" value="<?php
        if(isset($prod["pShipp"])){echo $prod["pShipp"];}
        ?>">
    </div><!--/formCol-->

    <div class="formCol">
        <label for="pDesc">PRODUCT DESCRIPTION</label>
        <textarea class="formField bgTxtArea" id="pDesc" name="pDesc"><?php
            if(isset($prod["pDesc"])){echo $prod["pDesc"];}
            ?></textarea>
        <button type="submit" name="submit" class="btn ckBtn smBtn blueBtn"><?php get_title("Product");?></button>

    </div><!--/formCol-->
</form><!--/editAddForm-->

                    </section><!--/editAddItem-->
                </div><!--/container-->
        <?php } // is logged in?>

            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php");?>
</div><!--/wrapper-->
<!-- add your JS here-->
<script src="<?php echo ROOT;?>build/js/fileUploadTrick.js"></script>
<!--/ your JS here-->
</body>
</html>

