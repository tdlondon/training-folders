<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/viewPages.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="viewItems">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">View pages</h2>
                        
                        <div class="itemsBlock">
                            <div class="itemLabelsBlock flexCont">
                                <div class="itemLabel pgIDLabel">id</div>
                                <div class="itemLabel pgOrderLabel">#</div>
                                <div class="itemLabel pgNameLabel">Name</div>
                                <div class="itemLabel pgTitleLabel">title</div>
                                <div class="itemLabel pgUrlLabel">Url</div>
                                <div class="itemLabel pgDescLabel">Desc</div>
                                <div class="itemLabel pgKeysLabel">Keys</div>
                                <div class="itemLabel pgBodyLabel">Body</div>
                            </div><!--/itemLabels-->

                            <div class="item flexCont"><!--/item =================================-->
                                <div class="itemBox vCentre pgIDBox">
                                    <p>1</p>
                                </div><!--/pgID-->

                                <div class="itemBox vCentre pgOrderBox">
                                    <p>1</p>
                                </div><!--/pgOrderBox-->

                                <div class="itemBox vCentre pgNameBox">
                                    <p>home</p>
                                </div><!--/pgNameBox-->

                                <div class="itemBox vCentre pgTitleBox">
                                    <p>homepage</p>
                                </div><!--/pgTitleBox-->

                                <div class="itemBox vCentre pgUrlBox">
                                    <p>index.php</p>
                                </div><!--/pgUrlBox-->

                                <div class="itemBox vCentre pgDescBox">
                                    <p>homepage desc</p>
                                </div><!--/pgDescBox-->

                                <div class="itemBox vCentre pgKeysBox">
                                    <p>homepage keys</p>
                                </div><!--/pgKeysBox-->

                                <div class="itemBox vCentre pgBodyBox">
                                    <p>homepage content</p>
                                </div><!--/pgBodyBox-->



                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="page.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item =======================================================-->

                            <!--DELETE FROM HERE =================================-->
                            <div class="item flexCont">
                                <div class="itemBox vCentre pgIDBox">
                                    <p>2</p>
                                </div><!--/pgID-->

                                <div class="itemBox vCentre pgOrderBox">
                                    <p>2</p>
                                </div><!--/pgOrderBox-->

                                <div class="itemBox vCentre pgNameBox">
                                    <p>search</p>
                                </div><!--/pgNameBox-->

                                <div class="itemBox vCentre pgTitleBox">
                                    <p>search page</p>
                                </div><!--/pgTitleBox-->

                                <div class="itemBox vCentre pgUrlBox">
                                    <p>search.php</p>
                                </div><!--/pgUrlBox-->

                                <div class="itemBox vCentre pgDescBox">
                                    <p>search desc</p>
                                </div><!--/pgDescBox-->

                                <div class="itemBox vCentre pgKeysBox">
                                    <p>search keys</p>
                                </div><!--/pgKeysBox-->

                                <div class="itemBox vCentre pgBodyBox">
                                    <p>search content</p>
                                </div><!--/pgBodyBox-->



                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="page.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->

                            <div class="item flexCont">
                                <div class="itemBox vCentre pgIDBox">
                                    <p>3</p>
                                </div><!--/pgID-->

                                <div class="itemBox vCentre pgOrderBox">
                                    <p>3</p>
                                </div><!--/pgOrderBox-->

                                <div class="itemBox vCentre pgNameBox">
                                    <p>test</p>
                                </div><!--/pgNameBox-->

                                <div class="itemBox vCentre pgTitleBox">
                                    <p>test</p>
                                </div><!--/pgTitleBox-->

                                <div class="itemBox vCentre pgUrlBox">
                                    <p>index.php?p=test</p>
                                </div><!--/pgUrlBox-->

                                <div class="itemBox vCentre pgDescBox">
                                    <p>test desc</p>
                                </div><!--/pgDescBox-->

                                <div class="itemBox vCentre pgKeysBox">
                                    <p>test keys</p>
                                </div><!--/pgKeysBox-->

                                <div class="itemBox vCentre pgBodyBox">
                                    <p>test content</p>
                                </div><!--/pgBodyBox-->



                                <div class="itemBox itemBtns">
                                    <a class="itemAction editItemAction" href="page.php"></a>
                                    <a class="itemAction deleteItemAction" href="#"></a>
                                </div><!--/itemBtns-->
                            </div><!--/item-->



                            <!--DELETE UP TO HERE=======================================================-->

                        </div><!--/itemsBlock-->


                    </section><!--/viewItems-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>

<?php include ("../includes/footer.php");?>
</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>