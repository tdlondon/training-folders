<!--/ https://developer.paypal.com/docs/classic/paypal-payments-standard/integration-guide/formbasics/ -->

<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/checkout.php
 */


########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");


########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
    <?php include("../includes/adminNav.php");?>

    <section class="mainBody">
        <div class="container">
            <!-- ====================  FEEDBACK START =========-->
            <?php include("../includes/feedback.php");?>
            <!-- ====================  FEEDBACK END ===========-->
        </div><!--container-->

                <div class="container">
                    <section class="editAddItem">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Checkout</h2>
                        <form method="post" enctype="multipart/form-data" action="https://www.paypal.com/cgi-bin/webscr" class="editAddForm editAddProd flexCont">
                            <INPUT TYPE="hidden" name="address_override" value="1">
                            <input type="hidden" name="cmd" value="_xclick">
                            <input type="hidden" name="business" value="seller@email.com">
                            <input type="hidden" name="notify_url" value="sellerwebsite.com/confirmation.php">
                            <INPUT TYPE="hidden" name="address_override" value="1">
                            <input type="hidden" name="item_name" value="company order">
                            <input type="hidden" name="item_number" value="1">
                            <input type="hidden" name="currency_code" value="GBP">
                            <div class="formCol">
                                <label for="first_name">FIRST NAME</label>
                                <input class="formField" type="text" id="first_name" name="first_name" value="John">

                                <label for="last_name">LAST NAME</label>
                                <input class="formField" type="text" id="last_name" name="last_name" value="Doe">

                                <label for="email">EMAIL</label>
                                <input class="formField" type="email" id="email" name="email" value="j@email.com">


                                <label for="addr1">ADDRESS 1</label>
                                <input class="formField" type="text" id="uAddr1" name="addr1" value="ad1">

                                <label for="addr2">ADDRESS 2</label>
                                <input class="formField" type="text" id="uAddr2" name="addr2" value="ad2">
                            </div><!--/formCol-->

                            <div class="formCol">
                                <label for="phone">PHONE</label>
                                <input class="formField" type="text" id="phone" name="phone" value="123123123">

                                <label for="zip">POSTAL CODE</label>
                                <input class="formField" type="text" id="zip" name="zip" value="A1 3BC">

                                <label for="city">CITY</label>
                                <input class="formField" type="text" id="city" name="city" value="London">

                                <label for="country">COUNTRY</label>
                                <input class="formField" type="text" id="country" name="country" value="GB">

                                <label for="amount">YOU WILL PAY A TOTAL OF</label>
                                <input class="formField" type="text" id="fakeamount" name="fakeamount" value="&pound;123.00">
                                <input  class="formField" type="hidden" id="amount" name="amount" value="123">


                                <button type="submit" name="submit" class="btn ckBtn smBtn blueBtn">Buy now</button>

                            </div><!--/formCol-->
                        </form><!--/editAddForm-->

                    </section><!--/editAddItem-->
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>

<?php include("../includes/footer.php")?>

</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>

