<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/admin.php
 */

$adminPage = true;
########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");
include("../includes/auth.php");


// form submission
if( isset($_POST["login"]) ){
    ######################################################
    ## DO NOT FORGET TO
    ## VALIDATE AND SANITIZE
    ## ALL YOUR FORMS!!!
    ## please refer to contacts.php for validation basics
    ######################################################

    // collecting form details
    $logEmail   = $_POST["logEmail"];
    $logPsw     = $_POST["logPsw"];
    $psw        = sha1($logPsw);

    // build query
    $q = "
        SELECT
            *
        FROM
            `" . DBN . "`.`user`
        WHERE
            `user`.`uEmail` = '$logEmail'
        AND
            `user`.`uPsw` = '$psw'
    ";

    // echo $q;

    // run query
    $res = $mysqli->query($q);

    // test and handle result
    if( $res->num_rows == 1 ){
        $user = $res->fetch_assoc();
        trace($user);

        /*
            STORING PERSISTENT DATA:
            CLIENT SIDE => $_COOKIE => do not use for sensitive information

            SERVER SIDE => $_SESSION => more secure, very useful for sensitive data


            $_SESSION =>
            * is a superglobal
            * is only available after we start the session
            * we want to start the session only once
            * we want to start the session before ANY output
        */

        startSessionOnce();

        // storing user details into $_SESSION
        $_SESSION["logID"]      = $user["uID"];
        $_SESSION["logNAME"]    = $user["uName"];

        //redirecting user into restricted area
        header("location:" . ROOT . "admin/viewProducts.php");

    } else {
        $failMsg = "Could not login. Please try again.";
    }## select check




}######### form submission



########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
<?php include("../includes/adminNav.php");?>

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <?php include("../includes/feedback.php");?>
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

<?php if(!is_logged_in()){?>
                <div class="container">
                    <section class="login">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Log in to access</h2>
<form method="post" action="#" class="loginForm flexCont">
    <div class="formCol emailCol">
        <label for="logEmail">Email</label>
        <input class="formField" type="email" id="logEmail" name="logEmail" value="">
    </div>
    <div class="formCol pswCol">
        <label for="logPsw">Password</label>
        <input class="formField" type="password" id="logPsw" name="logPsw" value="">
        <button type="submit" name="login" class=" btn ckBtn smBtn blueBtn">LOG IN</button>
    </div>
</form><!--/loginForm-->
                    </section><!--/login-->

                </div><!--/container-->
<?php } else {
    echo "<div class='container feedback'>
            <div class='successMsg'>You are already logged in.</div>
          </div>";
} ### if is_logged_in ?>

            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php");?>

</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>

