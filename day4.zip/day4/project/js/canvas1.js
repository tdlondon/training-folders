/**
 * @author  Training Dragon
 * @name    canvas1.js
 * @desc    this will demonstrate how to draw primitives (squares, rectangles, circles),
 *          interact with buttons, detect mouse cursor position on canvas
 */
// wrap all your code in an iife
(function(){
var
    c1 = document.getElementById("c1"),
    ctx1 = c1.getContext("2d"),
    c2 = document.getElementById("c2"),
    ctx2 = c2.getContext("2d"),
    c3 = document.getElementById("c3"),
    ctx3 = c3.getContext("2d"),
    c4 = document.getElementById("c4"),
    ctx4 = c4.getContext("2d"),
    w = c1.width,
    h = c1.height,
    fillCols = ['#0CF','#0C0','#C96','#63F','#F0F',
                'red','yellow','blue','green','#030',
                '#3F9','#06F','#FC6','#933','#0C3',
                '#CF9'],

    strokeCols = ['#000','#333','#009','#99c','#F06',
                '#C99','#093','#F9F','#F60','#30C',
                '#699','#306'],
    addBtn = document.getElementById("addBtn"),
    clearBtn = document.getElementById("clearBtn"),
    snapBtn = document.getElementById("snapBtn"),
    // boolean flag for mouse app (we start following mouse cursor)
    following = true,

    /**
     * @name    clearCanvas
     * @desc    this will receive a context and remove everything from it
     * @param   {object}    ctx     context of the canvas to clear
     */
    clearCanvas = function(ctx){
        ctx.clearRect(0, 0, w, h);
    }, // clearCanvas

    /**
     *  @name   getRandomToMax
     *  @desc   this will receive a number and return a random number between 0 and max
     *  @param  {number}    max     maximun allowed value
     *  @return {number}            random number
     *  Math.random()   =>  will return a random number between 0 and 1
     *
     *  rounding numbers in JS
     *  Math.floor()    =>  round down
     *  Math.ceil()     =>  round up
     *  Math.round()    =>  round to closest
     */
    getRandomToMax = function(max){
        return Math.random() * max;
    }, // getRandomToMax

    /**
     *  @name   drawRect
     *  @desc   this will draw rectangles / squares
     */
    drawRect = function () {
        var
            a = 1/2,
            rw = w * a,
            rh = h * a,
            rx = (w-rw) / 2,
            ry = (h-rh) / 2
        ;


        ctx1.beginPath();
        // ctx.rect(x, y, w, h)
        ctx1.rect(rx,ry, rw, rh);
        ctx1.fillStyle = "red";
        ctx1.fill();
        ctx1.strokeStyle = "blue";
        ctx1.lineWidth = 5;
        ctx1.stroke();
        ctx1.closePath();
    }, // drawRect

    drawArcs = function () {
        ctx2.beginPath();
        // c.arc( cx, cy, r, startAngle, endAngle, anticlockwise:boolean )
        ctx2.arc(200, 200, 100, 0, 2*Math.PI, false);
        ctx2.fillStyle = "yellow";
        ctx2.fill();
        ctx2.strokeStyle = "green";
        ctx2.lineWidth = 4;
        ctx2.stroke();
        ctx2.closePath();
    }, // drawArcs

    bindBtns = function () {
        addBtn.addEventListener("click", function () {
            var
                rw      = getRandomToMax(300),
                rh      = getRandomToMax(300),
                rx      = getRandomToMax(w),
                ry      = getRandomToMax(h),
                rLw     = getRandomToMax(5),
                rFill   = fillCols[   Math.floor( getRandomToMax(fillCols.length  ) )],
                rStroke = strokeCols[ Math.floor( getRandomToMax(strokeCols.length) )]
            ;

            ctx3.beginPath();
            ctx3.rect(rx, ry, rw, rh);
            ctx3.fillStyle = rFill;
            ctx3.fill();
            ctx3.strokeStyle = rStroke;
            ctx3.lineWidth = rLw;
            ctx3.stroke();
            ctx3.closePath();
        });// add

        clearBtn.addEventListener("click", function () {
            clearCanvas(ctx3);
        }); // clear

        snapBtn.addEventListener("click", function () {
            window.open( c3.toDataURL() );
        }); // snap

    }, // bindBtns

    /**
     * this will draw a blue dot in the centre of the canvas
     */
    drawCentre = function () {
        ctx4.beginPath();
        ctx4.arc(w/2, h/2, 15, 0, 2*Math.PI, true);
        ctx4.fillStyle = "blue";
        ctx4.fill();
        ctx4.closePath();
    }, // drawCentre

    drawGuidelines = function(mx, my){
        ctx4.beginPath();
        ctx4.moveTo(0, my);
        ctx4.lineTo(w, my);

        ctx4.moveTo(mx, 0);
        ctx4.lineTo(mx, h);
        ctx4.strokeStyle = "#999";
        ctx4.lineWidth = 1;
        ctx4.stroke();
        ctx4.closePath();
    }, // drawGuidelines


    drawBigLine = function(mx, my){
        ctx4.beginPath();
        ctx4.moveTo(w/2, h/2);
        ctx4.lineTo(mx, my);

        ctx4.strokeStyle = "blue";
        ctx4.lineWidth = 10;
        ctx4.lineCap = "round";
        ctx4.stroke();
        ctx4.closePath();
    }, // drawBigLine


    /**
     *  this will detect mouse cursor coordinates on the canvas, as we move it
     */
    onMouseMove = function(e){
        var
            // these are coordinates in reference to the viewport
            x = e.clientX,
            y = e.clientY,
            bBox = c4.getBoundingClientRect()
            mx = x - bBox.left,
            my = y - bBox.top
        ;

        // console.log( mx, my);
        clearCanvas(ctx4);
        drawGuidelines(mx, my);

        drawCentre();
        drawBigLine(mx, my);

    }, // onMouseMove


    /**
     * this will subscribe mouse event handlers
     */
    bindMouseOnCanvas = function () {
        c4.addEventListener("mousemove", onMouseMove);

        c4.addEventListener("click", function () {
            if(following){
                c4.removeEventListener("mousemove", onMouseMove);
            } else {
                c4.addEventListener("mousemove", onMouseMove);
            }
            following = !following;
        }); // click
    }, // bindMouseOnCanvas

    init = function () {
        drawRect();
        drawArcs();
        bindBtns();
        bindMouseOnCanvas();
    }// init
;
    window.addEventListener("load",init);
})();