/**
 * @author  Training Dragon
 * @name    video1.js
 * @desc    this will use css3 filters to manipulate a playing video
 */
// wrap all your code in an iife
(function(){
var
    supportsVideo = (function(){return !!Modernizr.video})(),
    vid1        = document.getElementById("vid1"),
    slowBtn     = document.getElementById("slowBtn"),
    playBtn     = document.getElementById("playBtn"),
    pauseBtn    = document.getElementById("pauseBtn"),
    fastBtn     = document.getElementById("fastBtn"),


    bindBtns = function () {
        playBtn.addEventListener("click", function () {
            vid1.playbackRate = 1;
            vid1.play();
        })

        pauseBtn.addEventListener("click", function () {
            vid1.pause();
        })

        slowBtn.addEventListener("click", function () {
            vid1.playbackRate = .5;
            vid1.play();
        })

        fastBtn.addEventListener("click", function () {
            vid1.playbackRate = 2;
            vid1.play();
        })
    }, // bindBtns


    init = function () {
        if(supportsVideo){
            bindBtns();
        } else {
            alert("video tag not supported");
        }
    }// init
;
    window.addEventListener("load",init);
})();