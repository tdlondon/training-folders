/**
 * @author  Training Dragon
 * @name    video2.js
 * @desc    this will use canvas and css3 filters to manipulate a playing video
 */
// wrap all your code in an iife
(function(){
var
    supportsVideo = (function(){return !!Modernizr.video})(),
    vid2        = document.getElementById("vid2"),
    slowBtn     = document.getElementById("slowBtn"),
    playBtn     = document.getElementById("playBtn"),
    pauseBtn    = document.getElementById("pauseBtn"),
    fastBtn     = document.getElementById("fastBtn"),
    effectBtn   = document.getElementById("effectBtn"),
    bCanvas     = document.getElementById("bufferCanvas"),
    videoBar    = document.getElementById("videoBar"),
    effectLinks = document.querySelectorAll("a[data-filter]"),
    bCtx        = bCanvas.getContext("2d"),
    w = bCanvas.width,
    h = bCanvas.height,
    effect = false,

    animateBar = function () {
        var
            ct = vid2.currentTime,
            d = vid2.duration,
            bw = ct*w/d
        ;
        videoBar.style.width = bw + "px";
    }, // animateBar

    /**
     * this will manipulate video frames and re-trigger itself asap
     */
    processVideo = function () {
        animateBar();

        bCtx.drawImage(vid2, 0, 0, w, h);
        var
            frame = bCtx.getImageData(0 ,0 , w, h),
            fD = frame.data,
            L = fD.length,
            i = 0
        ;

        if(effect){
            for( ; i<L; i+=4){
               /* // ============  negative  effect ========
                fD[i]       =   255 - fD[i];    // r
                fD[i+1]     =   255 - fD[i+1];  // g
                fD[i+2]     =   255 - fD[i+2];  // b
                //fD[i+3]                       // a*/

               // =============    effect ========
                var a = (fD[i] + fD[i+1] + fD[i+2])/3;
                fD[i]       = a;
                fD[i+1]     = a;
                fD[i+2]     = a;
            }// for

            frame.data = fD;
            bCtx.putImageData(frame, 0,0);
        }// if effect

        // retrigger the function ASAP
        setTimeout(function(){
            processVideo();
        }, 0);

    }, // processVideo


    bindBtns = function () {
        vid2.addEventListener("play", processVideo);


        playBtn.addEventListener("click", function () {
            vid2.playbackRate = 1;
            vid2.play();
        });

        pauseBtn.addEventListener("click", function () {
            vid2.pause();
        });

        slowBtn.addEventListener("click", function () {
            vid2.playbackRate = .5;
            vid2.play();
        });

        fastBtn.addEventListener("click", function () {
            vid2.playbackRate = 2;
            vid2.play();
        });

        effectBtn.addEventListener("click", function () {
            effect = !effect;
        });



    }, // bindBtns

    bindEffectLinks = function () {
        var i = 0, L = effectLinks.length;
        for(; i< L; i++){
            effectLinks[i].addEventListener("mouseenter", function (e) {
                var
                    className = e.target.getAttribute("data-filter")
                ;

                bCanvas.classList.add(className);
            });// mouseenter


            effectLinks[i].addEventListener("mouseleave", function (e) {
                var
                    className = e.target.getAttribute("data-filter")
                    ;

                bCanvas.classList.remove(className);
            });// mouseenter
        }// for
    }, // bindEffectLinks

    init = function () {
        if(supportsVideo){
            bindBtns();
            bindEffectLinks();
        } else {
            alert("video tag not supported");
        }
    }// init
;
    window.addEventListener("load",init);
})();