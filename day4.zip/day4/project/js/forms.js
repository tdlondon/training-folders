/**
 * @author  Training Dragon
 * @name    forms.html
 * @desc    this will show new form elements and attributes,
 *          custom attributes and real time manipulation
 */
// wrap all your code in an iife
(function(){
var
    numA = document.getElementById("numA"),
    numB = document.querySelector("#numB"), // using a css selector
    resBtn = document.getElementById("resBtn"),
    result = document.getElementById("result"),
    prBar = document.getElementById("prBar"),
    wSlider = document.querySelector("#wSlider"),
    sliders = document.querySelectorAll(".sizeSliders input[type=range]"),
    colSliders = document.querySelectorAll(".colSliders input[type=range]"),
    box1 = document.querySelector("#box1"),
    val = 0,

    bindSumBtn = function () {
        // element.addEventListener(event:string, handlers:function)
        resBtn.addEventListener("click", function () {
            if(numA.value !== "" && numB.value !== ""){
                var sum =
                    parseInt(numA.value, 10) +
                    parseInt(numB.value, 10)
                ;
                result.value = sum;
            } else {
                alert("please fill in the two numbers");
            }
        });//
    }, // bindSumBtn

    animatePrBar = function () {
        if(val < prBar.max){
            val += 50;
            prBar.value = val;
            setTimeout(
                // code
                function(){
                    animatePrBar();
                },
                // delay in ms
                100
            )
        } else {
            // alert("end of animation");
        }
    }, // animatePrBar

    bindPrBar = function () {
        animatePrBar();
    }, // bindPrBar

    bindWslider = function () {
        // try both CHANGE and INPUT events
        wSlider.addEventListener("input", function () {
           var w = wSlider.value;
           box1.style.width = w + "px";
        });
    }, //bindWslider

    bindSliders = function () {
        var i= 0, L = sliders.length;
        for( ; i<L; i++){
            sliders[i].addEventListener("input", function (e) {
                // fetching the target of the event,
                // basically: which slider are we moving?
                // console.log(e.target);
                var
                    prop = e.target.getAttribute("data-prop"),
                    val = e.target.value
                ;

                box1.style[prop] = val + "px";

            });
        }// for
    },

    bindColSliders = function () {

        var i = 0, L = colSliders.length,
            bgCol = {
                r : 0,
                g : 0,
                b : 255,
                a : 1
            }
            ;
        for(; i<L; i++){
            colSliders[i].addEventListener("input", function (e) {
                var
                    col = e.target.getAttribute("data-color"),
                    val = e.target.value
                ;

                bgCol[col] = val;
                box1.style.backgroundColor = "rgba("+
                        bgCol.r + "," +
                        bgCol.g + "," +
                        bgCol.b + "," +
                        bgCol.a  +
                        ")";
            });
        }// for
    }, //bindColSliders

    init = function () {
        bindSumBtn();
        bindPrBar();
        // static approach 1:1 relationship :(
        //bindWslider();

        // DYNAMIC approach M:M relationhsip :D
        bindSliders();
        bindColSliders();
    }// init
;
    window.addEventListener("load",init);
})();