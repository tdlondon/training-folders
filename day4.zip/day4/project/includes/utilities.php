<?php
/**
 * TrainingDragon
 *
 * PHP course project 2016
 * url: /includes/utilities.php
 */

/**
 *  This will take care of:
 *  + useful constants,
 *  + error handling,
 *  + database connection and selection
 *  + helper functions
 */

//===========  ERROR HANDLING:

######  DO NOT EXPOSE ERRORS IN PRODUCTION MODE
###### ATTACKERS CAN GET ADVANTAGE OF THEM!!!!
ini_set('display_errors','on');
error_reporting(E_ALL);


//===========  CONSTANTS:

###### defining a constant pointing at the root folder
//define('CONST_NAME','VALUE');
define('ROOT','http://localhost/_COURSES/PHP/PHP_2016_10_17/day4/project/');


//===========  DATABASE LOGIC:
define("USR", "root");
define("PSW", ""); // default pasword: root
define("HST", "localhost");
define("DBN", "php_2016_10_17");

// connecting to server ....
// $link is a mysql objcet that stores details about the connection in real time
$link = mysqli_connect(HST, USR, PSW)
    //or die("ERROR ==> " . mysqli_connect_error() );
    or $failMsg = "Could not connect to server.";

//trace($link);

// selecting the database
mysqli_select_db($link, DBN) or $failMsg = "Could not select DB.";

//===========  HELPER FUNCTIONS:



/**
 *	@name   trace
 *	@desc   this foo will display the content of arrays/superglobals
 *	            in a nice and readable fashion
 *  @param   object	$obj		the object to print
 */

function trace($obj){
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
}//end trace




/**
 * @name    startSessionOnce
 * @desc    this will make sure we start the session only if not started  already
 */
function startSessionOnce(){
    if(!isset($_SESSION)){
        session_start();
    }
} // startSessionOnce





/**
 *	@name   getPageNames
 *  @desc   this foo will retrieve and return all names for CMS pages
 */
function getPageNames(){


}//getPageNames




/**
 *	@name       getPageContentByName
 *	@desc       this foo will receive a page name and return all data about relative page
 * 	@param 	    STRING	$name	the name of the page to fetch
 */
function getPageContentByName($name){

}//getPageContentByName



/**
 *	@name       is_edit_mode
 *	@desc       this foo will detect if in edit mode
 *  @return     boolean
 */
function is_edit_mode(){
    if(isset($_GET["e_id"])){
        return true;
    } else {
        return false;
    }
}//is_edit_mode


/**
 *	@name       is_logged_in
 *	@desc       this foo will detect if user is currently logged in
 *  @return     boolean
 */
function is_logged_in(){
    if( isset($_SESSION["logID"]) ){
        return true;
    } else {
        return false;
    }
}//is_logged_in


/**
 *	@name       get_title
 *	@desc       this foo will receive a CMS entity name and return a page title
 * 	@param 	    STRING  	$what	the name of the CMS entity
 * 	@return 	STRING      $title	the title of the page
 */
function get_title($what){
    if(is_edit_mode()){
        echo "Edit $what";
    } else {
        echo "Add $what";
    }
}//get_title




/**
 *	@name       displayMsg
 *	@desc       this foo will feedback messaging
 * 	@param 	    STRING  	$msg	the message to display
 * 	@return 	STRING      $type	[s=> success, f=>fail]
 */
function displayMsg($msg, $type){
    global $successMsg;
    global $failMsg;

    if( strtolower($type) === "s" ){
        // success
        if(!isset($successMsg)){
            $successMsg = "<p>$msg</p>";
        } else {
            $successMsg .= "<p>$msg</p>";
        }
    } elseif(strtolower($type) === "f") {
        //fail
        if(!isset($failMsg)){
            $failMsg = "<p>$msg</p>";
        } else {
            $failMsg .= "<p>$msg</p>";
        }
    }// if $type
}//displayMsg