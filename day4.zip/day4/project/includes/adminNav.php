<?php
/**
 * Training Dragon
 *
 * PHP course project
 * url: /includes/adminNav.php
 */
?>



        <section class="adminNavBlock">
            <div class="container">
                <?php if(is_logged_in()){?>
                <section class="welcome">
                    <div class="redDash"></div>
                    <h2 class="welcomeTitle">Welcome back, <?php
                        echo ucfirst( $_SESSION["logNAME"] );?>!</h2>
                </section><!--/welcome-->
                <?php }// is logged in?>
                <nav class="adminNav">
<ul class="flexCont">
    <li><a class="ckBtn" href="<?php echo ROOT;?>admin/viewProducts.php">view products</a></li>
    <li><a class="ckBtn" href="<?php echo ROOT;?>admin/product.php">add product</a></li>
    <li><a class="ckBtn" href="<?php echo ROOT;?>admin/viewUsers.php">view users</a></li>
    <li><a class="ckBtn" href="<?php echo ROOT;?>admin/user.php">add user</a></li>
    <li><a class="ckBtn" href="<?php echo ROOT;?>admin/viewPages.php">view pages</a></li>
    <li><a class="ckBtn" href="<?php echo ROOT;?>admin/page.php">add pages</a></li>
<?php if(is_logged_in()){?>
    <li><a class="ckBtn" href="?log=out">log out</a></li>
<?php }// is logged in?>
</ul>
                </nav>
            </div>   <!--/container-->
        </section><!--/adminNavBlock-->
