<?php
/**
 * @file    /includes/auth.php
 * @desc    this will take care of the authentication logic
 */


####### 1) starting session
startSessionOnce();



####### 2) displaying an error message if the user is not allowed
if( !is_logged_in() && !isset($adminPage) ){
    $failMsg = "You are not allowed. Please click <a class='boldLink'
        href='".ROOT."admin/admin.php'>here</a> to get back to login page.";
}// logged in




####### 3) log out logic
if(isset($_GET["log"]) && $_GET["log"] == "out"){
    // removing data from session
    //session_destroy();

    $_SESSION["logID"] = null;
    $_SESSION["logNAME"] = null;

    //redirecting user to login page
    header("location:".ROOT."admin/admin.php");
}// loggin out