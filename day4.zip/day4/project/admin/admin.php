<?php
/**
 * TrainingDragon
 *
 * PHP course project
 * url: /admin/admin.php
 */

$adminPage = true;
########   HERE SOME PHP SCRIPTING FOR THE PAGE    #########
include("../includes/utilities.php");
include("../includes/auth.php");

// run logic only on form submission
if( isset( $_POST["login"] ) ){
    ########################
    ### do not forget validation and sanitation
    ### have a look at contacts.php for a reference
    ########################

    //trace($_POST);
    /*
    Array
(
    [logEmail] =>
    [logPsw] =>
    [login] =>
)
    */
    $logEmail = $_POST["logEmail"];
    $logPsw = $_POST["logPsw"];
    $psw = sha1($logPsw);

    // build query
    $q = "
        SELECT
            *
        FROM
            `".DBN."`.`user`
        WHERE
            `user`.`uEmail` = '$logEmail'
        AND
            `user`.`uPsw` = '$psw'
    ";

    // echo $q;

    $res = mysqli_query($link, $q);

    if(mysqli_num_rows($res) == 1){
        $user = mysqli_fetch_assoc($res);
        trace($user);

        ##########################
        ## STORING PERSISTENT DATA
        ##########################

        /**
         *  $_COOKIE    =>  client side     =>  easily accessible from the browser,
         *                                      do not use for sensitive information
         *
         *  $_SESSION   =>  server side     =>  use session for sensitive data
         *
         *  * $_COOKIE and $_SESSION are SUPERGLOBALS
         *  * are associative arrays
         *
         *  * $_SESSION is only available after we start the session
         *  * we want to start the session only once, before any output
         *  * we can store data into $_SESSION manually
         */

        // start session
        startSessionOnce();

        // storing user ID and NAME into $_SESSION
        $_SESSION["logID"]      = $user["uID"];
        $_SESSION["logNAME"]    = $user["uName"];

        // redirecting user to restricted area
        header("location:".ROOT."admin/viewProducts.php");




    } else {
        $failMsg = "Could not login, please try again.";
    }// select


}###### end form handling




########   THIS IS THE BEGINNING OF THE MARKUP    #########

include("../includes/top.php");
include("../includes/header.php");
####
?>
</header>

<main>
<?php include("../includes/adminNav.php");?>

            <section class="mainBody">
                <div class="container">
                    <!-- ====================  FEEDBACK START =========-->
                    <?php include("../includes/feedback.php");?>
                    <!-- ====================  FEEDBACK END ===========-->
                </div><!--container-->

                <div class="container">
<?php if(!is_logged_in()){?>
                    <section class="login">
                        <div class="redDash"></div>
                        <h2 class="sectionTitle">Log in to access</h2>
                        <form method="post" action="#" class="loginForm flexCont">
                            <div class="formCol emailCol">
                                <label for="logEmail">Email</label>
                                <input class="formField" type="email" id="logEmail" name="logEmail" value="">
                            </div>
                            <div class="formCol pswCol">
                                <label for="logPsw">Password</label>
                                <input class="formField" type="password" id="logPsw" name="logPsw" value="">
                                <button type="submit" name="login" class=" btn ckBtn smBtn blueBtn">LOG IN</button>
                            </div>
                        </form><!--/loginForm-->
                    </section><!--/login-->
<?php } else {?>
                    <div class="feedback successMsg">You are already logged in.</div>
<?php }///is logged in?>
                </div><!--/container-->


            </section><!--/ mainBody-->
        </main>


<?php include("../includes/footer.php");?>

</div><!--/wrapper-->
<!-- add your JS here-->

<!--/ your JS here-->
</body>
</html>

