/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 5_objects
 * spec         : 5-4_delete_operator
 **/


/**
 * notes:
 *
 **/
var __ = null;
//================== CAREFUL ==================
//global scope
var a = 1;
b = 2;
eval("var c = 3;");
eval("d = 4;");
//=============================================
describe("delete operator", function () {
	var actor;
	beforeEach(function () {
		actor = {
			name: "Ben Kingsley",
			address: {
				street: "Pentonville Road",
				postcode: "N1 9JY"
			}
		};
	});
	
	xit("1 - delete operator", function () {
		var result;
		result = delete actor.name;
		expect(result).toBe(true);//
		expect(actor.name).toBe(__);//
	});
	
	xit("2 - delete operator vs.\
	 setting property value to undefined", function () {
		var object = {
			propertyName: "propertyValue"
		}, properties, name;

		properties = "";
		object.propertyName = undefined;
		expect(object.propertyName).toBe(__);//
		for (name in object) {
			properties += name;
		}
		expect(properties).toBe(__);

		properties = "";
		delete object.propertyName;
		expect(object.propertyName).toBe(__);//
		for (name in object) {
			properties += name;
		}
		expect(properties).toBe(__);//
		
	});
	
	xit("3 - execution context and delete operator - I", function () {
		expect(a).toBe(__);//
		expect(window.a).toBe(__);//
		expect(delete a).toBe(__);//
		expect(b).toBe(__);//
		expect(window.b).toBe(__);//
		expect(delete b).toBe(__);//
		expect(c).toBe(__);//
		expect(window.c).toBe(__);//
		expect(delete c).toBe(__);//
		expect(d).toBe(__);//
		expect(window.d).toBe(__);//
		expect(delete d).toBe(__);//
	});
	
	xit("4 - execution context and delete operator - II", function () {
		var e = 1;
		f = 2;
		eval("var g = 3;");
		eval("h = 4;");
		expect(e).toBe(1);//
		expect(window.e).toBe(__);//
		expect(delete e).toBe(__);//
		expect(f).toBe(__);//
		expect(window.f).toBe(__);//
		expect(delete f).toBe(__);//
		expect(g).toBe(3);//
		expect(window.g).toBe(__);//
		expect(delete g).toBe(__);//
		expect(h).toBe(__);//
		expect(window.h).toBe(__);//
		expect(delete h).toBe(__);//
	});
	
	xit("5 - delete operator", function () {
		actor.actor = actor;
		delete actor.actor.actor;
		expect(actor.actor).toBe(__);//
	});
	
	xit("6 - delete operator", function () {
		actor.actor = actor;
		delete actor.actor.name;
		expect(actor.name).toBe(__);//
	});
});
