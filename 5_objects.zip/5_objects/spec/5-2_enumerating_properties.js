/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 5_objects
 * spec         : 5-2_enumerating_properties
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("Enumerating properties", function () {
    "use strict";
    xit("1 - for-in loops", function () {
        var actor = {
            name: "Ben Kingsley",
            dob: 1943,
            address: {
                street: "Pentonville Road",
                postcode: "N1 9JY"
            },
            toString: function () {
                return "I'm an actor!";
            }
        }, key, properties = 0, ownProperties = 0, enumerableProperties = 0;
        for (key in actor) {
            __;
            if (actor.hasOwnProperty(key)) {
                __;
            }
            if (actor.propertyIsEnumerable(key)) {
                __;
            }
        }
        expect(properties).toBe(4);//
        expect(ownProperties).toBe(4);//
        expect(enumerableProperties).toBe(4);//
    });
});




