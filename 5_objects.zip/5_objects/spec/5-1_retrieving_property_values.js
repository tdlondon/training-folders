/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 5_objects
 * spec         : 5-1_retrieving_property_values
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("retrieving property values", function () {
    var actor;
    beforeEach(function () {
        actor = {
            name: "Ben Kingsley",
            address: {
                street: "Pentonville Road",
                postcode: "N1 9JY"
            }
        };
    });

    xit("1 - dot and subscript notation to retrieve property values", function () {
        expect(actor.name).toBe(__);//
        expect(actor["name"]).toBe(__);//
    });

    xit("2 - property names are case-sensitive", function () {
        expect(actor.Name).toBe(__);//
    });

    xit("3 - use variable property name", function () {
        var propertyName = "name";
        expect(actor.propertyName).toBe(__);//
        expect(actor[propertyName]).toBe(__);//
        expect(actor["propertyName"]).toBe(__);//
    });

    xit("4 - default operator ||", function () {
        actor.title = "";
        expect(actor.address.city || "unknown city").toBe(__);//
        expect(actor.address.postcode || "unknown postcode").toBe(__);//
        expect(actor.title || "Mr.").toBe(__);//
    });

    xit("5 - guard operator &&", function () {
        var actor2, actor3 = {
            address: {
                postcode: "N1 9JY"
            }
        };
        expect(actor && actor.address && actor.address.street).toBe(__);//
        expect(actor2 && actor2.address && actor2.address.street).toBe(__);//
        expect(actor3 && actor3.address && actor3.address.street).toBe(__);//
    });

    xit("6 - combine default and guard operators", function () {
        var actor2, actor3 = {
            address: {
                postcode: "N1 9JY"
            }
        };
        expect(actor && actor.address && actor.address.street || "N/A").toBe(__);//
        expect(actor2 && actor2.address && actor2.address.street || "N/A").toBe(__);//
        expect(actor3 && actor3.address && actor3.address.street || "N/A").toBe(__);//
    });

    xit("7 - hasOwnProperty", function () {
        expect(actor.hasOwnProperty("name")).toBe(__);//
        expect(actor.toString !== undefined).toBe(__);//
        expect(actor.hasOwnProperty("toString")).toBe(__);//
    });

    xit("8 - propertyIsEnumerable", function () {
        expect(actor.propertyIsEnumerable("name")).toBe(__);//
        expect(actor.propertyIsEnumerable("toString")).toBe(__);//
    });
});



