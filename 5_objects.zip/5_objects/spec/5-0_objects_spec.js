/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 2_objects
 * spec         : 2-0_objects_spec
 **/



describe("creating objects - I", function() {
    it('object literal', function(){
        var player = {
            name     : 'super Mario',
            category : 'plumber'
        };

        expect(typeof player).toBe('object');
    });
});

describe("creating objects - II", function() {
    it('construtors', function(){
        var Enemy = function(type,weapon){
            this.type = type;
            this.weapon = weapon;
            this.kill = function(){console.log('KILL!')};
            this.die = function(){console.log('aaargh!')};
        }//end Enemy

        var eric = new Enemy('viking', 'axe');
        expect(typeof eric).toBe('object');
    });
});


describe("construtors", function() {
    it('retrieving construtors', function(){
        var Enemy = function(type,weapon){
            this.type = type;
            this.weapon = weapon;
            this.kill = function(){console.log('KILL!')};
            this.die = function(){console.log('aaargh!')};
        }//end Enemy

        var eric = new Enemy('viking', 'axe');
        expect(typeof eric.constructor).toBe('function');
    });
});

describe("properties", function() {
    it("property names and values", function(){
        var player = {
            name           : "super Mario",
            "no-of-lives"  : 5,
            shapes : {
                normal : "small red",
                power  : "big green"
            },
            enemies : ["turtle", "bird", "evil mushroom"],
            "" : "what?",
            weapon : null
        };

        expect(typeof player).toBe("object");
    });
});


describe("values", function() {
    it("retrieving property values", function(){
        var player = {
            name           : "super Mario",
            "no-of-lives"  : 5,
            shapes : {
                normal : "small red",
                power  : "big green"
            },
            enemies : ["turtle", "bird", "evil mushroom"],
            "" : "what?",
            weapon : null
        },
            prop = 'name'
        ;

        expect(player.name).toBe("super Mario");
        expect(player.weapon).toBe(null);
        expect(player.shapes.normal).toBe("small red");
        expect(player[""]).toBe("what?");
        expect(player[prop]).toBe("super Mario");
    });
});

describe("property values - I", function() {
    it('for...in', function(){
        var Enemy = function(type,weapon){
            this.type = type;
            this.weapon = weapon;
            this.kill = function(){console.log('KILL!')};
            this.die = function(){console.log('aaargh!')};
        }//end Enemy

        var eric = new Enemy('viking', 'axe');

        for(var key in eric){
            console.log(key , ' : ' , eric[key]);
        }
    });
});



describe("with statement", function() {
    it("deprecated and forbidden in ES5 strict mode", function(){
        var eric = {
            type    :  "viking",
            weapon  :  "axe",
            kill    :  function(){console.log("KILL!")},
            die     :  function(){console.log("aaargh!")}
        }, category = "external" ;

        with(eric){
            //we cannot tell which one belongs to eric !
            expect(type).toBe("viking");
            expect(category).toBe("external");
        }
    });
});

describe("updating properties", function() {
    it("just assign a new value", function(){
        var eric = {
            type    :  "viking",
            weapon  :  "battle axe",
            kill    :  function(){console.log("KILL!")},
            die     :  function(){console.log("aaargh!")}
        };
        eric.weapon = "battle axe";
        expect(eric["weapon"]).toBe("battle axe");
    });
});

describe("assigning new properties", function() {
    it("adding properties", function(){
        var eric = {
            type    :  "viking",
            weapon  :  "axe",
            kill    :  function(){console.log("KILL!")},
            die     :  function(){console.log("aaargh!")}
        };
        eric.nickname = "the red";
        expect(eric["nickname"]).toBe("the red");
    });
});

describe("comparing objects", function() {
    it("object are parsed by reference", function(){
        var eric = {
            type    :  "viking",
            weapon  :  "axe",
            kill    :  function(){console.log("KILL!")},
            die     :  function(){console.log("aaargh!")}
        },
        e2 = {
                type    :  "viking",
                weapon  :  "axe",
                kill    :  function(){console.log("KILL!")},
                die     :  function(){console.log("aaargh!")}
        },
        e3 = eric;

        expect(e2 === eric).toBe(false);
        expect(e2 == eric).toEqual(false);

        expect(e3 === eric).toBe(true);
        expect(e3 == eric).toEqual(true);
    });
});


describe("property attributes", function() {
    it("defineProperty", function(){
        var eric = {
            type    :  "viking",
            weapon  :  "axe"
        };
        Object.defineProperty(
            eric,
            "weapon",
            {
                value : "battle axe",
                writable: false,
                enumerable: true,
                configurable: true
            }
        );
        eric.weapon = "sword";

        expect( eric.weapon ).toBe("battle axe");
    });
});


describe("delete operator", function() {
    it("right behaviour", function(){
        var eric = {
            type    :  "viking",
            weapon  :  "axe"
        } , a = 3;
        b = 5;
        //obj property
        expect( delete eric.weapon ).toBe(true);
        //declared var
        expect( delete a).toBe(false);
        //undeclared var (obj property)
        expect( delete b).toBe(true);
        //inbuilt obj property
        expect( delete [1,2,3].length).toBe(false);
    });
});

