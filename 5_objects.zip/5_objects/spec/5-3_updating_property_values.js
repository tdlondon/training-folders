/**
 * TrainingDragon
 * ADVANCED JS COURSE
 * created by   : Emiliano
 * block        : 5_objects
 * spec         : 5-3_updating_property_values
 **/


/**
 * notes:
 *
 **/
var __ = null;
describe("Updating property value", function () {
	var actor;
	beforeEach(function () {
		actor = {
			name: "Ben Kingsley",
			address: {
				street: "Pentonville Road",
				postcode: "N1 9JY"
			}
		};
	});
	
	xit("1 - update primitive values", function () {
		var actor2 = {
			name: actor.name
		};
		actor2.name = "BOB";
		expect(actor2.name).toBe(__);//
		expect(actor.name).toBe(__);//
	});
	
	xit("2 - update object values", function () {
		var actor2 = {
			address: actor.address //reference to actor1 => it modifies actor1 address as well
		};
		actor2.address.street = "mare street";
		expect(actor2.address.street).toBe(__);//
		expect(actor.address.street).toBe(__);//
	});
	
	xit("3 - references", function () {
		actor.actor = actor;
		expect(actor.actor.actor.actor.actor.name).toBe(__);
	});
});